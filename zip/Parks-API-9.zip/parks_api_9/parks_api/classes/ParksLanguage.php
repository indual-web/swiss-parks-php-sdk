<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| Language class
|
*/


class ParksLanguage {


	/**
	 * API
	 */
	public $api;


	/**
	 * labels for current language
	 */
	private $labels = array();


	/**
	 * language id
	 */
	public $lang_id;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	function __construct($lang_id, $api) {

		// api instance
		$this->api = $api;

		// load language file
		if (!empty($lang_id) && in_array($lang_id, $this->api->config['available_languages']) && file_exists($this->api->config['absolute_path'].'/language/'.strtolower($lang_id).'.php')) {
			require($this->api->config['absolute_path'].'/language/'.strtolower($lang_id).'.php');
			$this->lang = strtolower($lang_id);
		}

		// load default language file
		elseif (file_exists($this->api->config['absolute_path'].'/language/de.php')) {
			require($this->api->config['absolute_path'].'/language/de.php');
			$lang_id = 'de';
		}

		// error, no language file found
		else {
			echo 'The language file does not exist.';
			exit();
		}

		// check language labels
		if (!isset($lang) || !is_array($lang)) {
			echo 'Your language file does not appear to be formatted correctly.';
			exit();
		}

		// set labels
		$this->labels = $lang;

		// set language id
		$this->lang_id = $lang_id;

	}



	/**
	 * Get language string
	 *
	 * @access public
	 * @param  string
	 * @return string
	 */
	public function get($key) {
		if (isset($this->labels[$key])) {
			return $this->labels[$key];
		}

		return $key;
	}


}