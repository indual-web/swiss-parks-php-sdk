<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| Update offer data (via cronjob)
|
*/


// include API
require("../autoload.php");

// initialize API and update local database from XML export
$api = new ParksAPI();
$api->update(TRUE);
