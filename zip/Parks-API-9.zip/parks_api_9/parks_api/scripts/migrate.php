<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
*/


// include API
require("../autoload.php");

// update offer data
$api = new ParksAPI();
$api->migrate();
