<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| Italian language file
|
*/

$lang = array();


$lang['general_from_2'] = "Da";
$lang['general_to'] = "a";
$lang['general_all'] = "Tutti";
$lang['general_none'] = "Nessuno";


/**
 * Offer language strings
 */
$lang['offer_filter'] = 'Filtro delle offerte';
$lang['offer_category'] = 'Categoria';
$lang['offer_select_category'] = 'Tutte le categorie';
$lang['offer_date_from'] = 'Data dal';
$lang['offer_date_to'] = 'Data al';
$lang['offer_search'] = 'Cerca';
$lang['offer_reset'] = 'Cancella';
$lang['offer_list'] = 'Lista delle offerte';
$lang['offer_not_found'] = 'Nessuna offerta trovata.';
$lang['offer_map'] = 'Mappa';
$lang['offer_description'] = 'Descrizione';
$lang['offer_detail'] = 'Dettagli';
$lang['offer_poi'] = 'Punti sul percorso';

$lang['offer_category'] = "Categoria";
$lang['offer_maincategory'] = "Categoria principale";
$lang['offer_subcategory'] = "Sottocategoria";
$lang['offer_subcategories'] = "Sottocategorie";
$lang['offer_select_category'] = "Tutte le offerte";
$lang['offer_selected_category'] = '%s categorie selezionate';
$lang['offer_select_park'] = "Scegli parco";
$lang['offer_select_language'] = 'Scegli lingua';
$lang['offer_default_data'] = "Dati generali";
$lang['offer_details'] = "Dettagli";
$lang['offer_files'] = "File";
$lang['offer_addresses'] = "Indirizzi";
$lang['offer_attributes'] = "Caratteristiche";
$lang['offer_target_group'] = "Gruppi destinatari";
$lang['offer_telephone'] = "Telefono";
$lang['offer_barrier_free'] = "Privo di ostacoli";
$lang['offer_learning_opportunity'] = "Offerta educazionale";
$lang['offer_child_friendly'] = "Adatto ai bambini";
$lang['offer_park_day'] = "Giornata dei Parchi";
$lang['offer_enjoy_week'] = "Settimana di divertimento";
$lang['offer_public_transport_stop'] = "Viaggio con i mezzi pubblici (fermata)";
$lang['offer_contact'] = "Informazioni di contatto";
$lang['offer_upload_image'] = "Carica immagine";
$lang['offer_links'] = "Link ulteriori";
$lang['offer_upload_pdf'] = "Carica PDF";
$lang['offer_available_for'] = "Sblocca offerta per";
$lang['offer_paerke_ch'] = "paerke.ch";
$lang['offer_own_park'] = "Parco proprio";
$lang['offer_switzerland_tourism'] = "Svizzera Turismo";
$lang['offer_valid'] = "Validit&agrave; della registrazione";
$lang['offer_valid_from'] = "Valido da";
$lang['offer_valid_to'] = "Valido fino a";
$lang['offer_signs'] = "Mostra";
$lang['offer_images'] = "Immagine";
$lang['offer_documents'] = "Documenti (PDF, Excel, Word, etc.)";
$lang['offer_documents_public'] = 'Documenti';
$lang['offer_main_image'] = "Immagine principale";
$lang['offer_image'] = "Immagine";
$lang['offer_delete_success'] = "L&#x27;offerta &egrave; stata cancellata con successo";
$lang['offer_delete_error'] = "Errore durante la cancellazione dell&#x27;offerta";
$lang['offer_category_update_success'] = "La categoria &egrave; stata aggiornata con successo.";
$lang['offer_delete_image_confirm'] = "Siete sicura/o che desiderate rimuovere l&#x27;immagine? L&#x27;immagine sar&agrave; cancellata irrevocabilmente.";
$lang['offer_document'] = "Documento";
$lang['offer_contact_change'] = "Cambia contatto";
$lang['offer_document_title'] = "Nome del documento";
$lang['offer_delete_document_confirm'] = "Siete sicura/o che desiderate rimuovere questo documento? Il documento sar&agrave; cancellato irrevocabilmente";
$lang['offer_link_url'] = "URL";
$lang['offer_link_title'] = "Indicazione";
$lang['offer_link_add'] = "Aggiungere un link";
$lang['offer_link_remove_confirm'] = "Siete sicura/o che desiderate rimuovere questo link?";
$lang['offer_park'] = "Parco/Organizzazione";
$lang['offer_additional_info'] = "Informazioni supplementari";
$lang['offer_valid_infinite'] = "Valido illimitatamente";
$lang['offer_parks_all'] = "Tutti i parchi";
$lang['offer_categories_all'] = "Tutte le categorie";
$lang['offer_categories'] = "Categorie";
$lang['offer_status'] = "Stato";
$lang['offer_status_inactive'] = "Inattivo";
$lang['offer_status_active'] = "Attivo";
$lang['offer_coordinates'] = "Coordinate";
$lang['offer_images_help'] = "Qui pu&ograve; caricare delle immagini in formato JPG, GIF o PNG. Un&#x27;immagine deve avere una dimensione minima di 200x100 pixel. La preghiamo di considerare i diritti di pubblicazione dell&#x27;immagine originale.";
$lang['offer_maps_help'] = "Per poter scegliere un punto sulla carta, pu&ograve; spostare il segnaposto con il mouse o cliccare due volte sul luogo desiderato sulla carta. In alternativa pu&ograve; anche cercare un punto inserendo direttamente il luogo e/o l'indirizzo.";
$lang['offer_activity_maps_help'] = "Pu&ograve; modificare il percorso spostando i punti del tragitto (in grigio) con il mouse. I simboli bianchi possono essere trascinati con il mouse per creare nuovi punti del tragitto. I punti gi&agrave; creati possono essere rimossi cliccandoli con il tasto destro del mouse.";
$lang['offer_will_not_be_published_on_myswitzerland'] = "Non pu&ograve; essere pubblicato da Svizzera Turismo";
$lang['offer_all_season'] = "Annuale";
$lang['offer_maps_search'] = "Cerca";
$lang['offer_maps_search_go'] = "Trova";
$lang['offer_maps_choose'] = "Scegli la mappa";
$lang['offer_languages'] = 'Lingue';
$lang['offer_filter'] = 'Filtro delle offerte';
$lang['offer_no_results'] = 'Nessuna offerta corrisponde ai suoi criteri di ricerca.';
$lang['offer_subscription_help'] = 'Per questa offerta è necessario registrarsi.';


/*
| language related fields
*/
$lang['offer_title_description'] = "Titolo &amp; descrizione";
$lang['offer_title'] = "Titolo";
$lang['offer_description'] = "Descrizione";
$lang['offer_short_description'] = "Descrizione breve";
$lang['offer_medium_description'] = "Descrizione media";
$lang['offer_long_description'] = "Descrizione lunga";
$lang['offer_price'] = "Informazioni sui prezzi";
$lang['offer_date_details'] = "Dettagli sugli appuntamenti";


/*
| Default mask fields
*/
$lang['offer_parkname'] = "Nome del parco";
$lang['offer_park_event'] = "Evento del parco";
$lang['offer_park_partner'] = "Azienda partner del parco";
$lang['offer_park_partner_event'] = "Eventi del partner del parco";
$lang['offer_park_partner_booking'] = 'Partner del parco';
$lang['offer_kind_of'] = "Tipo di evento";
$lang['offer_institution'] = "Istituzione/localit&agrave;";
$lang['offer_street'] = "Strada";
$lang['offer_place'] = "Luogo";
$lang['offer_location'] = "Posizione";
$lang['offer_date'] = "Appuntamento";
$lang['offer_dates'] = "Appuntamenti";
$lang['offer_from'] = "da";
$lang['offer_to'] = "fino";
$lang['offer_at'] = "a";
$lang['offer_oclock'] = "ore";


/*
| Insert mask 1
*/
$lang['offer_title_event'] = "Date degli eventi";
$lang['offer_add_date'] = "Aggiungi altri appuntamenti";
$lang['offer_event_location'] = "Luogo dell'evento";
$lang['offer_event_organiser'] = "Organizzatore/organizzatrice";
$lang['offer_subscription'] = "Iscrizione";
$lang['offer_subscription_mandatory'] = "Iscrizione necessaria";
$lang['offer_subscription_contact'] = "Iscrizione da";
$lang['offer_subscription_link'] = "Link per l&#x27;iscrizione";
$lang['offer_subscription_recommended'] = 'Consigliato';
$lang['offer_subscription_details'] = "Ulteriori informazioni riguardanti l'iscrizione";
$lang['offer_local'] = "Locale";
$lang['offer_regional'] = "Regionale";
$lang['offer_national'] = "Nazionale";
$lang['offer_international'] = "Internazionale";
$lang['offer_misc'] = "Diversi";
$lang['offer_delete_date_confirm'] = "Siete sicuro/a di voler rimuovere questa data?";
$lang['offer_location_details'] = "Dettagli della posizione";
$lang['offer_subscription_subscribe_now'] = 'Iscriversi online ora';


/*
| Insert mask 2
*/
$lang['offer_product_offerer'] = "Ente organizzativo";
$lang['offer_opening_hours'] = "Orari di apertura";
$lang['offer_supplier'] = "Fornitore";
$lang['offer_availability'] = "Prodotto ottenibile dal / fino al";
$lang['offer_available_from'] = "Ottenibile da";
$lang['offer_available_to'] = "Ottenibile fino al";
$lang['offer_supplier_add'] = "Aggiungi un fornitore";
$lang['offer_contact_remove_confirm'] = "Siete sicuro/a di voler rimuovere questo contatto?";
$lang['offer_infrastructure'] = "Infrastruttura";
$lang['offer_number_of_rooms'] = "Numero di camere";
$lang['offer_rooms'] = '%s camere';
$lang['offer_conference_room'] = "Sala per seminari";
$lang['offer_playground'] = "Parco giochi";
$lang['offer_picnic_place'] = "Spazio per picnic";
$lang['offer_fireplace'] = "Spazio focolare";
$lang['offer_washroom'] = "WC";
$lang['offer_other_infrastructure'] = "Ulteriori infrastrutture";


/*
| Insert mask 3
*/
$lang['offer_organizer'] = "Organizzatore/organizzatrice";
$lang['offer_execution_times'] = "Date di attuazione / periodo di tempo";
$lang['offer_accommodation'] = "Possibilit&agrave; di pernottamento";
$lang['offer_accommodation_add'] = "Aggiungi una possibilit&agrave; di pernottamento";
$lang['offer_number_of_people_groups'] = "Numero di persone nelle offerte di gruppo";
$lang['offer_number_of_people_individual'] = "Numero di persone per offerte individuali";
$lang['offer_min_subscriber'] = "Numero minimo di partecipanti";
$lang['offer_max_subscriber'] = "Numero massimo di partecipanti";
$lang['offer_benefits'] = "Prestazioni";
$lang['offer_requirements'] = "Requisiti";


/*
| Insert mask 4 (Activity)
*/
$lang['offer_safety_instructions'] = "Avvertenze di sicurezza";
$lang['offer_signalization'] = "Segnalizzazione";
$lang['offer_material_rent'] = "Noleggio del materiale";
$lang['offer_catering_informations'] = "Possibilit&agrave; di approvvigionamento";
$lang['offer_saison'] = "Stagione";
$lang['offer_start_place'] = "Luogo di partenza";
$lang['offer_goal_place'] = "Luogo di arrivo";
$lang['offer_altitude'] = "Altitudine";
$lang['offer_route_info'] = "Informazioni sull&#x27;itinerario";
$lang['offer_route_length'] = "Lunghezza dell&#x27;itinerario";
$lang['offer_untarred_route_length'] = 'Lunghezza rotta non asfaltata';
$lang['offer_altitude_differential'] = "Dislivello";
$lang['offer_altitude_ascent'] = "Dislivello della salita in metri";
$lang['offer_altitude_descent'] = "Dislivello della discesa in metri";
$lang['offer_altitude_meter'] = "m";
$lang['offer_route_length_km'] = "km";
$lang['offer_time_required'] = "Durata";
$lang['offer_level_technics'] = "Grado di difficolt&agrave;";
$lang['offer_level_condition'] = "Condizioni del grado di difficolt&agrave;";
$lang['offer_time_required_2h'] = "&lt;2 ore";
$lang['offer_time_required_2_4h'] = "2-4 ore";
$lang['offer_time_required_4h'] = "&gt;4 ore";
$lang['offer_easy'] = "Facile";
$lang['offer_average'] = "Medio";
$lang['offer_difficult'] = "Difficile";
$lang['offer_route'] = "Itinerario";
$lang['offer_activity_location'] = 'Luogo / Luogo di partenza';


$lang['pagination_prev'] = '&laquo; Indietro';
$lang['pagination_next'] = 'Avanti &raquo;';
$lang['back_to_overview'] = "&laquo; Torna all'elenco";
$lang['back_to_route'] = "Torna all‘ itinerario";


/*
| Swissmap
*/
$lang['swissmap_basemap'] = 'Mappa di base';
$lang['swissmap_swissimage'] = 'Fotografia aerea';
$lang['swissmap_pixelkarte'] = 'Carte nazionali';
$lang['swissmap_hybrid'] = 'Ibrido';

$lang['swissmap_zoom_in'] = 'Ingrandire';
$lang['swissmap_zoom_out'] = 'Ridurre';
$lang['swissmap_select_all_parks'] = 'Tutti i parchi';
$lang['swissmap_home'] = 'Home';
$lang['swissmap_back'] = 'Indietro';
$lang['swissmap_next'] = 'Avanti';
$lang['swissmap_print'] = 'Stampare';
$lang['swissmap_help'] = 'Aiuto';
$lang['swissmap_show_sidebar'] = 'Mostrare la barra laterale';
$lang['swissmap_hide_sidebar'] = 'Nascondere la barra laterale';
$lang['swissmap_show_legend'] = 'Mostrare la leggenda';
$lang['swissmap_hide_legend'] = 'Nascondere la leggenda';
$lang['swissmap_show_overview'] = 'Mostrare le carte sinottiche';
$lang['swissmap_hide_overview'] = 'Nascondere le carte sinottiche';
$lang['swissmap_close'] = 'Chiudere';
$lang['swissmap_baseinfo'] = 'Informazioni base';
$lang['swissmap_coordinates'] = 'Coordinate';
$lang['swissmap_tools'] = 'Strumenti';
$lang['swissmap_tools_none'] = "Nessuno strumento";
$lang['swissmap_tools_point'] = "Punto";
$lang['swissmap_tools_distance'] = "Distanza";
$lang['swissmap_tools_area'] = "Area";
$lang['swissmap_tools_result'] = "Risultato di misura";
$lang['swissmap_tools_choose_tool'] = "Selezionare uno strumento per misurare.";
$lang['swissmap_search'] = 'Cerca per posto, cantone, ...';
$lang['swissmap_home_title'] = 'Home';
$lang['swissmap_back_title'] = 'Indietro';
$lang['swissmap_next_title'] = 'Avanti';
$lang['swissmap_tools_title'] = "Strumenti per misurare";
$lang['swissmap_print_title'] = 'Stampare';
$lang['swissmap_help_title'] = 'Aiuto';
$lang['swissmap_offers'] = 'Offerte';
$lang['swissmap_all_offers'] = 'Tutte le offerte';
$lang['swissmap_source_swisstopo'] = 'Sorgente: swisstopo';
$lang['swissmap_loading'] = 'Caricamento...';
$lang['swissmap_cancel'] = 'Annulla';