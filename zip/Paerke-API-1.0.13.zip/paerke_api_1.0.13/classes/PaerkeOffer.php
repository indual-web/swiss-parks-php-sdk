<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Class for retrieving data for offers, categories, etc.
 *
 * @author indual GmbH
 * @version 1.0
 * @copyright 2013 by indual GmbH
 */
class PaerkeOffer {

	/**
	 * API object
	 */
	private $api;


	/**
	 * Database object
	 */
	private $db;


	/**
	 * Logger object
	 */
	private $logger;


	/**
	 * Configuration items
	 */
	private $config;


	/**
	 * Current language
	 */
	private $language;


	/**
	 * Offer levels for difficulty
	 */
	public $levels;


	/**
	 * Park abbreviations
	 */
	public $parkAbbreviations = array(
		2  => 'lpb',
		3  => 'snp',
		4  => 'jpa',
		5  => 'prc',
		6  => 'die',
		8  => 'frg',
		9  => 'bvm',
		10 => 'ela',
		11 => 'ube',
		12 => 'npt',
		13 => 'gpe',
		14 => 'wpz',
		15 => 'npb',
		16 => 'prd',
		17 => 'adu',
		18 => 'pnl',
		19 => 'pjv',
		20 => 'npf',
		27 => 'npn',
		28 => 'nps',
	);


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	function __construct($api) {
		$this->api = $api;
		$this->language = $this->api->language;

		$this->config = $this->api->config;
		$this->db = new PaerkeMySQL($this->config['db_hostname'], $this->config['db_username'], $this->config['db_password'], $this->config['db_database']);
		$this->logger = new PaerkeLog();

		$this->levels = array(
			0 => '',
			1 => $this->api->lang->get('offer_easy'),
			2 => $this->api->lang->get('offer_average'),
			3 => $this->api->lang->get('offer_difficult')
		);
	}


	/**
	 * Get current language
	 *
	 * @access public
	 * @return string
	 */
	public function get_language() {
		return $this->language;
	}


	/**
	 * Set current language (used for getting offers)
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	public function set_language($language) {
		if (!empty($language))
			$this->language = $language;
	}


	/**
	 * Checks if an offer with the given id exists
	 *
	 * @access public
	 * @param  int
	 * @return mixed
	 */
	public function offer_exists($offer_id) {
		$q_offer = $this->db->query("SELECT `offer_id` FROM `offer` WHERE `offer_id` = ".$offer_id);
		if (mysql_num_rows($q_offer) > 0) {
			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Get offer by ID
	 *
	 * @access public
	 * @param  int
	 * @return mixed
	 */
	public function get_offer($offer_id, $date_from = NULL, $date_to = NULL) {
		$available_languages = array('de', 'fr', 'it', 'en');

		// first check user language
		$q_offer = $this->db->query("SELECT *
										FROM `offer` main_offer
										INNER JOIN `offer_i18n` main_offer_i18n ON main_offer_i18n.`offer_id` = main_offer.`offer_id`
										LEFT OUTER JOIN `subscription` ON `subscription`.`offer_id` = main_offer.`offer_id`
										WHERE main_offer.offer_id = '".$offer_id."'
										AND main_offer_i18n.language = '".$this->language."'");
		// no result, check other languages
		if (!mysql_num_rows($q_offer)) {
			foreach ($available_languages as $language) {
				if ($language != $this->language) {
					$q_offer = $this->db->query("SELECT *
													FROM `offer` main_offer
													INNER JOIN `offer_i18n` main_offer_i18n ON main_offer_i18n.`offer_id` = main_offer.`offer_id`
													WHERE main_offer.offer_id = '".$offer_id."'
													AND main_offer_i18n.language = '".$language."'");
					if (mysql_num_rows($q_offer) > 0) {
						break;
					}
				}
			}
		}

		if (($q_offer != FALSE) && mysql_num_rows($q_offer)) {

			$offer = mysql_fetch_object($q_offer);
			$offer->root_category = NULL;

			// Correct data types
			$offer->barrier_free = (boolean)$offer->barrier_free;
			$offer->learning_opportunity = (boolean)$offer->learning_opportunity;
			$offer->child_friendly = (boolean)$offer->child_friendly;
			$offer->park_day = (boolean)$offer->park_day;
			$offer->enjoy_week = (boolean)$offer->enjoy_week;

			$offer->latitude = (float)$offer->latitude;
			$offer->longitude = (float)$offer->longitude;

			// Categories
			$q_categories = $this->db->get('category_link', array('offer_id' => $offer_id));
			if (mysql_num_rows($q_categories) > 0) {
				$offer->categories = array();

				while ($row = mysql_fetch_object($q_categories)) {
					$offer->categories[$row->category_id] = $this->get_category($row->category_id);

					if (!$offer->root_category) {
						$offer->root_category = $this->_get_root_category($row->category_id);
					}
				}
			}

			// Target groups
			$q_target_groups = $this->db->get('target_group_link', array('offer_id' => $offer_id));
			if (mysql_num_rows($q_target_groups) > 0) {
				$offer->target_groups = array();

				while ($row = mysql_fetch_object($q_target_groups)) {
					$offer->target_groups[$row->target_group_id] = $this->get_target_group($row->target_group_id)->body;
				}
			}

			// Route
			$q_route = $this->db->get('offer_route', array('offer_id' => $offer_id));
			if (mysql_num_rows($q_route) > 0) {
				$offer->route = array();

				while ($row = mysql_fetch_object($q_route)) {
					$offer->route[$row->sort] = $row;
				}
			}

			// Dates
			if (!empty($date_from)) {
				$offer->date_from = $date_from;
				$offer->date_to = $date_to;
			}
			else {
				$q_dates = $this->db->get('offer_date', array('offer_id' => $offer_id), NULL, array("DATE_FORMAT(date_from, '".$this->config['mysql_date_format']."')" => 'date_from', "DATE_FORMAT(date_to, '".$this->config['mysql_date_format']."')" => 'date_to'));
				if (mysql_num_rows($q_dates) > 0) {
					$offer->dates = array();

					while ($row = mysql_fetch_object($q_dates)) {
						$offer->dates[] = $row;
					}
				}
			}

			// Images
			$q_images = $this->db->get('image', array('offer_id' => $offer_id));
			if (mysql_num_rows($q_images) > 0) {
				$offer->images = array();

				while ($row = mysql_fetch_object($q_images)) {
					$offer->images[] = $row;
				}
			}

			// Documents
			$q_documents = $this->db->get('document', array('offer_id' => $offer_id, 'language' => $this->language));
			if (mysql_num_rows($q_documents) > 0) {
				$offer->documents = array();

				while ($row = mysql_fetch_object($q_documents)) {
					$offer->documents[] = $row;
				}
			}

			// Hyperlinks
			$q_hyperlinks = $this->db->get('hyperlink', array('offer_id' => $offer_id, 'language' => $this->language));
			if (mysql_num_rows($q_hyperlinks) > 0) {
				$offer->hyperlinks = array();

				while ($row = mysql_fetch_object($q_hyperlinks)) {
					$offer->hyperlinks[] = $row;
				}
			}

			// Event
			if ($offer->root_category == CATEGORY_EVENT) {
				$q_event = $this->db->get('event', array('offer_id' => $offer_id));

				if (mysql_num_rows($q_event)) {
					$offer = (object) array_merge( (array)$offer, mysql_fetch_assoc($q_event));

					$offer->is_park_event = isset($offer->is_park_event) ? (boolean)$offer->is_park_event : FALSE;
					$offer->is_park_partner_event = isset($offer->is_park_partner_event) ? (boolean)$offer->is_park_partner_event : FALSE;
					$offer->subscription_mandatory = isset($offer->is_park_partner_event) ? (int)$offer->subscription_mandatory : 0;
				}
			}
			// Product
			else if ($offer->root_category == CATEGORY_PRODUCT) {
				$q_product = $this->db->get('product', array('offer_id' => $offer_id), NULL, array("DATE_FORMAT(available_from, '".$this->config['mysql_date_format']."')" => 'available_from', "DATE_FORMAT(available_to, '".$this->config['mysql_date_format']."')" => 'available_to'));

				if (mysql_num_rows($q_product)) {
					$offer = (object) array_merge( (array)$offer, mysql_fetch_assoc($q_product));

					$offer->number_of_rooms = (int)$offer->number_of_rooms;
					$offer->has_conference_room = (boolean)$offer->has_conference_room;
					$offer->has_playground = (boolean)$offer->has_playground;
					$offer->has_picnic_place = (boolean)$offer->has_picnic_place;
					$offer->has_fireplace = (boolean)$offer->has_fireplace;
					$offer->has_washrooms = (boolean)$offer->has_washrooms;
					$offer->is_park_event = isset($offer->is_park_event) ? (boolean)$offer->is_park_event : FALSE;
					$offer->is_park_partner_event = isset($offer->is_park_partner_event) ? (boolean)$offer->is_park_partner_event : FALSE;
					$offer->subscription_mandatory = isset($offer->subscription_mandatory) ? (int)$offer->subscription_mandatory : NULL;


					// Suppliers
					$q_suppliers = $this->db->get('supplier', array('offer_id' => $offer_id));
					if (mysql_num_rows($q_suppliers) > 0) {
						$offer->suppliers = array();

						while ($row = mysql_fetch_object($q_suppliers)) {
							$offer->suppliers[] = array('contact' => $row->contact, 'is_park_partner' => $row->is_park_partner);
						}
					}
				}
			}
			// Booking
			else if ($offer->root_category == CATEGORY_BOOKING) {
				$q_booking = $this->db->get('booking', array('offer_id' => $offer_id));

				if (mysql_num_rows($q_booking)) {
					$offer = (object) array_merge( (array)$offer, mysql_fetch_assoc($q_booking));

					$offer->is_park_partner = (boolean)$offer->is_park_partner;
					$offer->min_group_subscriber = (int)$offer->min_group_subscriber;
					$offer->max_group_subscriber = (int)$offer->max_group_subscriber;
					$offer->min_individual_subscriber = (int)$offer->min_individual_subscriber;
					$offer->max_individual_subscriber = (int)$offer->max_individual_subscriber;
					$offer->subscription_mandatory = (int)$offer->subscription_mandatory;


					// Suppliers
					$q_accommodations = $this->db->get('accommodation', array('offer_id' => $offer_id));
					if (mysql_num_rows($q_accommodations) > 0) {
						$offer->accommodations = array();

						while ($row = mysql_fetch_object($q_accommodations)) {
							$offer->accommodations[] = $row->contact;
						}
					}
				}
			}
			// Activity
			else if ($offer->root_category == CATEGORY_ACTIVITY) {
				$q_activity = $this->db->get('activity', array('offer_id' => $offer_id));

				if (mysql_num_rows($q_activity)) {
					$offer = (object) array_merge( (array)$offer, mysql_fetch_assoc($q_activity));

					$offer->route_length = (float)$offer->route_length;
					$offer->untarred_route_length = (float)$offer->untarred_route_length;
					$offer->altitude_differential = (int)$offer->altitude_differential;
					$offer->altitude_ascent = (int)$offer->altitude_ascent;
					$offer->altitude_descent = (int)$offer->altitude_descent;

					$offer->time_required = (string)$offer->time_required;
					$offer->level_technics = $this->levels[(int)$offer->level_technics];
					$offer->level_condition = $this->levels[(int)$offer->level_condition];

					$offer->has_playground = (boolean)$offer->has_playground;
					$offer->has_picnic_place = (boolean)$offer->has_picnic_place;
					$offer->has_fireplace = (boolean)$offer->has_fireplace;
					$offer->has_washrooms = (boolean)$offer->has_washrooms;
				}
			}

			return $offer;

		}

		return FALSE;
	}


	/**
	 * Get all offers
	 *
	 * @access public
	 * @return mixed  An array of offers or FALSE when no offers found
	 */
	public function get_all_offers($offset = NULL, $limit = NULL) {
		$offer_sql = $this->db->query("

					SELECT `offer`.*, `offer_i18n`.*, `offer_date`.`date_from`, `offer_date`.`date_to`

					FROM `offer`

					INNER JOIN `offer_i18n` ON `offer`.`offer_id` = `offer_i18n`.`offer_id`
					LEFT OUTER JOIN `offer_date` ON `offer`.`offer_id` = `offer_date`.`offer_id`

					INNER JOIN `category_link` ON category_link.`offer_id` = `offer`.`offer_id`
					INNER JOIN `category` AS c1 ON category_link.`category_id` = c1.`category_id`
					LEFT JOIN `category` AS c2 ON c1.parent_id = c2.category_id
					LEFT JOIN `category` AS c3 ON c2.parent_id = c3.category_id

					WHERE (
						((`offer_date`.`date_from` IS NULL) OR (`offer_date`.`date_from` >= NOW()) OR (`offer_date`.`date_to` >= NOW()))
						OR
						(".CATEGORY_EVENT." NOT IN (`c1`.`category_id`, `c1`.`parent_id`, `c2`.`category_id`, `c2`.`parent_id`, `c3`.`category_id`, `c3`.`parent_id`))
					)

					GROUP BY offer.offer_id, offer_date.date_from
					ORDER BY offer_date.date_from, offer_i18n.title ASC

					");

		if (mysql_num_rows($offer_sql) > 0) {
			$offers = array();

			while ($row = mysql_fetch_object($offer_sql)) {
				if (!empty($row->offer_id)) {
					$offers[] = $this->get_offer($row->offer_id, $row->date_from, $row->date_to);
				}
			}

			return $offers;
		}

		return FALSE;
	}


	/**
	 * Get Custom Layers for API filtered by language
	 * @access public
	 * @return void
	 */
	public function get_custom_layers() {

		$query = 'SELECT * FROM map_layer WHERE languages LIKE "%'. $this->language.'%";';
		$q_layers = $this->db->query($query);

		if (mysql_num_rows($q_layers) > 0) {
			$layers = array();

			while ($row = mysql_fetch_object($q_layers)) {

				// retrieve content
				$query_i18n = 'SELECT * FROM map_layer_i18n WHERE map_layer_id = '. $row->map_layer_id;
				$q_layers_i18n = $this->db->query($query_i18n);
				if (mysql_num_rows($q_layers_i18n) > 0) {
					$layer_content = array();

					// parse content for each langauge
					while ($row_i18n = mysql_fetch_object($q_layers_i18n)) {
						if (isset($row_i18n->language) && isset($row_i18n->popup_content)) {
							$layer_content[$row_i18n->language] = $row_i18n->popup_content;
						}
					}

					// add parsed content to row
					$row->popup_content = $layer_content;
 				}

				$layers[$row->map_layer_id] = $row;
			}
			return $layers;
		}
		return FALSE;
	}



	/**
	 * Get filtered offers
	 *
	 * @access public
	 * @param  mixed          An array containing filter values
	 * @return mixed|boolean  An array of offers or FALSE when no offers found
	 */
	public function get_filtered_offers($filter, $limit = NULL, $offset = NULL) {

		$select = "SELECT * FROM `offer` ";
		$select .= "INNER JOIN `offer_i18n` ON `offer`.`offer_id` = `offer_i18n`.`offer_id` ";
		if (isset($this->config['language_independence']) && ($this->config['language_independence'] === FALSE)) {
			$select .= "AND `offer_i18n`.language = '".$this->language."' ";
		}
		$select .= "LEFT OUTER JOIN `offer_date` ON `offer`.`offer_id` = `offer_date`.`offer_id` ";
		$join = "";
		$where = array();
		$limit_sql = "";

		// filter: category
		$join .= " INNER JOIN `category_link` ON `category_link`.`offer_id` = `offer`.`offer_id` ";
		$join .= " INNER JOIN `category` AS c1 ON `category_link`.`category_id` = `c1`.`category_id` ";
		$join .= " LEFT JOIN `category` AS c2 ON `c1`.`parent_id` = `c2`.`category_id` ";
		$join .= " LEFT JOIN `category` AS c3 ON `c2`.`parent_id` = `c3`.`category_id` ";
		if (isset($filter['categories']) && !empty($filter['categories'])) {
			if (!is_array($filter['categories'])) {
				$filter['categories'] = array($filter['categories']);
			}
			if (!empty($filter['categories'])) {
				$where_categories = "";
				foreach ($filter['categories'] as $category) {
					$where_categories .= $category." IN (c1.`category_id`, c1.`parent_id`, c2.`category_id`, c2.`parent_id`, c3.`category_id`, c3.`parent_id`) OR ";
				}
				$where_categories = substr($where_categories, 0, -4);
				$where[] = "(".$where_categories.")";
			}
		}

		// filter: offer settings
		if (isset($filter['offer_settings']) && !empty($filter['offer_settings'])) {
			foreach ($filter['offer_settings'] as $setting) {
				$where[] = "`offer`.`".$setting."` = '1'";
			}
		}

		// filter: target groups
		if (isset($filter['target_groups']) && !empty($filter['target_groups'])) {
			$join .= " INNER JOIN `target_group_link` ON `target_group_link`.`offer_id` = `offer`.`offer_id` ";
			$where[] = "`target_group_link`.`target_group_id` IN (".implode(',', $filter['target_groups']).")";
		}

		// filter: park
		if (isset($filter['park_id']) && !empty($filter['park_id'])) {
			$where[] = "`offer`.`park_id` = '".$filter['park_id']."'";
		}
		if (isset($filter['user']) && !empty($filter['user'])) {
			$where[] = "`offer`.`park` = '".$filter['park_id']."'";
		}

		// filter: date
		if ((isset($filter['date_from']) && !empty($filter['date_from'])) || (isset($filter['date_to']) && !empty($filter['date_to']))) {
			$date_from = isset($filter['date_from']) ? $this->_get_datetime($filter['date_from']) : FALSE;
			$date_to = isset($filter['date_to']) ? $this->_get_datetime($filter['date_to']) : FALSE;

			if ($date_from && $date_to) {
				$where[] = "(`offer_date`.`date_from` BETWEEN DATE_SUB('".$date_from."', INTERVAL 1 DAY) AND DATE_ADD('".$date_to."', INTERVAL 1 DAY) OR `offer_date`.`date_to` BETWEEN DATE_SUB('".$date_from."', INTERVAL 1 DAY) AND DATE_ADD('".$date_to."', INTERVAL 1 DAY))";
			}
			else if ($date_from) {
				$where[] = "(`offer_date`.`date_from` >= '".$date_from."' OR `offer_date`.`date_to` >= '".$date_from."')";
			}
			else if ($date_to) {
				$where[] = "(`offer_date`.`date_to` <= '".$date_to."' OR `offer_date`.`date_from` <= '".$date_to."')";
			}
			else {
				$where[] = "(`offer_date`.`date_from` IS NULL OR `offer_date`.`date_from` >= NOW() OR `offer_date`.`date_to` >= NOW())";
			}
		}
		else {
			// show only coming events
			$where[] = "(
				(`offer_date`.`date_from` IS NULL OR `offer_date`.`date_from` >= NOW() OR `offer_date`.`date_to` >= NOW())
				OR
				(".CATEGORY_EVENT." NOT IN (`c1`.`category_id`, `c1`.`parent_id`, `c2`.`category_id`, `c2`.`parent_id`, `c3`.`category_id`, `c3`.`parent_id`))
			)";
		}

		// filter: search words
		if (isset($filter['search'])) {
			$where[] = "( (offer_i18n.title LIKE '%".$filter['search']."%') OR (offer_i18n.abstract LIKE '%".$filter['search']."%') )";
		}

		// create where
		if (!empty($where)) {
			$where = " WHERE ".implode(" AND ", $where);
		}
		else {
			$where = "";
		}

		// order by, group by
		$group_by = " GROUP BY offer.offer_id, offer_date.date_from";
		$order_by = " ORDER BY offer_date.date_from, offer_i18n.title ASC";

		// limit query
		if (!is_null($limit) && is_numeric($limit)) {
			$limit_sql = " LIMIT ".(isset($offset) && is_numeric($offset) ? intval($offset).', ' : '').intval($limit);
		}

		// run query
		$query = $select.$join.$where.$group_by.$order_by.$limit_sql;
		$q_offers = $this->db->query($query);

		if (mysql_num_rows($q_offers) > 0) {
			$offers = array();

			while($row = mysql_fetch_object($q_offers)) {
				if (!empty($row->offer_id)) {
					$offers[] = $this->get_offer($row->offer_id, $row->date_from, $row->date_to);
				}
			}

			return $offers;
		}

		return FALSE;
	}


	/**
	 * Get category by ID
	 *
	 * @access public
	 * @param  int
	 * @return object  A category object or FALSE
	 */
	public function get_category($category_id) {
		$q_category = $this->db->get('category', array('category.category_id' => $category_id, 'language' => $this->language), array('category_i18n' => 'category.category_id = category_i18n.category_id'));
		if (mysql_num_rows($q_category) > 0) {
			return mysql_fetch_object($q_category);
		}

		return FALSE;
	}


	/**
	 * Get path for a category
	 *
	 * @access public
	 * @param  int
	 * @return object  A category object or FALSE
	 */
	public function get_category_path($category_id) {
		if (!empty($category_id)) {
			$path = array();

			while($category_id > 0) {
				$q_category = $this->db->get('category', array('category_id' => $category_id));
				if (mysql_num_rows($q_category) > 0) {
					$category = mysql_fetch_object($q_category);
					$category_id = $category->parent_id;
					$path[] = $category->category_id;
				}
			}

			return $path;
		}

		return FALSE;
	}


	/**
	 * Get all categories
	 *
	 * @access public
	 * @return mixed|boolean  An array of categories or FALSE when nothing found
	 */
	public function get_all_categories($additional_infos = array()) {
		$q_categories_string = "
			SELECT
				c1.`category_id` as category_id,
				c1.`parent_id`,
				`category_i18n`.`body`,
				c1.`marker`,
				CONCAT_WS(',', c1.`parent_id`, c2.`parent_id`, c3.`parent_id`, c4.`parent_id`) AS parents,
				c1.`sort`
			FROM `category` c1
			INNER JOIN `category_i18n` ON `category_i18n`.`category_id` = c1.`category_id` AND `category_i18n`.`language` = '".$this->language."'
			LEFT JOIN `category` c2 ON c1.`parent_id` = c2.`category_id`
			LEFT JOIN `category` c3 ON c2.`parent_id` = c3.`category_id`
			LEFT JOIN `category` c4 ON c3.`parent_id` = c4.`category_id`";

		// Additional information
		if (!empty($additional_infos) && count($additional_infos) > 0) {
			$q_categories_string .= "
				LEFT JOIN `category_link` l ON l.`category_id` = c1.`category_id`
				LEFT JOIN `offer` o ON l.`offer_id` = o.`offer_id` WHERE (";
			foreach ($additional_infos as $additional_info) {
				$q_categories_string .= "o.`".$additional_info."` = '1' AND ";
			}
			$q_categories_string = substr($q_categories_string, 0, -5).") OR c1.`parent_id` = 0 ";
		}

		$q_categories_string .= "GROUP BY c1.`category_id` ";
		$q_categories_string .= "ORDER BY c1.`sort` ";

		$q_categories = $this->db->query($q_categories_string);

		if (mysql_num_rows($q_categories) > 0) {
			$categories = array();

			while($row = mysql_fetch_object($q_categories)) {
				$categories[$row->category_id] = (object) array(
					'category_id' => $row->category_id,
					'parent_id' => $row->parent_id,
					'language' => $this->language,
					'body' => $row->body,
					'marker' => $row->marker,
					'parents' => explode(",", $row->parents),
					'sort' => $row->sort
				);
			}

			return $categories;
		}

		return FALSE;
	}


	/**
	 * Get all category links
	 *
	 * @access public
	 * @return mixed|boolean  An array of users or FALSE when nothing found
	 */
	public function get_all_category_links() {
		$q_category_links = $this->db->query("SELECT category_id FROM category_link GROUP BY category_link.category_id");

		if (mysql_num_rows($q_category_links) > 0) {
			// add main categories
			$category_links = array(CATEGORY_EVENT, CATEGORY_PRODUCT, CATEGORY_BOOKING, CATEGORY_ACTIVITY);

			while($row = mysql_fetch_object($q_category_links)) {
				$category_links[] = $row->category_id;
			}

			return $category_links;
		}

		return FALSE;
	}


	/**
	 * Get all users/parks
	 *
	 * @access public
	 * @return mixed|boolean  An array of users or FALSE when nothing found
	 */
	public function get_all_users($categories = array(), $additional_infos = array()) {
		if(empty($categories)) {
			$categories = $this->get_all_category_links();
		}

		$query = "SELECT park_id, park FROM offer";
		if (count($categories) > 0) {
			$query .= " INNER JOIN category_link ON offer.offer_id = category_link.offer_id WHERE category_link.category_id IN (".implode(",", $categories).")";
		}

		// additional information
		if (!empty($additional_infos) && count($additional_infos) > 0) {
			foreach ($additional_infos as $additional_info) {
				$query .= " AND `offer`.`".$additional_info."` = '1'";
			}
		}
		$query .= " GROUP BY park_id ORDER BY park ASC";

		$q_users = $this->db->query($query);

		if (mysql_num_rows($q_users) > 0) {
			$users = array();

			while($row = mysql_fetch_object($q_users)) {
				$users[$row->park_id] = $row->park;
			}

			return $users;
		}

		return FALSE;
	}


	/**
	 * Get target group by ID
	 *
	 * @access public
	 * @param  int
	 * @return object  A target_group object or FALSE
	 */
	public function get_target_group($target_group_id) {
		$q_target_group = $this->db->get('target_group', array('target_group.target_group_id' => $target_group_id, 'language' => $this->language), array('target_group_i18n' => 'target_group.target_group_id = target_group_i18n.target_group_id'));
		if (mysql_num_rows($q_target_group) > 0) {
			return mysql_fetch_object($q_target_group);
		}

		return FALSE;
	}


	/**
	 * Get all target groups
	 *
	 * @access public
	 * @return mixed|boolean  An array of categories or FALSE when nothing found
	 */
	public function get_all_target_groups() {
		$q_target_groups = $this->db->get('target_group');

		if (mysql_num_rows($q_target_groups) > 0) {
			$target_groups = array();

			while($row = mysql_fetch_object($q_target_groups)) {
				$target_groups[$row->target_group_id] = $this->get_target_group($row->target_group_id);
			}

			return $target_groups;
		}

		return FALSE;
	}


	/**
	 * Private method for retrieving the root category
	 *
	 * @param category_id
	 * @return integer|boolean
	 */
	private function _get_root_category($category_id) {
		if (!empty($category_id)) {

			while($category_id > 0) {
				$q_category = $this->db->get('category', array('category_id' => $category_id));
				if (mysql_num_rows($q_category) > 0) {
					$category = mysql_fetch_object($q_category);
					$category_id = $category->parent_id;
					$last_category_id = $category->category_id;
				}
			}

			return (int)$last_category_id;
		}

		return FALSE;
	}

	private function _get_datetime($value, $format = 'Y-m-d H:i:s') {
		$datetime = new DateTime($value);
		return $datetime->format($format);
	}

}