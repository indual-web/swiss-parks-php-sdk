<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| API configuration
|
*/



/*
|--------------------------------------------------------------------------
| Global configuration for Paerke.ch API
|--------------------------------------------------------------------------
|
*/
$config = array();



/*
|--------------------------------------------------------------------------
| API Hash Key
|--------------------------------------------------------------------------
|
| This hash is needed to import the data via XML.
| Create an export configuration on http://angebote.paerke.ch and
| put your Hashkey in here.
|
*/
$config['api_hash'] = "insert-your-hash-here";



/*
|--------------------------------------------------------------------------
| MySQL Database
|--------------------------------------------------------------------------
|
| A MySQL Database is required to use the API.
| Imported offers will be stored there for better performance.
|
*/
$config['db_hostname'] = "localhost";
$config['db_username'] = "root";
$config['db_password'] = "root";
$config['db_database'] = "paerke_api";



/*
|--------------------------------------------------------------------------
| Custom view
|--------------------------------------------------------------------------
|
| Set your custom view, located in your "custom" folder.
| example: "MyView"
|
*/
$config['class_view'] = "";



/*
|--------------------------------------------------------------------------
| Custom view options
|--------------------------------------------------------------------------
|
| 'always_show_filter' => Show filter on detail pages
| 'show_route_filter' => Show route filter
| 'show_route_filter_min_count' => Define minimum activities for route filter
| 'offers_per_apge' => How many offers should be displayed per page?
| 'n_th_point' => Each n-th point of routes shown on the overview map (speeds up overviews with map)
| 'pagination_max_numbers' => Define how many pages should be displayed in the pagination (in overviews)
|
*/
$config['always_show_filter'] = FALSE;
$config['show_route_filter'] = TRUE;
$config['show_route_filter_min_count'] = 5;
$config['offers_per_page'] = 10;
$config['n_th_point'] = 5;
$config['pagination_max_numbers'] = 10;
$config['overview_thumbnail_size'] = 'small';
$config['detail_thumbnail_size'] = 'medium';
$config['favorites_extension_available'] = FALSE;



/*
|--------------------------------------------------------------------------
| Languages
|--------------------------------------------------------------------------
|
| Set all available languages in your environment and your default language.
| Also specifiy if offers should be displayed or not whether it exists in the selected language
|
*/
$config['default_language'] = 'de';
$config['available_languages'] = array('de', 'fr', 'it', 'en');
$config['language_independence'] = TRUE;
$config['language_priority'] = array(
	'de' => array('fr', 'it', 'en'),
	'fr' => array('de', 'it', 'en'),
	'it' => array('fr', 'de', 'en'),
	'en' => array('de', 'fr', 'it'),
);



/*
|--------------------------------------------------------------------------
| PHP session
|--------------------------------------------------------------------------
|
*/
$config['use_sessions'] = TRUE;
$config['session_name'] = "paerke_api";



/*
|--------------------------------------------------------------------------
| Logs
|--------------------------------------------------------------------------
|
| Define the folder where log files are stored.
| Make sure this directory is writeable.
|
*/
$config['log_directory'] = "log/";



/*
|--------------------------------------------------------------------------
| Formats
|--------------------------------------------------------------------------
|
| Specify date format for PHP & MySQL
|
*/
$config['mysql_date_format'] = "%d.%m.%Y %H:%i";
$config['php_date_format'] = "d.m.Y H:i";



/*
|--------------------------------------------------------------------------
| Base URL
|--------------------------------------------------------------------------
|
*/
$config['base_url'] = "https://angebote.paerke.ch/";



/*
|--------------------------------------------------------------------------
| XML Import
|--------------------------------------------------------------------------
|
| Base url for xml import
|
*/
$config['xml_export_url'] = $config['base_url']."export/";
$config['xml_export_offer_url'] = $config['base_url']."export/xml/";
$config['xml_export_map_layer_url'] = $config['base_url']."export/xml/map_layers/";
$config['xml_export_active_offers'] = $config['base_url']."export/xml/active_offers/";