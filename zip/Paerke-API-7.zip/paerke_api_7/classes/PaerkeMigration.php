<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Migration class (database)
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeMigration {

	/**
	 * API object
	 */
	private $api;


	/**
	 * Database object
	 */
	private $db;


	/**
	 * Configuration items
	 */
	private $config;


	/**
	 * Logger object
	 */
	private $logger;


	/**
	 * Migration details
	 */
	private $version_from;
	private $version_to;



	/**
	 * Constructor
	 *
	 * @access public
	 * @param mixed $api
	 * @return void
	 */
	function __construct($api) {

		// setup api
		$this->api = $api;
		$this->config = $this->api->config;
		$this->db = new PaerkeMySQL($this->config['db_hostname'], $this->config['db_username'], $this->config['db_password'], $this->config['db_database']);
		$this->logger = new PaerkeLog();

		// version from
		$query_api = mysqli_fetch_assoc($this->db->get('api'));
		$this->version_from = intval($query_api['version']);

		// version to
		$this->version_to = API_VERSION;

		// migrate all versions
		for ($version = ($this->version_from+1) ; $version <= $this->version_to ; $version++) {
			$this->migrate($version);
		}

	}



	/**
	 * Execute migrations
	 *
	 * @access private
	 * @return void
	 */
	private function migrate($version_to) {
		if ($version_to > 0) {
			$this->logger->info('Starting migration from version '.$this->version_from.' to version '.$version_to.'...');
			switch($version_to) {

				/*
				|--------------------------------------------------------------------------
				| Migrate version 1 to version 2
				|--------------------------------------------------------------------------
				|
				*/
				case 2:
					$this->db->query("ALTER TABLE offer_route ADD PRIMARY KEY (offer_id);");
					$this->db->query("CREATE TABLE `project` (
										  `offer_id` bigint(20) NOT NULL DEFAULT '0',
										  `duration_from` int(11) DEFAULT NULL,
										  `duration_to` int(11) DEFAULT NULL,
										  `status` tinyint(1) DEFAULT NULL,
										  `poi` text,
										  PRIMARY KEY (`offer_id`),
										  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offer` (`offer_id`) ON DELETE CASCADE
										  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
					");

					// create new main category
					$this->db->insert('category', array('category_id' => CATEGORY_PROJECT, 'parent_id' => 0, 'marker' => '454545', 'sort' => 5000));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'de', 'body' => 'Projekt'));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'fr', 'body' => 'Projet'));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'it', 'body' => 'Progetto'));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'en', 'body' => 'Project'));

					// create sub categories
					$this->db->insert('category', array('category_id' => 1001, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ffcc00', 'sort' => 5010));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'de', 'body' => 'Natur / Landschaft'));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'fr', 'body' => 'Nature / paysage'));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'it', 'body' => 'Natura / Paesaggio'));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'en', 'body' => 'Nature / Landscape'));

					$this->db->insert('category', array('category_id' => 1002, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'cccccc', 'sort' => 5020));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'de', 'body' => 'Biodiversität'));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'fr', 'body' => 'Biodiversité'));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'it', 'body' => 'Biodiversità'));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'en', 'body' => 'Biodiversity'));

					$this->db->insert('category', array('category_id' => 1003, 'parent_id' => CATEGORY_PROJECT, 'marker' => '0066ff', 'sort' => 5030));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'de', 'body' => 'Landwirtschaft'));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'fr', 'body' => 'Agriculture'));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'it', 'body' => 'Agricoltura'));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'en', 'body' => 'Agriculture'));

					$this->db->insert('category', array('category_id' => 1004, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff99cc', 'sort' => 5040));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'de', 'body' => 'Forstwirtschaft'));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'fr', 'body' => 'Sylviculture'));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'it', 'body' => 'Economia forestale'));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'en', 'body' => 'Forestry'));

					$this->db->insert('category', array('category_id' => 1005, 'parent_id' => CATEGORY_PROJECT, 'marker' => '93dbff', 'sort' => 5050));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'de', 'body' => 'Energie'));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'fr', 'body' => 'Énergie'));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'it', 'body' => 'Energia'));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'en', 'body' => 'Energy'));

					$this->db->insert('category', array('category_id' => 1006, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff7b21', 'sort' => 5060));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'de', 'body' => 'Raumplanung'));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'fr', 'body' => 'Aménagement du territoire'));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'it', 'body' => 'Pianificazione territoriale'));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'en', 'body' => 'Spatial planning'));

					$this->db->insert('category', array('category_id' => 1007, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'd8d8d8', 'sort' => 5070));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'de', 'body' => 'Tourismus'));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'fr', 'body' => 'Tourisme'));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'it', 'body' => 'Turismo'));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'en', 'body' => 'Tourism'));

					$this->db->insert('category', array('category_id' => 1008, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ffff00', 'sort' => 5080));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'de', 'body' => 'Mobilität'));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'fr', 'body' => 'Mobilité'));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'it', 'body' => 'Mobilità'));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'en', 'body' => 'Mobility'));

					$this->db->insert('category', array('category_id' => 1009, 'parent_id' => CATEGORY_PROJECT, 'marker' => '00501f', 'sort' => 5090));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'de', 'body' => 'Besucherlenkung'));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'fr', 'body' => 'Gestion des visiteurs'));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'it', 'body' => 'Visite guidate'));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'en', 'body' => 'Visitor management'));

					$this->db->insert('category', array('category_id' => 1010, 'parent_id' => CATEGORY_PROJECT, 'marker' => '974807', 'sort' => 5100));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'de', 'body' => 'Zugänglichkeit'));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'fr', 'body' => 'Accessibilité '));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'it', 'body' => 'Accessibilità'));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'en', 'body' => 'Accessibility'));

					$this->db->insert('category', array('category_id' => 1011, 'parent_id' => CATEGORY_PROJECT, 'marker' => '7dd53b', 'sort' => 5110));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'de', 'body' => 'Bildung'));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'fr', 'body' => 'Education'));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'it', 'body' => 'Formazione'));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'en', 'body' => 'Education'));

					$this->db->insert('category', array('category_id' => 1012, 'parent_id' => CATEGORY_PROJECT, 'marker' => '699fd6', 'sort' => 5120));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'de', 'body' => 'Kultur'));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'fr', 'body' => 'Culture'));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'it', 'body' => 'Cultura'));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'en', 'body' => 'Culture'));

					$this->db->insert('category', array('category_id' => 1013, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'c79602', 'sort' => 5130));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'de', 'body' => 'Regionale Produkte'));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'fr', 'body' => 'Produits régionaux'));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'it', 'body' => 'Prodotti regionali'));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'en', 'body' => 'Regional products'));

					$this->db->insert('category', array('category_id' => 1014, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff00ff', 'sort' => 5140));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'de', 'body' => 'Gesundheit / Wellness'));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'fr', 'body' => 'Santé / bien-être'));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'it', 'body' => 'Benessere / wellness'));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'en', 'body' => 'Health / wellness'));

					$this->db->insert('category', array('category_id' => 1015, 'parent_id' => CATEGORY_PROJECT, 'marker' => '9b7bb4', 'sort' => 5150));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'de', 'body' => 'Nachhaltigkeit'));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'fr', 'body' => 'Durabilité'));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'it', 'body' => 'Sostenibilità'));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'en', 'body' => 'Sustainability'));

					$this->db->insert('category', array('category_id' => 1016, 'parent_id' => CATEGORY_PROJECT, 'marker' => '376091', 'sort' => 5160));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'de', 'body' => 'Dienstleistungen'));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'fr', 'body' => 'Services'));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'it', 'body' => 'Servizi'));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'en', 'body' => 'Services'));

					$this->db->insert('category', array('category_id' => 1017, 'parent_id' => CATEGORY_PROJECT, 'marker' => '7030a0', 'sort' => 5170));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'de', 'body' => 'Transnationale Projekte'));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'fr', 'body' => 'Projets transfrontaliers'));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'it', 'body' => 'Progetti transnazionali'));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'en', 'body' => 'Transnational projects'));

					// move research category
					$this->db->query("UPDATE `category` SET `category`.`sort` = 6000 WHERE `category_id` = 5000 LIMIT 1;");
					$this->db->query("UPDATE `category` SET `category`.`sort` = 6010 WHERE `category_id` = 5001 LIMIT 1;");
					$this->db->query("UPDATE `category` SET `category`.`sort` = 6020 WHERE `category_id` = 5002 LIMIT 1;");

					break;


				/*
				|--------------------------------------------------------------------------
				| Migrate version 4 to version 5
				|--------------------------------------------------------------------------
				|
				*/
				case 5:
					$this->db->query("ALTER TABLE `offer` ADD COLUMN `is_hint` TINYINT(1) AFTER `park`;");
					break;

				/*
				|--------------------------------------------------------------------------
				| Migrate version 5 to version 6
				|--------------------------------------------------------------------------
				|
				*/
				case 6:

					// create new keywords field for offers
					$this->db->query("ALTER TABLE `offer` ADD COLUMN `keywords` VARCHAR(150) AFTER `longitude`;");

					// create category: event -> presentation
					$this->db->insert('category', array('category_id' => 122, 'parent_id' => 1, 'marker' => 'ffcc00', 'sort' => 1025));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'de', 'body' => 'Vortrag'));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'fr', 'body' => 'Présentation'));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'it', 'body' => 'Presentatzione'));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'en', 'body' => 'Presentation'));

					// create category: product -> producer
					$this->db->insert('category', array('category_id' => 123, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2312));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'de', 'body' => 'Produzent'));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'fr', 'body' => 'Producteur'));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'it', 'body' => 'Produttore'));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'en', 'body' => 'Producer'));

					// create category: product -> shop for regional products
					$this->db->insert('category', array('category_id' => 124, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2314));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'de', 'body' => 'Verkauf Regionalprodukte'));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'fr', 'body' => 'Vente du produits regionaux'));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'it', 'body' => 'Vendita di prodotti regionali'));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'en', 'body' => 'Shop for regional products'));

					// create category: product -> gifts
					$this->db->insert('category', array('category_id' => 125, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2316));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'de', 'body' => 'Geschenke'));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'fr', 'body' => 'Cadeaux'));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'it', 'body' => 'Regali'));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'en', 'body' => 'Gifts'));

					// update category: product -> further
					$this->db->update('category_i18n', array('body' => 'Weitere Produkte'), array('category_id' => 27, 'language' => 'de'));

					// update category: gastronomy/accommodation -> restaurant
					$this->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'de'));
					$this->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'fr'));
					$this->db->update('category_i18n', array('body' => 'Ristorante'), array('category_id' => 28, 'language' => 'it'));
					$this->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'en'));

					// create category: gastronomy/accommodation -> cafe
					$this->db->insert('category', array('category_id' => 126, 'parent_id' => 20, 'marker' => 'ff7b21', 'sort' => 2415));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'de', 'body' => 'Cafe'));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'fr', 'body' => 'Café'));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'it', 'body' => 'Caffè'));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'en', 'body' => 'Cafe'));

					// check all cafe offers coming from restaurant
					$q_category_link = $this->db->get('category_link', array('category_id' => 28));
					if (mysqli_num_rows($q_category_link) > 0) {
						while ($row = mysqli_fetch_object($q_category_link)) {
							$this->db->insert('category_link', array('offer_id' => $row->offer_id, 'category_id' => 126));
						}
					}

					// create category: infrastructure -> swimming pool/lake
					$this->db->insert('category', array('category_id' => 127, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2631));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'de', 'body' => 'Schwimmbad/Badesee'));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'fr', 'body' => 'Piscine/Lac de baignade'));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'it', 'body' => 'Piscina/Lago balneabile'));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'en', 'body' => 'Swimming pool/Swimming lake'));

					// update category sort: infrastructure -> watersports
					$this->db->update('category', array('sort' => 2633), array('category_id' => 119));

					// create category: infrastructure -> funicular
					$this->db->insert('category', array('category_id' => 128, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2632));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'de', 'body' => 'Seilbahn'));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'fr', 'body' => 'Funiculaire'));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'it', 'body' => 'Funicolare'));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'en', 'body' => 'Funicular'));

					// create category: infrastructure -> climbing
					$this->db->insert('category', array('category_id' => 129, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2638));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'de', 'body' => 'Klettern'));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'fr', 'body' => 'Escalade'));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'it', 'body' => 'Arrampicata'));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'en', 'body' => 'Climbing'));

					// create category: infrastructure -> skating rink
					$this->db->insert('category', array('category_id' => 130, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2643));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'de', 'body' => 'Eisbahn'));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'fr', 'body' => 'Patinoire'));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'it', 'body' => 'Pista di ghiaccio'));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'en', 'body' => 'Skating rink'));

					// create category: infrastructure -> cross-country skiing
					$this->db->insert('category', array('category_id' => 131, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2647));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'de', 'body' => 'Langlauf'));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'fr', 'body' => 'Ski de fond'));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'it', 'body' => 'Sci di fondo'));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'en', 'body' => 'Cross-country skiing'));

					break;
				
				/*
				|--------------------------------------------------------------------------
				| Migrate version 6 to version 7
				|--------------------------------------------------------------------------
				|
				*/
				case 7:
					// update category: veranstaltungen
					$this->db->update('category', array('marker' => '362782'), array('category_id' => 1));
					// update sub-categories: veranstaltungen
					$this->db->update('category', array('marker' => '362782'), array('parent_id' => 1));
			
					// update category: informationen
					$this->db->update('category', array('marker' => '79BCDA'), array('category_id' => 79));
					// update sub-categories: informationen
					$this->db->update('category', array('marker' => '79BCDA'), array('parent_id' => 79));
			
					// update category: sehensw
					$this->db->update('category', array('marker' => '00625C'), array('category_id' => 22));
					// update sub-categories: sehensw
					$this->db->update('category', array('marker' => '00625C'), array('parent_id' => 22));
			
					// update category: reg prod
					$this->db->update('category', array('marker' => '1CAF8E'), array('category_id' => 19));
					// update sub-categories: reg prod
					$this->db->update('category', array('marker' => '1CAF8E'), array('parent_id' => 19));
			
					// update category: verpflegung
					$this->db->update('category', array('marker' => 'EEEFEA'), array('category_id' => 20));
					// update sub-categories: verpflegung
					$this->db->update('category', array('marker' => 'EEEFEA'), array('parent_id' => 20));
			
					// update category: beherbergung
					$this->db->update('category', array('marker' => 'F39760'), array('category_id' => 21));
					// update sub-categories: beherbergung
					$this->db->update('category', array('marker' => 'F39760'), array('parent_id' => 21));
			
					// update category: infra
					$this->db->update('category', array('marker' => 'DE7E90'), array('category_id' => 100));
					// update sub-categories: infra
					$this->db->update('category', array('marker' => 'DE7E90'), array('parent_id' => 100));
			
					// update category: pauschaulang
					$this->db->update('category', array('marker' => 'C62945'), array('category_id' => 3));
					// update sub-categories: pauschalang
					$this->db->update('category', array('marker' => 'C62945'), array('parent_id' => 3));
			
					// update category: sommerakti
					$this->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 50));
					// update sub-categories: sommerakti
					$this->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 50));
			
					// update category: winterakti
					$this->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 51));
					// update sub-categories: winterakti
					$this->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 51));
			
					// update category: forschung
					$this->db->update('category', array('marker' => '3A5BA6'), array('category_id' => 5000));
					// update sub-categories: forschung
					$this->db->update('category', array('marker' => '3A5BA6'), array('parent_id' => 5000));
			
					// update category: themenweg
					$this->db->update('category', array('marker' => 'A1BF7F'), array('category_id' => 63));
					// update sub-categories: themenweg
					$this->db->update('category', array('marker' => 'A1BF7F'), array('parent_id' => 63));
			
					// update category: wanderung
					$this->db->update('category', array('marker' => '6F9C3B'), array('category_id' => 64));
					// update sub-categories: wanderung
					$this->db->update('category', array('marker' => '6F9C3B'), array('parent_id' => 64));
			
					// update category: veloroute
					$this->db->update('category', array('marker' => '759FD1'), array('category_id' => 65));
					// update sub-categories: veloroute
					$this->db->update('category', array('marker' => '759FD1'), array('parent_id' => 65));
			
					// update category: e-bike routen
					$this->db->update('category', array('marker' => '9EBCDF'), array('category_id' => 78));
					// update sub-categories: e-bike routen
					$this->db->update('category', array('marker' => '9EBCDF'), array('parent_id' => 78));
			
					// update category: Mountainbiketour
					$this->db->update('category', array('marker' => 'FACA4D'), array('category_id' => 66));
					// update sub-categories: Mountainbiketour
					$this->db->update('category', array('marker' => 'FACA4D'), array('parent_id' => 66));
			
					// update category: reittouren
					$this->db->update('category', array('marker' => 'C09732'), array('category_id' => 82));
					// update sub-categories: reittouren
					$this->db->update('category', array('marker' => 'C09732'), array('parent_id' => 82));
			
					// update category: weitere routen
					$this->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 68));
					// update sub-categories: weitere routen
					$this->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 68));
			
					// update category: schneeschuhtour
					$this->db->update('category', array('marker' => 'C74D90'), array('category_id' => 69));
					// update sub-categories: schneeschuhtour
					$this->db->update('category', array('marker' => 'C74D90'), array('parent_id' => 69));
			
					// update category: Winterwanderung
					$this->db->update('category', array('marker' => 'F3A1C6'), array('category_id' => 70));
					// update sub-categories: Winterwanderung
					$this->db->update('category', array('marker' => 'F3A1C6'), array('parent_id' => 70));
			
					// update category: Langlaufstrecke
					$this->db->update('category', array('marker' => 'BBD0E9'), array('category_id' => 131));
					// update sub-categories: Langlaufstrecke
					$this->db->update('category', array('marker' => 'BBD0E9'), array('parent_id' => 131));
			
					// update category: Schlittelweg
					$this->db->update('category', array('marker' => 'A78373'), array('category_id' => 74));
					// update sub-categories: Schlittelweg
					$this->db->update('category', array('marker' => 'A78373'), array('parent_id' => 74));
			
					// update category: Weitere Routen
					$this->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 75));
					// update sub-categories: Weitere Routen
					$this->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 75));
					
					break;

				default:
					break;


			}

			// update db version
			$this->db->query("UPDATE `api` SET `version` = ".$version_to." LIMIT 1;");
			$this->logger->info('Migration to version '.$version_to.' successfully finished.');
		}
		else {
			$this->logger->error('No valid version number set.');
		}
	}



}
