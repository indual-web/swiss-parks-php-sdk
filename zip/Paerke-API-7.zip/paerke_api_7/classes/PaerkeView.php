<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");
require_once(ABSOLUTE_PATH."/helpers/PaerkeMapHelper.php");


/**
 * Default view class for API
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeView {

	/**
	 * API object
	 */
	private $api;

	/**
	 * Language object
	 */
	private $lang;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	function __construct($api) {
		$this->api = $api;
		$this->lang = $api->lang;

		// target groups, which won't be shown in offer detail view (target_group_id => group_name)
		$this->target_group_restrictions = array(2 => '50+');
	}


	/**
	 * Show offer filter
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_offers_filter($params = array()) {
		$fieldname = FORM_PREFIX.'filter';
		$output = '';

		$output .= '<div class="listing_search">';
		$output .= '<form action="'.$_SERVER['SCRIPT_NAME'].'" method="post" autocomplete="off">';

		// Free text search
		$output .= '
			<p class="search_text">
				<label for="'.$fieldname.'_search">'.$this->lang->get('offer_filter_search_free').'</label>
				<span class="input_wrap">
					<input type="text" name="'.$fieldname.'[search]" id="'.$fieldname.'_search"'.(isset($params['selected']['search']) ? ' value="'.(isset($params['selected']['search']) ? $params['selected']['search'] : '').'"' : '').' placeholder="'.$this->lang->get('offer_search').'..." />
					<input class="button" type="submit" value="c" />
				</span>
			</p>
		';

		// Select parks
		if (!empty($params['users']) && count($params['users']) > 1) {
			$output .= '
				<p class="select_field">
					<label for="'.$fieldname.'_park_id">'.$this->lang->get('offer_select_park').'</label>
					<span class="select_wrap">
						<select id="'.$fieldname.'_park_id" name="'.$fieldname.'[park_id]" class="select2">
							<option value="0">'.$this->lang->get('offer_parks_all').'</option>';
							foreach ($params['users'] as $park_id => $park) {
								$output .= '<option value="'.$park_id.'"'.(isset($params['selected']['park_id']) && $params['selected']['park_id'] == $park_id ? ' selected="selected"' : '').'>'.$park.'</option>';
							}
						$output .= '</select>
					</span>
				</p>
			';
		}

		// Select categories
		if (is_array($params['categories']) && !empty($params['categories'])) {
			$output .= '
				<p class="select_field biginput">
					<label for="'.$fieldname.'">'.$this->lang->get('offer_category').'</label>
					<span class="select_wrap">
						<select id="'.$fieldname.'_categories" name="'.$fieldname.'[categories][]" size="1" class="select2" multiple="multiple">';
							foreach ($params['categories'] as $label => $childs) {
								if (is_array($childs) && !empty($childs)) {
									$output .= '<optgroup label="'.$label.'">';
									foreach ($childs as $id => $category) {
										$output .= '	<option value="'.$id.'"'.(isset($params['selected']['categories']) && is_array($params['selected']['categories']) && !empty($params['selected']) && in_array($id, $params['selected']['categories']) ? ' selected="selected"' : '').'>'.$category.'</option>';
									}
									$output .= '</optgroup>';
								}
							}
						$output .= '</select>
					</span>
				</p>
			';
		}

		// Select date from
		$output .= '
			<p class="date_wrap">
				<label for="'.$fieldname.'_date_from">'.$this->lang->get('offer_date_from').'</label>
				<span class="input_wrap">
					<input class="datepicker" type="text" name="'.$fieldname.'[date_from]" id="'.$fieldname.'_date_from" class="datepicker"'.(isset($params['selected']['date_from']) && !empty($params['selected']['date_from']) ? ' value="'.$params['selected']['date_from'].'"' : '').' placeholder="'.$this->lang->get('offer_date_from').'" />
				</span>
			</p>
		';

		// Select date to
		$output .= '
			<p class="date_wrap">
				<label for="'.$fieldname.'_date_to">'.$this->lang->get('offer_date_to').'</label>
				<span class="input_wrap">
					<input class="datepicker" type="text" name="'.$fieldname.'[date_to]" id="'.$fieldname.'_date_to" class="datepicker"'.(isset($params['selected']['date_to']) && !empty($params['selected']['date_to']) ? ' value="'.$params['selected']['date_to'].'"' : '').' placeholder="'.$this->lang->get('offer_date_to').'" />
				</span>
			</p>
		';

		// Select project status
		if (isset($params['show_project_filter']) && ($params['show_project_filter'] == TRUE)) {
			$all_project_status = $this->api->config['project_status_'.$this->api->language];
			$output .= '
				<p class="select_field">
					<label for="'.$fieldname.'_project_status">'.$this->lang->get('offer_project_status').'</label>
					<span class="select_wrap">
						<select id="'.$fieldname.'_project_status" name="'.$fieldname.'[project_status]" class="select2">';
							$output .= '<option value="0"'.(!isset($params['selected']['project_status']) || ($params['selected']['project_status'] == 0) ? ' selected="selected"' : '').'>'.$this->lang->get('offer_project_status').'</option>';
							foreach ($all_project_status as $status_id => $status_label) {
								$output .= '<option value="'.$status_id.'"'.(isset($params['selected']['project_status']) && ($params['selected']['project_status'] == $status_id) ? ' selected="selected"' : '').'>'.$status_label.'</option>';
							}
						$output .= '</select>
					</span>
				</p>
			';
		}

		// Select route filter attributes
		if (isset($params['show_route_filter']) && ($params['show_route_filter'] == TRUE)) {
			$output .= '
				<div class="cf"></div>

				<p class="range_wrap">
					<label>'.$this->lang->get('offer_route_length').'</label>
					<span class="range"></span>
					<span class="range_text">
						<span class="minimum">0km</span>
						<span class="maximum">+42km</span>
						<span class="cf"></span>
					</span>
					<input type="hidden" name="'.$fieldname.'[route_length_min]" id="offer_filter_route_length_min" value="'.(isset($params['selected']['route_length_min']) ? $params['selected']['route_length_min'] : '0').'" />
					<input type="hidden" name="'.$fieldname.'[route_length_max]" id="offer_filter_route_length_max" value="'.(isset($params['selected']['route_length_max']) ? $params['selected']['route_length_max'] : '42').'"/>
				</p>

				<p class="offer_filter_time_required">
					<label for="'.$fieldname.'_time_required">'.$this->lang->get('offer_time_required').'</label>
					<select id="'.$fieldname.'_time_required" name="'.$fieldname.'[time_required]" class="select2">
						<option value="0">'.$this->lang->get('offer_time_required').'</option>';
						$times_array = array($this->lang->get('offer_time_required_2h'), $this->lang->get('offer_time_required_2_4h'), $this->lang->get('offer_time_required_4h'));
						foreach ($times_array as $time) {
							$output .= '<option value="'.$time.'"'.(isset($params['selected']['time_required']) && ($params['selected']['time_required'] == $time) ? ' selected="selected"' : '').'>'.$time.'</option>';
						}
					$output .= '</select>
				</p>

				<p class="offer_filter_level_technics">
					<label for="'.$fieldname.'_level_technics">'.$this->lang->get('offer_level_technics').'</label>
					<select id="'.$fieldname.'_level_technics" name="'.$fieldname.'[level_technics]" class="select2">
						<option value="0">'.$this->lang->get('offer_level_technics').'</option>';
						$level_array = array(1 => $this->lang->get('offer_easy'), 2 => $this->lang->get('offer_average'), 3 => $this->lang->get('offer_difficult'));
						foreach ($level_array as $level => $level_value) {
							$output .= '	<option value="'.$level.'"'.(isset($params['selected']['level_technics']) && ($params['selected']['level_technics'] == $level) ? ' selected="selected"' : '').'>'.$level_value.'</option>';
						}
					$output .= '</select>
				</p>

				<p class="offer_filter_level_condition">
					<label for="'.$fieldname.'_level_condition">'.$this->lang->get('offer_level_condition').'</label>
					<select id="'.$fieldname.'_level_condition" name="'.$fieldname.'[level_condition]" class="select2">
						<option value="0">'.$this->lang->get('offer_level_condition').'</option>';
						foreach ($level_array as $level => $level_value) {
							$output .= '	<option value="'.$level.'"'.(isset($params['selected']['level_condition']) && ($params['selected']['level_condition'] == $level) ? ' selected="selected"' : '').'>'.$level_value.'</option>';
						}
					$output .= '</select>
				</p>
			';
		}

		// Buttons
		$output .= '
			<div class="reset_box">
				<input type="submit" name="'.$fieldname.'[submit]" value="'.$this->lang->get('offer_search').'" class="button" />';
				if ($params['filter'] == TRUE) {
					$output .= '<a href="'.$_SERVER['SCRIPT_NAME'].'?reset" class="reset_button button">'.$this->lang->get('offer_reset').'</a>';
				}
				$output .= '
			</div>
		';

		$output .= '</div>';
		$output .= '</form>';

		// show output
		echo $output;
	}


	/**
	 * Show offer list
	 *
	 * @access public
	 * @param  array
	 * @param  integer
	 * @param  integer
	 * @return void
	 */
	public function show_offers_list($offers, $in_tab = FALSE, $poi = FALSE, $original_category = NULL) {
		$output = "";
		if (isset($offers['total']) && ($offers['total'] > 0) && isset($offers['data']) && !empty($offers['data'])) {

			$output .= '
				<div class="listing">
					<h6>'.$offers['total'].' '.(($offers['total'] > 1) ? $this->lang->get('offers') : $this->lang->get('offer')).'</h6>
			';

			foreach ($offers['data'] as $offer) {

				if (!empty($offer)) {

					$paramname = PARAM_PREFIX.'offer';
					$offer_detail_url = $_SERVER['SCRIPT_NAME'].(strstr($_SERVER['SCRIPT_NAME'], '?') ? '&amp' : '?').$paramname.'='.$offer->offer_id;

					// allow to get back to routes
					if ($poi) {
						$offer_detail_url .= '&amp;poi='.$poi.'&amp;original_category='.$original_category.'&amp;tab=poi';
					}

					// prepare dates
					if (isset($offer->date_from) && !empty($offer->date_from)) {
						$date_from = new DateTime($offer->date_from);
					}
					if (isset($offer->date_to) && !empty($offer->date_to)) {
						$date_to = new DateTime($offer->date_to);
					}

					// prepare categories
					$category_parent_id = (is_array($offer->categories) && !empty($offer->categories)) ? array_values($offer->categories) : NULL;
					$category_parent_id = array_shift($category_parent_id);

					// start Offer
					$output .= '<div id="offer_'.$offer->offer_id.'" class="listing_entry">';

					// favorites
					$config_favorites = isset($this->api->config['favorites_extension_available']) ? $this->api->config['favorites_extension_available'] : FALSE;
					if ($config_favorites === TRUE) {
						$output .= '<div class="favorite"><a href="">i</a></div>';
					}

					// offer image or date
					$has_image = isset($offer->images) && (count($offer->images) > 0);
					$config_thumbnail_size = isset($this->api->config['overview_thumbnail_size']) ? $this->api->config['overview_thumbnail_size'] : 'medium';
					$output .= '
						<div class="picture">
							<a href="'.$offer_detail_url.'">
								'.(($offer->is_hint) ? '<div class="tipp">'.$this->lang->get('offer_hint').'</div>' : '');

					// image
					if ($has_image == TRUE) {
						$output .= '<img class="image" src="'.$offer->images[0]->{$config_thumbnail_size}.'" alt="'.$offer->title;
						if (!empty($offer->images[0]->copyright)) {
							$output .= ' - &copy; '.$offer->images[0]->copyright;
						}
						$output .= '" />';
					}

					// date
					else {
						$output .= '<div class="date_wrap">';

						// date from
						if (isset($date_from)) {
							$output .= '
								<div class="date">
									<span>'.$date_from->format('d').'</span>
									<span>'.$this->lang->get('month'.$date_from->format('m')).'</span>
								</div>
							';
						}

						// date to
						if (isset($date_to) && ($date_from->format('dmY') != $date_to->format('dmY'))) {
							$output .= '
								<div class="date">
									<span>'.$date_to->format('d').'</span>
									<span>'.$this->lang->get('month'.$date_to->format('m')).'</span>
								</div>
							';
						}

						$output .= '</div>';
					}

					$output .= '</a></div>';

					$output .= '<div class="description">';

					// show dates
					if (isset($offer->date_from) && is_object($category_parent_id) && in_array($category_parent_id->parent_id, array(CATEGORY_EVENT, CATEGORY_RESEARCH))) {

						// date from
						$output .= '<div class="date">'.$date_from->format('d.m.Y');
						if (($date_from->format('H') != '00') || ($date_from->format('i') != '00')) {
							$output .= $date_from->format(' H:i');
						}

						// date to
						if (isset($offer->date_to)) {
							$output .= ' - ';
							if ($date_from->format('d.m.Y') != $date_to->format('d.m.Y')) {
								$output .= $date_to->format('d.m.Y');
							}
							if (($date_to->format('H') != '00') || ($date_to->format('i') != '00')) {
								$output .= $date_to->format(' H:i');
							}
						}

						$output .= '</div>';
					}

					// Offer title
					$output .= '<h3><a href="'.$offer_detail_url.'">'.$offer->title.'</a></h3>';

					// Offer description and park
					$output .= '
						<div class="intro_content">
							<p>
								<span class="park"><strong>'.$offer->park.'</strong> - '.nl2br($offer->description_medium).'
							</p>
						</div>
					';

					// Offer categories
					$output .= '<ul class="categories">';
					foreach ($offer->categories as $category) {
						$output .= '<li>'.$category->body.'</li>';
					}
					$output .= '</ul>';

					$output .= '</div>';
					$output .= '<div class="cf"></div>';
					$output .= '</div>';

				}
			}

		}
		else {

			$output .= '<p class="no_results">'.$this->lang->get('offer_not_found').'</p>';

		}

		// if true list offer inside a div for tab
		if ($in_tab) {
			return $output;
		}
		else {
			echo $output;
		}

	}


	/**
	 * Show map with offer(s)
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_pagination($page = 1, $total = 1) {

		// init
		if ($page <= 0) {
			$page = 1;
		}

		// output
		$output = '<div class="offer_pagination">';

		// previous link
		if ($page > 1) {
			$paramname = FORM_PREFIX.'page';
			$link = $_SERVER['REQUEST_URI'];

			$output .= '<div class="prev_wrap">';

			// set links
			if (strpos($_SERVER['REQUEST_URI'], $paramname)) {
				$first_link = str_replace($paramname.'='.$page, $paramname.'=1', $_SERVER['REQUEST_URI']);
				$prev_link = str_replace($paramname.'='.$page, $paramname.'='.($page-1), $_SERVER['REQUEST_URI']);
			}
			else {
				$first_link = (strstr($link, '?') ? '&' : '?').$paramname.'=1';
				$prev_link = (strstr($link, '?') ? '&' : '?').$paramname.'='.($page-1);
			}

			$output .= '
				<a href="'.$first_link.'">'.$this->lang->get('offer_first').'</a>
				<a href="'.$prev_link.'" class="icon">u</a>
			';

			$output .= '</div>';
		}

		// next page link
		if ($page < $total) {
			$paramname = FORM_PREFIX.'page';
			$link = $_SERVER['REQUEST_URI'];

			$output .= '<div class="next_wrap">';

			// set link
			if (strpos($_SERVER['REQUEST_URI'], $paramname)) {
				$last_link = str_replace($paramname.'='.$page, $paramname.'='.$total, $_SERVER['REQUEST_URI']);
				$next_link = str_replace($paramname.'='.$page, $paramname.'='.($page+1), $_SERVER['REQUEST_URI']);
			}
			else {
				$last_link = (strstr($link, '?') ? '&' : '?').$paramname.'='.$total;
				$next_link = (strstr($link, '?') ? '&' : '?').$paramname.'='.($page+1);
			}
			$output .= '
				<a href="'.$next_link.'" class="icon">u</a>
				<a href="'.$last_link.'">'.$this->lang->get('offer_last').'</a>
			';

			$output .= '</div>';
		}

		// page numbers
		if ($total > 1) {
			$paramname = FORM_PREFIX.'page';
			$pagination_max_numbers = $this->api->config['pagination_max_numbers'] ? intval($this->api->config['pagination_max_numbers']) : 5;
			$half_pages_start = floor($pagination_max_numbers/2);
			$half_pages_end = ceil($pagination_max_numbers/2)-1;
			$end = 0;

			// calculate start
			$start = intval($page - $half_pages_start);
			if ($start <= 0) {
				$start = 1;
				$end = $pagination_max_numbers;
			}
			elseif ($start < ($page - $half_pages_start)) {
				$start = ($page - $half_pages_start);
			}

			// calculate end
			if (($end == 0) || ($end > $total)) {
				$end = ($page + $half_pages_end);
				if ($end > $total) {
					if ($end == 0) {
						$start = $total - $pagination_max_numbers + 1;
					}
					$end = $total;
				}
			}

			$output .= '<div class="numbers">';
			for ($i=$start ; $i<=$end ; $i++) {

				// set link
				$link = $_SERVER['REQUEST_URI'];
				if (strpos($_SERVER['REQUEST_URI'], $paramname)) {
					$link = str_replace($paramname.'='.$page, $paramname.'='.$i, $_SERVER['REQUEST_URI']);
				}
				else {
					$link .= (strstr($link, '?') ? '&' : '?').$paramname.'='.$i;
				}
				$output .= '<a href="'.$link.'"'.(($page == $i) ? ' class="current"' : '').'>'.$i.'</a> ';

			}
			$output .= '</div>';
		}


		$output .= '</div>';

		if ($total > 1) {
			echo $output;
		}

	}


	/**
	 * Show map with offer(s)
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_offers_map($offers, $show_layers_at_start = FALSE, $map_layers = FALSE, $poi_detail = FALSE, $offer_id = FALSE) {
		$output = '<div class="offer_map_container">';

		$add_markers_function = 'var swissmap;';
		$add_markers_function .= 'function loadSwissMap() {';
		$add_markers_function .= 'swissmap = new SwissMap("#mapContainer", function() {';
		$add_markers_function .= '		var that = this;';

		// Custom map layers
		$map_layers = $this->api->offer->get_custom_layers();

		// Add custom map layers
		if (isset($map_layers) && is_array($map_layers)) {
			// Set quantity of custom layers
			$add_markers_function .= 'this.setCustomLayerQuantity('. (isset($map_layers) ? count($map_layers) : 0) .');';
			foreach ($map_layers as $layer) {

				// set popup content
				$popup = $this->_build_popup($layer);

				// add custom layers with/without layers
				$add_markers_function .= 'this.addCustomMapLayer(	"'.$layer->url.'", { id: "'.$layer->map_layer_id.'", visible: '. (($layer->visible_by_default) ? $layer->visible_by_default : 'false') .', position: '. (($layer->layer_position) ? $layer->layer_position : 0) . $popup .'});';
			}
		}

		$paramname = PARAM_PREFIX.'offer';

		$filter_data = $this->api->get_filter_data();
		$filter_categories = isset($filter_data['categories']) ? $filter_data['categories'] : array();

		$all_categories = $this->api->offer->get_all_categories();

		if (!empty($offers)) {
			$categories = array();
			$category_groups = array();
			$js_output = "";

			foreach ($offers as $offer) {

				if (isset($offer->latitude) && ($offer->latitude > 0) && isset($offer->longitude) && ($offer->longitude > 0)) {
					$offer_categories = array();

					$max_level = 0;
					if (!empty($offer->categories)) {
						foreach ($offer->categories as $category) {
							if (
								(is_object($this->api->offer) && is_object($category))
								&&
								(
									!$this->api->is_filter_activated()
									||
									count($filter_categories) == 0
									||
									in_array($category->category_id, $filter_categories)
									||
									in_array($category->parent_id, $filter_categories)
								)
							) {
								$path = $this->api->offer->get_category_path($category->parent_id);
								if (is_array($path)) {
									$path = reset($path);
								}
								$category->group = $all_categories[$path];

								if (!in_array($category->group->category_id, array(CATEGORY_PRODUCT, CATEGORY_ACTIVITY))) {

									if (count($path) > $max_level) {
										$offer_categories = array();
										$max_level = count($path);
									}

									$offer_categories[] = $category;
								}
							}
						}
					}

					$marker_id = md5($offer->offer_id);

					$date = FALSE;
					if ($offer->root_category == CATEGORY_EVENT) {
						$marker_id = md5($marker_id.$offer->date_from.$offer->date_to);

						$date_from = mysql2date($offer->date_from, true);
						$date_to = mysql2date($offer->date_to, true);
						$date = show_date(array('date_from'=>mysql2form($date_from), 'date_to' => mysql2form($date_to)));
					}

					$url = $_SERVER['REQUEST_URI'].(strstr($_SERVER['REQUEST_URI'], '?') ? '&' : '?').$paramname.'='.$offer->offer_id;
					$image = (isset($offer->images) && count($offer->images) > 0) ? $offer->images[0]->medium : FALSE;

					$position = convertLatLonToCH1903($offer->latitude, $offer->longitude);

					if (isset($offer->route)) {
						$route = array();
						foreach ($offer->route as $waypoint) {
							$point = convertLatLonToCH1903($waypoint->latitude, $waypoint->longitude);
							$route[] = '['.$point['y'].', '.$point['x'].']';
						}
						$path = '['.implode(',', $route).']';
					}

					$offer_categories_ids = array();
					foreach ($offer_categories as $offer_category) {
						$categories[intval($offer_category->sort)] = $offer_category;
						$category_groups[intval($offer_category->group->sort)] = $offer_category->group;

						$offer_categories_ids[] = $offer_category->sort;
					}

					$js_output .= '
						this.addMarkerForMultipleLayers(['.implode(",", $offer_categories_ids).'], function() {
							return {
								id: \''.$marker_id.'\',
								point: new esri.geometry.Point('.$position['y'].', '.$position['x'].', that.spatialReference),
								'.(isset($offer->route) ? ' route: new esri.geometry.Polyline({ paths: ['.$path.'], spatialReference: that.spatialReference }),' : '').'
								attributes: {
									title: \''.addslashes($offer->title).'\',
									'.($date ? ' date: \''.$date.'\',' : '');

					if (isset($offer->route_length)) {
						$js_output .= ' route_length: \''.$offer->route_length.' '.$this->lang->get('offer_route_length_km').'\',';
					}

					if (isset($offer->time_required)) {
						$js_output .= ' time_required: \''.$offer->time_required.'\',';
					}

					if (isset($offer->level_technics)) {
						$js_output .= ' level_technics: \''.$offer->level_technics.'\',';
					}

					$js_output .= '	content: '.json_encode($offer->description_medium).',
									'.($image ? ' image: \''.$image.'\',' : '').' link: \''.$url.'\'
								}
							}
						});';

				}
			}

			// create category groups
			foreach ($category_groups as $group) {
				$add_markers_function .= '		this.createOfferLayerGroup('.$group->sort.', \''.addslashes($group->body).'\', \''.$group->marker.'\');';
			}

			// create categories
			foreach ($categories as $category) {
				$add_markers_function .= '		this.createOfferLayer('.$category->sort.', \''.addslashes($category->body).'\', \''.$category->marker.'\', '.$category->group->sort.', '.($this->api->is_filter_activated() ? 'true' : 'false').');';
			}

			$add_markers_function .= $js_output;
		}

		$config = array(
			'cookieOptions' => array('expires' => 1, 'path' => $_SERVER['SCRIPT_NAME']),
			'offerLayerVisibility' => FALSE,
			'lang' => $this->lang->get_lang(),
			'hash' => $this->api->config['api_hash'],
			'base_url' => $this->api->config['base_url'],
			'type' => 'api'
		);

		if (!$poi_detail) {
			$config['cookieName'] = 'swissmap_overview';
			$config['printUrl'] = $this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'?logo=true';
			$config['resetMapExtent'] = FALSE; // set to FALSE if caching is activated
			$config['resetOfferLayerVisibility'] = TRUE;
			$config['overviewMap'] = TRUE;
		}
		else {
			$config['defaultBaseMap'] = 'pixelkarte';
			$config['cookieName'] = 'swissmap_poi_detail';
			$config['disableClustering'] = TRUE;
			$config['fitOfferExtent'] = TRUE;
			$config['offerLayerVisibility'] = TRUE;
			$config['printUrl'] = $this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'/'.$offer->offer_id.'?logo=true';
			$config['hasPoi'] = TRUE;
			$config['offerId'] = (isset($offer_id) ? $offer_id : 0);
		}

		$config_ui = array(
			'canvasWidth' => 78
		);

		if ($poi_detail) {
			$config_ui['noPrint'] = TRUE;

			if (isset($offer->route) && !empty($offer->route)) {
				$config_ui['showElevationProfile'] = TRUE;
			}
		}

		if (isset($_SESSION[$this->api->session_name]['selectedPark']) && !empty($_SESSION[$this->api->session_name]['selectedPark'])) {
			$config['selectedPark'] = $_SESSION[$this->api->session_name]['selectedPark'];
		}

		// show allways all layers on the map
		if (($this->api->is_filter_activated() === TRUE) || ($show_layers_at_start == TRUE)) {
			$config['offerLayerVisibility'] = TRUE;
		}

		if (isset($_POST[FORM_PREFIX.'filter']) && !empty($offers)) {
			$config['fitOfferExtent'] = TRUE;
		}

		if ($this->api->is_filter_activated() || isset($_SESSION['offer_detail_view']) && ($_SESSION['offer_detail_view'] == TRUE)) {
			$config['resetMapExtent'] = FALSE;
			$config['resetOfferLayerVisibility'] = FALSE;
			$config['resetMapLayerVisibility'] = FALSE;

			if ($_SESSION['offer_detail_view'] == TRUE) {
				$_SESSION['offer_detail_view'] = FALSE;
			}
		}

		$add_markers_function .= '	}, '.json_encode($config).', '.json_encode($config_ui).');';
		$add_markers_function .= '}';

		if ($poi_detail) {
			return $this->_get_detail_view_output($output, $add_markers_function);
		}
		else {
			$output .= $this->_get_swissmap_html().'

				<script type="text/javascript">
					var mapInit = false;
					$(document).ready(function() {
						var tab = $("#mapContainer").closest(".ui-tabs-panel");
						if (tab.length > 0) {
							if ($("#offer_listing_tabs").tabs("option", "selected") == 1) {
								$("div.offer_pagination").hide();
								if (!mapInit) {
									dojo.addOnLoad(function() {
										loadSwissMap();
									});
									mapInit = true;
								}
							}
							$("#offer_listing_tabs").on("tabsactivate", function(event, ui) {
								if (ui.newPanel.attr("id") == "map") {
									$("div.offer_pagination").hide();
									if (!mapInit) {
										dojo.addOnLoad(function() {
											loadSwissMap();
										});
										mapInit = true;
									}
								} else {
									$("div.offer_pagination").show();
								}
							});
							$("#offer_listing_tabs").on("tabsshow", function(event, ui) {
								if (ui.panel.id == "map") {
									$("div.offer_pagination").hide();
									if (!mapInit) {
										dojo.addOnLoad(function() {
											loadSwissMap();
										});
										mapInit = true;
									}
								} else {
									$("div.offer_pagination").show();
								}
							});
						} else {
							dojo.addOnLoad(function() {
								loadSwissMap();
							});
						}
					});
					'.$add_markers_function.'
				</script>
			</div>
			';

			echo $output;
		}
	}


	/**
	 * Show offer detail page
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_offer_detail($offer) {

		// init
		$output = '';
		$season = '';
		$_SESSION['offer_detail_view'] = TRUE;
		$poi_tab_label = ($offer->root_category != CATEGORY_PROJECT) ? $this->lang->get('offer_poi') : $this->lang->get('offer_project_links');

		// prepare dates for overviews
		if (isset($offer->dates) && !empty($offer->dates)) {
			$first_date = $offer->dates[0];
			if (isset($first_date->date_from) && !empty($first_date->date_from)) {
				$date_from = new DateTime($first_date->date_from);
			}
			$last_date = $offer->dates[ count($offer->dates)-1 ];
			if (isset($last_date->date_to) && !empty($last_date->date_to)) {
				$date_to = new DateTime($last_date->date_to);
			}
		}

		// output: buttons
		$output .= '<div class="ui_buttons">';
		if (isset($_GET["poi"])) {
			$back_button_label = (isset($_GET['original_category']) && ($_GET['original_category'] != CATEGORY_PROJECT)) ? $this->lang->get('back_to_route') : $this->lang->get('back_to_project');
			$output .= '<a class="back_to_overview" href="'.$_SERVER['SCRIPT_NAME'].(strstr($_SERVER['SCRIPT_NAME'], '?') ? '&amp' : '?').'offer='.intval($_GET["poi"]).(isset($_GET['tab']) ? ('#offer-tab-'.$_GET['tab']) : '#offer-tab-map').'">'.$back_button_label.'</a>';
		}
		else {
			$output .= '<a class="back_to_overview" href="'.$_SERVER['SCRIPT_NAME'].'">'.$this->lang->get('back_to_overview').'</a>';
		}
		$output .= '
				<a class="print reset_button button" onclick="swissmap_detail_print(\''.$this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'/'.$offer->offer_id.'?logo=true\', \''.$this->lang->get('swissmap_print_title').'\');">'.$this->lang->get('swissmap_print').'</a>
				<div class="cf"></div>
			</div>
		';

		// output heading
		$output .= '
			<div class="heading">
				<h1>'.$offer->title.'</h1>
				<div class="introduction">';

					// show offer detail
					switch ($offer->root_category) {
						case CATEGORY_EVENT:
						case CATEGORY_BOOKING:
						case CATEGORY_RESEARCH:
							if (isset($date_from)) {
								$output .= '<span>'.$this->lang->get('offer_date').':</span> '.$date_from->format('d.m.Y');
							}
							if (isset($date_to) && ($date_from->format('d.m.Y') != $date_to->format('d.m.Y'))) {
								$output .= ' - '.$date_to->format('d.m.Y');
							}
							break;
						case CATEGORY_PRODUCT:
							$season = $this->lang->get('offer_all_season');
							if (!empty($offer->available_from)) {
								$offer->available_from = new DateTime($offer->available_from);
								$season = $this->lang->get('general_from_2').' '.$offer->available_from->format('d.m.Y');
							}
							if (!empty($offer->available_to)) {
								$offer->available_to = new DateTime($offer->available_to);
								$season .= ' '.$this->lang->get('general_to').' '.$offer->available_to->format('d.m.Y');
							}
							$output .= '<span>'.$this->lang->get('offer_saison').'</span> '.$season;
							break;
						case CATEGORY_ACTIVITY:
							if (isset($offer->route_length) && !empty($offer->route_length)) {
								$output .= '<span>'.$this->lang->get('offer_route_length').':</span> '.$offer->route_length.' km ';
							}
							if (isset($offer->time_required) && !empty($offer->time_required)) {
								$output .= '<span>'.$this->lang->get('offer_time_required').':</span> '.$offer->time_required;
							}
							break;
						case CATEGORY_PROJECT:
							$output .= '';
							break;
					}

					$output .= '
				</div>
			</div>
			<div class="cf"></div>
			<div class="mix_container">
				<ul class="tags">
					<li class="filter" data-filter=".content_1">'.$this->lang->get('offer_description').'</li>
					<li class="filter" data-filter=".content_2" id="offer-li-tab-map">'.$this->lang->get('offer_map').'</li>'.
					((isset($offer->poi) && !empty($offer->poi)) ? '<li class="filter" data-filter=".content_3">'.$this->lang->get('offer_poi').'</li>' : '').'
				</ul>
				<div id="mixItUp" class="tags_content">
					<div class="content_wrapper content_1">
						<div class="content_left">
							'.$this->_get_additional_infos($offer);

							// Show detail hyperlinks
							if (isset($offer->hyperlinks) && !empty($offer->hyperlinks) && count($offer->hyperlinks) > 0) {
								$links = '';
								foreach($offer->hyperlinks as $hyperlink) {
									if (in_array($this->lang->get_lang(), explode(',', $hyperlink->language))) {
										$link_label = !empty($hyperlink->title) ? $hyperlink->title : $hyperlink->url;
										$links .= '<a href="'.$hyperlink->url.'" target="_blank">'.$link_label.'</a><br>';
									}
								}
								if (!empty($links)) {
									$output .= $this->_show_text($this->lang->get('offer_links'), '<p>'.$links.'</p>', 'portlet');
								}
							}

							$output .= '
						</div>
						<div class="content_right">';

							// Long description
							$long_description = trim($offer->description_long);
							if ($long_description == strip_tags($long_description)) {
								$output .= '
								 	<p class="description">'.nl2br($long_description).'</p>
								 ';
							}
							else {
								$output .= $long_description;
							}

							// Additional Info
							if (isset($offer->additional_informations) && !empty($offer->additional_informations)) {
								$output .= '
									<h8>'.$this->lang->get('offer_additional_info').'</h8>
									<p>'.$offer->additional_informations.'</p>
								';
							}

							$output .= '<div class="accordion_wrap">';

							// show subscription possibility
							if (isset($offer->subscription_mandatory) && ($offer->subscription_mandatory == TRUE)) {
								$output .= '
									<div class="accordion_element">
										<h2 class="accordion_title">
											'.$this->lang->get('offer_subscription').'
											<span class="icon"><span></span><span></span></span>
										</h2>
										<div class="accordion_content">'.$this->_get_detail_subscription($offer).'</div>
									</div>
								';
							}

							// show offer detail
							switch ($offer->root_category) {
								case CATEGORY_EVENT:
									$output .= $this->_get_detail_event($offer);
									break;
								case CATEGORY_PRODUCT:
									$output .= $this->_get_detail_product($offer, $season);
									break;
								case CATEGORY_BOOKING:
									$output .= $this->_get_detail_booking($offer);
									break;
								case CATEGORY_ACTIVITY:
									$output .= $this->_get_detail_activity($offer);
									break;
								case CATEGORY_PROJECT:
									$output .= $this->_get_detail_project($offer);
									break;
								case CATEGORY_RESEARCH:
									$output .= $this->_get_detail_research($offer);
									break;
							}

							$output .= '

							</div>
						</div>
						<div class="cf"></div>
					</div>
					<div id="offer-tab-map" class="content_wrapper content_2">';
						if (isset($offer->poi) && !empty($offer->poi)) {
							$output .= $this->_get_detail_map_poi($offer);
						}
						else {
							$output .= $this->_get_detail_map($offer);
						}
		$output .= '	<div class="cf"></div>';
		$output .= '</div>';

		// points of interest
		if (isset($offer->poi) && !empty($offer->poi)) {
			$output .= '
				<div id="offer-tab-poi" class="content_wrapper content_3">
					'.$this->_get_poi_content($offer->poi, $offer->offer_id, $offer->root_category).'
					<div class="cf"></div>
				</div>
			';
		}

		$output .= '</div></div>';

		echo $output;

	}


	/**
	 * Get detail description
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_additional_infos($offer) {
		$return = "";

		// Images
		$config_thumbnail_size = isset($this->api->config['detail_thumbnail_size']) ? $this->api->config['detail_thumbnail_size'] : 'medium';
		if (isset($offer->images) && is_array($offer->images) && !empty($offer->images)) {
			$return .= '
				<div class="portlet">
					<div class="pictures">';
						foreach ($offer->images as $image) {
							$return .= '
								<div class="picture">
									<a href="'.$image->large.'"'.((!empty($image->copyright)) ? ' title="&copy; '.$image->copyright.'"' : '').' rel="offer_images" class="fancybox">
										<img src="'.$image->{$config_thumbnail_size}.'" alt="'.$offer->title.'" />
										'.(!empty($image->copyright) ? '<div class="image_description">&copy; '.$image->copyright.'</div>' : '').'
									</a>
								</div>
							';
						}
			$return .= '</div></div>';
		}

		// Dates
		if (isset($offer->dates) && is_array($offer->dates) && !empty($offer->dates)) {
			$dates = '';
			foreach ($offer->dates as $date) {
				$dates .= '<br><strong>'.show_date(array('date_from'=>mysql2form($date->date_from), 'date_to' => mysql2form($date->date_to))).'</strong>';
			}
			$return .= $this->_show_text($this->lang->get('offer_dates'), $dates, 'portlet');
		}

		// Suppliers
		if (isset($offer->suppliers) && !empty($offer->suppliers)) {
			$suppliers = '';
			foreach ($offer->suppliers as $supplier) {
				if ($supplier['is_park_partner'] == 1) {
					$suppliers .= '
						<div class="partner">'.$this->lang->get('offer_park_partner').'</div>
						<p>'.$supplier['contact'].'</p>';
				}
			}
			$return .= $this->_show_text($this->lang->get('offer_supplier'), $suppliers, 'portlet');
		}

		// Institution
		if (isset($offer->institution) && !empty($offer->institution) && ($offer->institution != $offer->contact) && ($offer->root_category != CATEGORY_EVENT) && ($offer->root_category != CATEGORY_RESEARCH) && ($offer->root_category != CATEGORY_PROJECT)) {
			if ($offer->institution_is_park_partner == 1) {
				$offer->institution = '<div class="partner">'.$this->lang->get('offer_park_partner').'</div>' . $offer->institution;
			}
			$return .= $this->_show_text($this->lang->get('offer_organizer'), $offer->institution, 'portlet');
		}

		// Park
		if ($offer->root_category != CATEGORY_RESEARCH) {
			if ($offer->contact_is_park_partner == 1) {
				$offer->contact = '<div class="partner">'.$this->lang->get('offer_park_partner_booking').'</div>' . $offer->contact;
			}
			$return .= $this->_show_text($this->lang->get('offer_contact'), $offer->contact, 'portlet');
		}

		// TargetGroups
		if (isset($offer->target_groups) && is_array($offer->target_groups) && !empty($offer->target_groups)) {
			if (is_array($this->target_group_restrictions)) {
				foreach($this->target_group_restrictions as $target_group_id => $name) {
					if (array_key_exists($target_group_id, $offer->target_groups)) {
						unset($offer->target_groups[$target_group_id]);
					}
				}
			}
			$target_groups = implode("<br>", $offer->target_groups);
			$return .= $this->_show_text($this->lang->get('offer_target_group'), $target_groups, 'portlet');
		}

		// Additional info
		$additional_info = array();
		if (!empty($offer->barrier_free)) $additional_info[] = $this->lang->get('offer_barrier_free');
		if (!empty($offer->learning_opportunity)) $additional_info[] = $this->lang->get('offer_learning_opportunity');
		if (!empty($offer->child_friendly)) $additional_info[] = $this->lang->get('offer_child_friendly');
		if (!empty($offer->park_day)) $additional_info[] = $this->lang->get('offer_park_day');
		if (!empty($offer->enjoy_week)) $additional_info[] = $this->lang->get('offer_enjoy_week');
		$additional_info = (count($additional_info) > 0) ? implode("<br>", $additional_info) : '';
		$return .= $this->_show_text($this->lang->get('offer_additional_info'), $additional_info, 'portlet');

		// Documents
		if (isset($offer->documents) && (count($offer->documents) > 0)) {
			$documents = '';
			foreach ($offer->documents as $document) {
				$documents .= '<br><a href="'.$document->url.'" target="_blank">'.($document->title ? $document->title : $document->url).'</a>';
			}
			$return .= $this->_show_text($this->lang->get('offer_documents_public'), $documents, 'portlet');
		}

		return $return;
	}


	/**
	 * Get Poi content
	 * @access private
	 * @param mixed $pois
	 * @return list view with offers
	 */
	private function _get_poi_content($pois, $offer_id, $original_category) {
		$offers = $this->api->show_offer_poi_list($pois);
		$output = $this->show_offers_list($offers, true, $offer_id, $original_category);
		return $output;
	}


	/**
	 * Get detail view
	 *
	 * @access private
	 * @param mixed $return
	 * @param mixed $add_markers_function
	 * @return void
	 */
	private function _get_detail_view_output($return, $add_markers_function) {

		$return .=

			$this->_get_swissmap_html().'
			<script type="text/javascript">
				$(document).ready(function() {
					var tab = $("#mapContainer").closest(".ui-tabs-panel");
					if (tab.length > 0) {
						$("#offer_detail_tabs").on("tabsactivate", function(event, ui) {
							if (ui.newPanel.attr("id") == "offer-tab-map") {
								$("#offer_detail_tabs").off("tabsactivate");
								dojo.addOnLoad(function() {
									loadSwissMap();
								});
							}
						});
						$("#offer_detail_tabs").on("tabsshow", function(event, ui) {
							if (ui.panel.id == "offer-tab-map") {
								$("#offer_detail_tabs").off("tabsshow");
								dojo.addOnLoad(function() {
									loadSwissMap();
								});
							}
						});
						if ($(".ui-state-active a").attr("href") == "#offer-tab-map") {
							dojo.addOnLoad(function() {
								loadSwissMap();
							});
						}
					} else {
						dojo.addOnLoad(function() {
							loadSwissMap();
						});
					}
				});

				function swissmap_detail_print(url, title) {
					if ((this.swissmap != undefined) && (this.swissmap.ui != undefined)) {
						var params = this.swissmap.ui._getParamsForPrint(true);
						window.open(url+\'?\'+params, title, \'width=820,height=1140\');
					}
					else {
						window.open(url, title, \'width=820,height=1140\');
					}
				}

				'.$add_markers_function.'
			</script>
			</div>

		';

		return $return;
	}


	/**
	 * Get event detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_event($offer) {
		$return = '';

		$details = trim('
			'.$this->_show_text($this->lang->get('offer_location_details'), $offer->location_details, 'block location_details').'
			'.$this->_show_text($this->lang->get('offer_public_transport_stop'), $offer->public_transport_stop, 'block public_transport_stop').'
			'.$this->_show_text($this->lang->get('offer_date_details'), $offer->details, 'block details').'
			'.$this->_show_text($this->lang->get('offer_price'), $offer->price, 'block price').'
		');

		if (!empty($details)) {
			$return = '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_details').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">'.$details.'</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * Get product detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_product($offer, $season = '') {
		$return = '';

		// infrastructure
		$infrastructure = array();
		if (!empty($offer->number_of_rooms)) $infrastructure[] = sprintf($this->lang->get('offer_rooms'), $offer->number_of_rooms);
		if (!empty($offer->has_conference_room)) $infrastructure[] = $this->lang->get('offer_conference_room');
		if (!empty($offer->has_playground)) $infrastructure[] = $this->lang->get('offer_playground');
		if (!empty($offer->has_picnic_place)) $infrastructure[] = $this->lang->get('offer_picnic_place');
		if (!empty($offer->has_fireplace)) $infrastructure[] = $this->lang->get('offer_fireplace');
		if (!empty($offer->has_washrooms)) $infrastructure[] = $this->lang->get('offer_washroom');
		$infrastructure = (count($infrastructure) > 0) ? '<ul><li>'.implode('</li><li>', $infrastructure).'</li></ul>' : '';

		// details
		$details = trim('
			'.$this->_show_text($this->lang->get('offer_opening_hours'), $offer->opening_hours, 'block opening_hours').'
			'.$this->_show_text($this->lang->get('offer_public_transport_stop'), $offer->public_transport_stop, 'block public_transport_stop').'
			'.$this->_show_text($this->lang->get('offer_price'), $offer->price, 'block price').'
			'.$this->_show_text($this->lang->get('offer_infrastructure'), $infrastructure.$offer->other_infrastructure, 'block infrastructure').'
			'.$this->_show_text($this->lang->get('offer_saison'), $season, 'block saison').'
		');

		if (!empty($details)) {
			$return = '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_details').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">'.$details.'</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * Get booking detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_booking($offer) {
		$return = '';

		// details
		$details = trim('
			'.$this->_show_text($this->lang->get('offer_public_transport_stop'), $offer->public_transport_stop, 'block public_transport_stop').'
			'.$this->_show_text($this->lang->get('offer_benefits'), $offer->benefits, 'block benefits').'
			'.$this->_show_text($this->lang->get('offer_requirements'), $offer->requirements, 'block requirements').'
			'.$this->_show_text($this->lang->get('offer_price'), $offer->price, 'block price').'
		');
		if (!empty($details)) {
			$return .= '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_details').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">'.$details.'</div>
				</div>
			';
		}

		// accommodations
		if (isset($offer->accommodations) && !empty($offer->accommodations)) {
			$return .= '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_accommodation').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">';
					foreach ($offer->accommodations as $accommodation) {
						$return .= '<p>'.$this->_auto_text_format($accommodation, TRUE).'</p>';
					}
					$return .= '
					</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * Get activity detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_activity($offer) {
		$return = '';

		// show detail infos
		$details = trim(
			$this->_show_text($this->lang->get('offer_price'), $offer->price, 'price').'
			'.$this->_show_text($this->lang->get('offer_catering_informations'), $offer->catering_informations, 'catering_informations').'
			'.$this->_show_text($this->lang->get('offer_material_rent'), $offer->material_rent, 'material_rent').'
			'.$this->_show_text($this->lang->get('offer_safety_instructions'), $offer->safety_instructions, 'safety_instructions').'
			'.$this->_show_text($this->lang->get('offer_signalization'), $offer->signalization, 'block signalization')
		);
		$dates = '';
		if (isset($offer->dates) && is_array($offer->dates) && !empty($offer->dates)) {
			$dates = '<ul>';
			foreach ($offer->dates as $date) {
				$dates .= '<li>'.show_date(array('date_from'=>mysql2form($date->date_from), 'date_to' => mysql2form($date->date_to))).'</li>';
			}
			$dates .= '</ul>';
		}
		$details .= $dates;
		if (!empty($details)) {
			$return .= '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_details').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">'.$details.'
					</div>
				</div>
			';
		}

		// show route details
		$return .= '
			<div class="accordion_element">
				<h2 class="accordion_title">
					'.$this->lang->get('offer_start_place').' / '.$this->lang->get('offer_goal_place').'
					<span class="icon"><span></span><span></span></span>
				</h2>
				<div class="accordion_content">
					<table class="special_table">
						<tr>
							<th>'.$this->lang->get('offer_start_place').'</th>
							<th></th>
						</tr>
						'.$this->_get_string($offer->start_place_info, '</td></tr>', '<tr><td>'.$this->lang->get('offer_start_place').'</td><td>').'
						'.$this->_get_string($offer->public_transport_start, '</td></tr>', '<tr><td>'.$this->lang->get('offer_public_transport_stop').'</td><td>').'
						'.$this->_get_string($offer->start_place_altitude, ' '.$this->lang->get('offer_altitude_meter').'</td></tr>', '<tr><td>'.$this->lang->get('offer_altitude').'</td><td>').'
					</table>
					<table class="special_table">
						<tr>
							<th>'.$this->lang->get('offer_goal_place').'</th>
							<th></th>
						</tr>
						'.$this->_get_string($offer->goal_place_info, '</td></tr>', '<tr><td>'.$this->lang->get('offer_goal_place').'</td><td>').'
						'.$this->_get_string($offer->public_transport_stop, '</td></tr>', '<tr><td>'.$this->lang->get('offer_public_transport_stop').'</td><td>').'
						'.$this->_get_string($offer->goal_place_altitude, ' '.$this->lang->get('offer_altitude_meter').'</td></tr>', '<tr><td>'.$this->lang->get('offer_altitude').'</td><td>').'
					</table>
					<div class="cf"></div>
				</div>
			</div>

			<div class="accordion_element">
				<h2 class="accordion_title">
					'.$this->lang->get('offer_route_info').'
					<span class="icon"><span></span><span></span></span>
				</h2>
				<div class="accordion_content">
					<table>
						<tr>
							<th>'.$this->lang->get('offer_route_info').'</th>
							<th></th>
						</tr>
						'.$this->_get_string($offer->route_length, ' '.$this->lang->get('offer_route_length_km').'</td></tr>', '<tr><td>'.$this->lang->get('offer_route_length').'</td><td>').'
						'.$this->_get_string($offer->untarred_route_length, ' '.$this->lang->get('offer_route_length_km').'</td></tr>', '<tr><td>'.$this->lang->get('offer_untarred_route_length').'</td><td>').'
						'.$this->_get_string($offer->altitude_differential, ' '.$this->lang->get('offer_altitude_meter').'</td></tr>', '<tr><td>'.$this->lang->get('offer_altitude_differential').'</td><td>').'
						'.$this->_get_string($offer->altitude_ascent, ' '.$this->lang->get('offer_altitude_meter').'</td></tr>', '<tr><td>'.$this->lang->get('offer_altitude_ascent').'</td><td>').'
						'.$this->_get_string($offer->altitude_descent, ' '.$this->lang->get('offer_altitude_meter').'</td></tr>', '<tr><td>'.$this->lang->get('offer_altitude_descent').'</td><td>').'
						'.$this->_get_string($offer->time_required, '</td></tr>', '<tr><td>'.$this->lang->get('offer_time_required').'</td><td>').'
						'.$this->_get_string($this->api->offer->levels[$offer->level_technics], '</td></tr>', '<tr><td>'.$this->lang->get('offer_level_technics').'</td><td>').'
						'.$this->_get_string($this->api->offer->levels[$offer->level_condition], '</td></tr>', '<tr><td>'.$this->lang->get('offer_level_condition').'</td><td>').'
					</table>
				</div>
			</div>
		';

		// show infrastructure infos
		$infrastructure = array();
		if (!empty($offer->has_playground)) $infrastructure[] = $this->lang->get('offer_playground');
		if (!empty($offer->has_picnic_place)) $infrastructure[] = $this->lang->get('offer_picnic_place');
		if (!empty($offer->has_fireplace)) $infrastructure[] = $this->lang->get('offer_fireplace');
		if (!empty($offer->has_washrooms)) $infrastructure[] = $this->lang->get('offer_washroom');
		if (!empty($infrastructure)) {
			$return .= '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_infrastructure').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">';
						$infrastructure = (count($infrastructure) > 0) ? '<ul><li>'.implode('</li><li>', $infrastructure).'</li></ul>' : '';
						$return .= $this->_show_text('', $infrastructure.$offer->other_infrastructure, 'infrastructure').'
					</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * Get project detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_project($offer) {
		$return = '';

		// duration
		$duration = '';
		if (isset($offer->duration_from) && ($offer->duration_from > 0)) {
			if ($offer->duration_from != $offer->duration_to) {
				$duration .= $this->lang->get('offer_from').' ';
			}
			$duration .= '<strong>'.$offer->duration_from.'</strong>';
			if ($offer->duration_from != $offer->duration_to) {
				$duration .= ' '.$this->lang->get('offer_to').' <strong>'.$offer->duration_to.'</strong>';
			}
			$return .= $this->_show_text($this->lang->get('offer_project_duration'), $duration, 'block');
		}

		// status
		if ($offer->project_status > 0) {
			$all_project_status = $this->api->config['project_status_'.$this->api->language];
			$return .= $this->_show_text($this->lang->get('offer_project_status'), $all_project_status[ $offer->project_status ], 'block');
		}

		// institution
		$return .= $this->_show_text($this->lang->get('offer_project_responsibility'), $offer->institution, 'block address');

		return $return;
	}


	/**
	 * Get research detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_research($offer) {
		$return = '';

		$details = trim('
			'.$this->_show_text($this->lang->get('offer_research_responsibility'), $offer->institution, 'block address').'
			'.$this->_show_text($this->lang->get('offer_contact'), $offer->institution, 'block address').'
		');

		if (!empty($details)) {
			$return .= '
				<div class="accordion_element">
					<h2 class="accordion_title">
						'.$this->lang->get('offer_details').'
						<span class="icon"><span></span><span></span></span>
					</h2>
					<div class="accordion_content">'.$details.'
					</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * get overview map with POI elements
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_map_poi($offer) {

		// merge offer with poi offer
		$offers = $this->api->show_offer_poi_list($offer->poi);

		// call overview and return content
		if (!empty($offers)) {
			array_push($offers, $offer);
			return $this->show_offers_map($offers, NULL, NULL, TRUE, $offer->offer_id);
		}
	}



	/**
	 * Get detail map
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_map($offer) {
		if (!empty($offer)) {

			$return = "";

			$return .= '<div class="offer_map_container">';

			$add_markers_function = 'var swissmap;';
			$add_markers_function .= 'function loadSwissMap() {';
			$add_markers_function .= '	swissmap = new SwissMap("#mapContainer", function() {';
			$add_markers_function .= '		var that = this;';


			// Custom Map Layers
			$map_layers = $this->api->offer->get_custom_layers();


			// Add custom map layers
			if (isset($map_layers) && is_array($map_layers)) {
				// Set quantity of custom layers
				$add_markers_function .= 'this.setCustomLayerQuantity('. (isset($map_layers) ? count($map_layers) : 0) .');';
				foreach ($map_layers as $layer) {
					$popup = $this->_build_popup($layer);
					$add_markers_function .= 'this.addCustomMapLayer("'.$layer->url.'", { id: "'.$layer->map_layer_id.'", position: '. (($layer->layer_position) ? $layer->layer_position : 0). ', visible: '. (($layer->visible_by_default) ? $layer->visible_by_default : 'false'). $popup .' });';
				}
			}

			$paramname = PARAM_PREFIX.'offer';

			$all_categories = $this->api->offer->get_all_categories();

			$offer_category = NULL;
			$offer_category_group = NULL;
			$current_level = 0;
			if (isset($offer->categories) && !empty($offer->categories)) {
				foreach ($offer->categories as $category) {
					$path = $this->api->offer->get_category_path($category->parent_id);

					if (count($path) > $current_level) {
						$offer_category_group = $all_categories[reset($path)];
						$offer_category = $category;
						$current_level = count($path);
					}
				}
			}

			$add_markers_function .= '		var marker;';
			$add_markers_function .= '		this.createOfferLayerGroup('.$offer_category_group->sort.', \''.addslashes($offer_category_group->body).'\');';
			$add_markers_function .= '		this.createOfferLayer('.$offer_category->category_id.', \''.addslashes($offer_category->body).'\', \''.$offer_category->marker.'\', '.$offer_category_group->sort.');';

			if ($offer->latitude > 0 && $offer->longitude > 0) {
				$position = convertLatLonToCH1903($offer->latitude, $offer->longitude);

				if (isset($offer->route) && !empty($offer->route)) {
					$route = array();
					foreach ($offer->route as $waypoint) {
						$point = convertLatLonToCH1903($waypoint->latitude, $waypoint->longitude);
						$route[] = '['.$point['y'].', '.$point['x'].']';
					}
					$path = '['.implode(',', $route).']';
				}

				$add_markers_function .= '		this.addMarkerForLayer('.$offer_category->category_id.', function() { return { point: new esri.geometry.Point('.$position['y'].', '.$position['x'].', that.spatialReference),'.((isset($offer->route) && !empty($offer->route)) ? ' route: new esri.geometry.Polyline({ paths: ['.$path.'], spatialReference: that.spatialReference }),' : '').' symbol: \''.$offer_category->marker.'\' } });';
			}

			$config = array(
				'defaultBaseMap' => 'pixelkarte',
				'cookieName' => 'swissmap_detail',
				'cookieOptions' => array('expires' => 1, 'path' => $_SERVER['SCRIPT_NAME']),
				'offerLayerVisibility' => TRUE,
				'disableClustering' => TRUE,
				'fitOfferExtent' => TRUE,
				'lang' => $this->lang->get_lang(),
				'hash' => $this->api->config['api_hash'],
				'base_url' => $this->api->config['base_url'],
				'type' => 'api',
				'printUrl' => $this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'/'.$offer->offer_id.'?logo=true'
			);

			$config_ui = array(
				'canvasWidth' => 78,
				'sidebarVisible' => FALSE,
				'noPrint' => TRUE
			);

			if (isset($_SESSION[$this->api->session_name]['selectedPark']) && !empty($_SESSION[$this->api->session_name]['selectedPark'])) {
				$config['selectedPark'] = $_SESSION[$this->api->session_name]['selectedPark'];
			}

			if (isset($offer->route) && !empty($offer->route)) {
				$config_ui['showElevationProfile'] = TRUE;
			}

			$add_markers_function .= '	}, '.json_encode($config).', '.json_encode($config_ui).');';
			$add_markers_function .= '}';

			return $this->_get_detail_view_output($return, $add_markers_function);
		}
	}


	/**
	 * Get subscription detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_subscription($offer) {

		$return = '
			<p>
				'.(($offer->subscription_mandatory == 2) ? $this->lang->get('offer_subscription_info_recommended') : $this->lang->get('offer_subscription_info_mandatory')).'
			</p>
		';

		// subscription contact
		if (!empty($offer->subscription_contact)) {
			$return .= '
				<p>
					<strong>'.$this->lang->get('offer_subscription_contact').':</strong>
					<br>'.$this->_auto_text_format($offer->subscription_contact).'
				</p>
			';
		}

		// subscription details
		if (!empty($offer->subscription_details)) {
			$return .= '
				<p>
					<strong>'.$this->lang->get('offer_subscription_details').':</strong>
					<br>'.$offer->subscription_details.'
				</p>
			';
		}

		// subscription link
		if (!empty($offer->subscription_link)) {
			$return .= '
				<p>
					<button class="button" type="button" name="subscribe_now" onclick="window.open(\''.$offer->subscription_link.'\');">'.$this->lang->get('offer_subscription_subscribe_now').'</button>
				</p>
			';
		}

		// subscribe now button
		if ($offer->online_subscription_enabled == 1) {
			$return .= '
				<p>
					<button class="button" type="button" name="subscribe_now" onclick="window.open(\''.$this->api->config['base_url'].'subscription/subscriber/'.$offer->offer_id.'\');">'.$this->lang->get('offer_subscription_subscribe_now').'</button>
				</p>
			';
		}

		return $return;
	}


	/**
	 * Returns HTML required for displaying the SwissMap
	 *
	 * @access private
	 * @return string
	 */
	private function _get_swissmap_html() {
		$output  = '

			<div id="mapContainer">
				<div class="mapToolbar">
					<div class="mapToolbarSelects">
						<select class="mapBasemapSelect" name="basemapSelect">
							<option value="0">'.$this->lang->get('swissmap_basemap').'</option>
						</select>
						<select class="mapParkSelect" name="parkSelect" style="display: none">
							<option value="all">'.$this->lang->get('swissmap_select_all_parks').'</option>
						</select>
					</div>
					<div class="mapToolbarSearch">
						&nbsp;<input class="mapSearchInput" type="text" name="searchInput" value="'.$this->lang->get('swissmap_search').'" />
					</div>
					<div class="mapToolbarButtons">
					</div>
					<div class="cf"></div>
				</div>
				<div style="position: relative">
					<div id="mapCanvasContainer" class="mapCanvasContainer">
						<div id="mapCanvas" class="mapCanvas">
							<div class="mapLoading">'.$this->lang->get('swissmap_loading').'</div>
							<div class="mapControls">
								<div class="mapButton mapHomeButton"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAABRCAYAAACqj0o2AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAV5JREFUeNrs3MERgyAUhGHYsYCUko60s9hRSjIXM+Mt0UV9wL8XvHDgmwfMKJiXZUnEiyDoA/EJopcppfRe27AZggO+1udvO//os3eBzy1X4hYwbSAnpvNxwNCQqggwLKQqAwwJqQoBw0FG2J3nlNJ4sO+/u3bTlegAhqnIoXLALeTjroHkm15AlAS0xl/rdI4CWO2a2Bzg1YhNAl6J2CzgVYhNA16B2Dzg2YhdAJ6J2A3gWYhdAZ6B2B1gacQuAUsi1go4R0GsuQLHEpBiCvuQ6hywCKQA9CEFoA8pAH1IAehDCkAfUgD6kALQhxSAPqQA9CEFoA8pAH1IAehDCkAfcgDQhjx0KqyHe2y7TotxLa1AQAQRRBAJiCCCCCIBEcS4ifL7Audm00IlMp0JiCCCCCIBEUQQQSQggggiiAREEEEEkYAIIoggEhBvy5HvzjnYGDKV2EA+AAAA//8DADP5T1QSIe8+AAAAAElFTkSuQmCC"/></div>
								<div class="mapButton mapZoomInButton"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAABRCAYAAACqj0o2AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAKtJREFUeNrs3TEKACEMAEEj/v/LsbUVm6izL5AhKQ6Ui8xsOqsjOG8UO8/OWoRJtM6CCBEiREGECBGiIEKECFEQIUKEKIgQIUIURIgQBREiRIiCCBHiq62XPG+7d1zhvGESrTNEiIIIESJEQYR4z2dfhbdy3vZZZ0GECFEQIUKEKIgQIUIURIgQIQoiRIgQBREiRIiCCBEiREGECFGt3g8cwiR+2gQAAP//AwCEcweowhIlcgAAAABJRU5ErkJggg=="/></div>
								<div class="mapZoomSlider"></div>
								<div class="mapButton mapZoomOutButton">
			<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAABRCAYAAACqj0o2AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAJhJREFUeNrs2iEOACAMBEFK+P+XDwmWoCCzqnrSChIqSdNdHQFEiBAFESJEiIIIESJEQYQIEaIgQoQIURAhQoQoiBAhCiJEiBAFESLELxvb7N/xeWUTnTNEiIIIESJEQYT4zrOvcNhEiBAhCiJEiIIIESJEQYQIEaIgQoQIURAhQoQoiBAhQhREiBAFESJEiFpNAAAA//8DAJ77BKS17yGaAAAAAElFTkSuQmCC"/>

			</div>
							</div>
							<div class="mapCopyright">
								<p>&copy; Netzwerk Schweizer Pärke<br>
								'.$this->lang->get('swissmap_source_swisstopo').'</p>
							</div>
							<div id="mapOverview"></div>
							<div class="mapOverviewToggle ui-icon ui-icon-triangle-1-se"></div>
						</div>
						<div class="cf"></div>
						<div id="mapElevationChart"></div>
						<div class="cf"></div>
						<div id="distanceTitleText"></div>
					</div>
					<div class="mapSidebar" style="display: none">
						<div class="mapInformation">
							<div class="inner">
								<h3 class="section_header" data-rel="mapPrint">'.$this->lang->get('swissmap_print').'</h3>
								<div class="mapPrint section">
									<div class="mapPrintClose"></div>
									<div class="mapPrintActions">
										<button class="mapPrintButton">'.$this->lang->get('swissmap_print_select_section').'</button>
										<button class="mapPrintCancel">'.$this->lang->get('swissmap_cancel').'</button>
										<button class="mapPrintPreview">'.$this->lang->get('swissmap_print').'</button>
									</div>
								</div>
								<h3 class="section_header" data-rel="mapTools">'.$this->lang->get('swissmap_tools').'</h3>
								<div class="mapTools section">
									<div class="mapToolsMeasurement">
										<input type="radio" name="mapToolsTool" value="none" checked="checked" id="mapToolsNone" class="mapToolsNone" /><label for="mapToolsNone">'.$this->lang->get('swissmap_tools_none').'</label>
										<input type="radio" name="mapToolsTool" value="point" id="mapToolsPoint" class="mapToolsPoint" /><label for="mapToolsPoint">'.$this->lang->get('swissmap_tools_point').'</label>
										<input type="radio" name="mapToolsTool" value="distance" id="mapToolsDistance" class="mapToolsDistance" /><label for="mapToolsDistance">'.$this->lang->get('swissmap_tools_distance').'</label>
										<input type="radio" name="mapToolsTool" value="area" id="mapToolsArea" class="mapToolsArea" /><label for="mapToolsArea">'.$this->lang->get('swissmap_tools_area').'</label>
									</div>
									<div class="mapToolsMeasurementResult">'.$this->lang->get('swissmap_tools_choose_tool').'</div>
								</div>
								<h3 class="section_header" data-rel="mapOffers">'.$this->lang->get('swissmap_offers').'</h3>
								<div class="mapOffers section">
								</div>
								<h3 class="section_header" data-rel="mapPoi" style="display:none">'.$this->lang->get('swissmap_poi').'</h3>
								<div class="mapPoi section" style="display:none">
								</div>
								<h3 class="section_header" data-rel="mapLayers">'.$this->lang->get('swissmap_baseinfo').'</h3>
								<div class="mapLayers section">
								</div>
								<h3 class="active coordinates_header">'.$this->lang->get('swissmap_coordinates').'</h3>
								<div class="mapInfo section">
									<div class="mapInfoCoordinates"></div>
									<a href="#" class="mapHelpButton">'.$this->lang->get('swissmap_help').'</a>
								</div>
							</div>
						</div>
						<div class="mapToggleLayersButton"><span></span></div>
					</div>
				</div>
				<div class="mapLegend">
					<div class="inner">
						<h3 class="mapLegendTitle"></h3>
						<div class="mapLegendContent"></div>
						<div class="mapLegendDescription"></div>
					</div>
				</div>
				<div class="cf"></div>
			</div>

		';

		return $output;
	}


	/**
	 * Get string
	 *
	 * @access private
	 * @param mixed $string
	 * @param string $suffix (default: "")
	 * @param string $prefix (default: "")
	 * @return void
	 */
	private function _get_string($string, $suffix = "", $prefix = "") {
		if (!empty($string)) {
			return $prefix.$string.$suffix;
		}

		return "";
	}


	/**
	 * Truncate string
	 *
	 * @access private
	 * @param mixed $string
	 * @param mixed $length
	 * @return void
	 */
	private function _truncate_string($string, $length) {
		if (mb_strlen($string) > $length) {
			return mb_substr($string, 0, $length)."...";
		}

		return $string;
	}


	/**
	 * Prepare detail block
	 *
	 * @access private
	 * @param mixed $title
	 * @param mixed $content
	 * @param string $class (default: "")
	 * @return void
	 */
	private function _show_text($title, $content, $class = "") {

		$return = "";

		// check html tags
		$has_html = FALSE;
		if ($content != strip_tags($content)) {
			$has_html = TRUE;
		}

		// output
		if (!empty($content)) {
			$return .= '
				<div class="'.$class.'">
					<div class="description">
						'.(!empty($title) ? '<h7>'.$title.'</h7>' : '').
						(($has_html == TRUE) ? $content : $this->_auto_text_format($content)).'
					</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * Auto text format
	 *
	 * @access private
	 * @param mixed $string
	 * @return void
	 */
	private function _auto_text_format($string, $first_line_strong = FALSE) {

		// init
		$return = '';
		$html_tags = array('ul', 'li', 'ol', 'dl', 'dd');
		$is_first_line = TRUE;

		$new_lines = explode("\n", $string);
		foreach ($new_lines as $line) {
			if (($first_line_strong == TRUE) && ($is_first_line == TRUE)) {
				$return .= '<strong>';
			}
			if (substr($line, 0, 7) == 'http://' || substr($line, 0, 8) == 'https://') {
				$return .= '<a href="'.$line.'" target="_blank">'.str_replace(array('http://', 'https://'), '', $line).'</a>';
			}
			else if (!preg_match("/\<(".implode("|", $html_tags).")\>/i", $line) && !empty($line)) {
				$return .= $line.'<br>';
			}
			else {
				$return .= $line;
			}
			if (($first_line_strong == TRUE) && ($is_first_line == TRUE)) {
				$return .= '</strong>';
				$first_line_strong = FALSE;
			}
		}

		return $return;
	}


	/**
	 * Build popup of custom layer
	 *
	 * @access private
	 * @param mixed $layer
	 * @return void
	 */
	private function _build_popup($layer) {

		$popup = ', popup: { ';

		// set title
		$popup .= isset($layer->popup_title) ? ('title: "'. $layer->popup_title .'", ') : NULL;

		// set logo with size
		if (isset($layer->popup_logo)) {
			$popup .= 'logo: "'. $this->api->config['base_url'].$layer->popup_logo .'", ';
			$popup .= (isset($layer->popup_logo_width) && ($layer->popup_logo_width > 0)) ? ('logo_width: "'. $layer->popup_logo_width .'",  ') : 'width : "auto",';
			$popup .= (isset($layer->popup_logo_height) && ($layer->popup_logo_height > 0)) ? ('logo_height: "'. $layer->popup_logo_height .'",  ') : 'height :"auto",';
		}

		// show new lines
		if (isset($layer->popup_content)) {
			foreach ($layer->popup_content as $key => $popup_content) {
				$layer->popup_content[$key] = nl2br($popup_content);
			}
		}

		// set content
		$popup .= isset($layer->popup_content) ? ('content: '. json_encode($layer->popup_content) .' ') : '';
		$popup .= ' }';

		return $popup;

	}


	/*
	 * Helper func: Transform mysql date to readable version
	 *
	 * @access public
	 * @param string
	 * @param bool
	 * @param bool
	 */
	public function mysql2date($mysql_date, $time = false, $ts = false) {
		$date = mb_substr($mysql_date, 0, 10);
		$date_time = '';
		if ($time != false) {
			$date_time = ' '.mb_substr($mysql_date, 11, 5);
		}

		$date_explode = explode("-", $date);

		if (count($date_explode) < 3 || (intval($date_explode[0]) == 0) && (intval($date_explode[1]) == 0) && (intval($date_explode[2]) == 0)) {
			return '';
		}

		$date_explode_ts = mktime(0, 0, 0, $date_explode[1], $date_explode[2], $date_explode[0]);
		if ($ts == true) {
			return $date_explode_ts;
		}
		return '<strong>'.date('d.m.Y', $date_explode_ts).'</strong>'.$date_time;
	}

}
