<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| Constants and Configuration items
|
*/


/**
 * API Version
 * -------------------------------------------------
 */
define('API_VERSION', '1.0.26');


/**
 * Your default language
 * -------------------------------------------------
 */
define('DEFAULT_LANGUAGE', 'de');


/**
 * Global configuration for Paerke.ch API
 */
$config = array();


/**
 * API Hash Key
 * -------------------------------------------------
 * This hash is needed to import the data from XML
 * You can obtain a valid hash from angebote.paerke.ch
 */
$config['api_hash'] = "your-export-hash-key";


/**
 * MySQL Database
 * -------------------------------------------------
 * A MySQL Database is required to use the API. Imported
 * offers will be stored there for better performance.
 */
$config['db_hostname'] = "localhost";
$config['db_username'] = "root";
$config['db_password'] = "root";
$config['db_database'] = "paerke_api";


/**
 * Custom classes
 * -------------------------------------------------
 * Here you can configure custom classes for the view, for example "MyView"
 */
$config['class_view'] = "";


/**
 * Languages
 * -------------------------------------------------
 * Specify which languages should be enabled (currently supported are de, fr and it)
 * Also specifiy if offers should be displayed or not whether it exists in the selected language
 */
$config['available_languages'] = array('de', 'fr', 'it', 'en');
$config['language_independence'] = TRUE;


/**
 * PHP Session
 * -------------------------------------------------
 */
$config['use_sessions'] = TRUE;
$config['session_name'] = "paerke_api";


/**
 * Logging
 * -------------------------------------------------
 * Make sure this directory is writeable, otherwise no logs will be generated
 */
$config['log_directory'] = "log/";


/**
 * Formats
 * -------------------------------------------------
 * Specify date format for PHP & MySQL
 */
$config['mysql_date_format'] = "%d.%m.%Y %H:%i";
$config['php_date_format'] = "d.m.Y H:i";


/**
 * Base URL
 * -------------------------------------------------
 */
$config['base_url'] = "http://angebote.paerke.ch/";


/**
 * XML Import
 * -------------------------------------------------
 * Base url for xml import
 */
$config['xml_export_url'] = $config['base_url']."export/";
$config['xml_export_offer_url'] = $config['base_url']."export/xml/";
$config['xml_export_map_layer_url'] = $config['base_url']."export/xml/map_layers/";
$config['xml_export_active_offers'] = $config['base_url']."export/xml/active_offers/";


/**
 * Custom view options
 * -------------------------------------------------
 * 'always_show_filter' = Show filter on detail pages
 * 'show_route_filter' => Show route filter
 * 'show_route_filter_min_count' => Define minimum activities for route filter
 * 'offers_per_apge' = How many offers should be displayed per page?
 */
$config['always_show_filter'] = FALSE;
$config['show_route_filter'] = TRUE;
$config['show_route_filter_min_count'] = 5;
$config['offers_per_page'] = 10;


/**
 * Constants
 * -------------------------------------------------
 */
define('CATEGORY_EVENT', 1);
define('CATEGORY_PRODUCT', 2);
define('CATEGORY_BOOKING', 3);
define('CATEGORY_ACTIVITY', 4);
define('CATEGORY_RESEARCH', 5000);

define('OFFER_STATUS_STUB', 0);
define('OFFER_STATUS_INACTIVE', 1);
define('OFFER_STATUS_ACTIVE', 2);

define('FORM_PREFIX', '');
define('PARAM_PREFIX', '');