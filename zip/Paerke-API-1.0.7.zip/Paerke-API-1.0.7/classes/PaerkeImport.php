<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Class for importing XML data into database
 *
 * @author indual GmbH
 * @version 1.0.2
 * @copyright 2012 by indual GmbH
 */
class PaerkeImport {

	/**
	 * Database object
	 */
	private $db;


	/**
	 * Logger object
	 */
	private $logger;


	/**
	 * XML object containing all data
	 */
	private $xml;


	/**
	 * Necessary Key-Value mappings for XML data
	 */
	private $mappings;


	/**
	 * Constructor
	 */
	function __construct() {

		global $config;
		$this->db = new PaerkeMySQL($config['db_hostname'], $config['db_username'], $config['db_password'], $config['db_database']);
		$this->logger = new PaerkeLog();

		// setup mappings necessary for XML import
		$this->mappings = array(
			'langs' => array(
				'de' => 'de',
				'fr' => 'fr',
				'it' => 'it',
				'en' => 'en'
			),
			'levels' => array(
				'' 			=> 0,
				'easy' 		=> 1,
				'medium' 	=> 2,
				'hard' 		=> 3
			)
		);
	}


	/**
	 * Method for importing xml data into database
	 *
	 * @param url Location of XML file
	 * @param force Forces import of all offers (including those who haven't changed)
	 * @return boolean
	 */
	public function import($url, $force = FALSE) {

		if (empty($url)) {
			$this->logger->error("No URL for XML file specified");
			die("No URL for XML file specified");
		}

		// Add param to url with last import timestamp
		if ($force !== TRUE) {
			$api_info = mysql_fetch_assoc($this->db->get('api'));
			$last_import = $api_info['last_import'];
			if (!empty($last_import)) {
				$url .= '?since='.$last_import;
			}
			else {
				$force = TRUE;
				$this->logger->info("Enabling FORCE mode because timestamp for last import is empty");
			}
		}
		else {
			$this->logger->info("FORCE mode is enabled");
		}

		$this->xml = simplexml_load_file($url);

		if ($this->xml !== FALSE) {

			$this->logger->info("Starting XML import from ".$url."…");
			$ctr_imported = 0;
			$ctr_deleted = 0;

			$offers_checklist = array();

			if (count($this->xml->Offer) > 0) {
				// Temp: Remove every category link
				// $this->db->delete('category_link');

				// import every offer
				foreach ($this->xml->Offer as $offer) {
					$offer_id = intval($offer->attributes()->identifier);
					$deleted_at = $offer->attributes()->deletedAt;
					$status = $offer->attributes()->status;

					// check if offer should be deleted
					if (!empty($deleted_at) || $status != OFFER_STATUS_ACTIVE) {
						if ($force !== TRUE) {
							// delete offer from db and continue
							$this->db->delete('offer', array('offer_id' => $offer_id));
							$this->logger->info("\tDeleted offer with ID ".$offer_id);
							$ctr_deleted++;
						}

						continue;
					}

					// Offer
					$fields = array();

					$fields['park_id'] = (int)$offer->ParkId;
					$fields['park'] = (string)$offer->Park;
					$fields['institution'] = $this->_address($offer->Institution);
					$fields['contact'] = $this->_address($offer->Contact);

					$fields['barrier_free'] = (int)$offer->BarrierFree;
					$fields['learning_opportunity'] = (int)$offer->LearningOpportunity;
					$fields['child_friendly'] = (int)$offer->ChildFriendly;
					$fields['park_day'] = (int)$offer->ParkDay;
					$fields['enjoy_week'] = (int)$offer->EnjoyWeek;

					$fields['latitude'] = (float)$offer->Latitude;
					$fields['longitude'] = (float)$offer->Longitude;

					$fields['created_at'] = $this->_datetime($offer->attributes()->createdAt);
					$fields['modified_at'] = $this->_datetime($offer->attributes()->modifiedAt);


					// error handling
					if (!$this->_insert_or_update('offer', $fields, array('offer_id' => $offer_id))) {
						$this->logger->error("MySQL Error: ".$this->db->get_last_error());
						continue;
					}


					// Categories
					$this->db->delete('category_link', array('offer_id' => $offer_id));
					foreach ($offer->Categories->Category as $category) {
						$category_id = $category->attributes()->identifier;
						$this->db->insert('category_link', array('offer_id' => $offer_id, 'category_id' => $category_id));
					}


					// Offer_I18n
					$i18n = array();
					foreach ($this->mappings['langs'] as $lang) {
						$i18n[$lang] = array();
					}

					foreach ($offer->Title as $title) {
						$lang = (string)$title->attributes()->language;
						$i18n[$lang]['title'] = (string)$title;
					}

					foreach ($offer->Abstract as $abstract) {
						$lang = (string)$abstract->attributes()->language;
						$i18n[$lang]['abstract'] = (string)$abstract;
					}

					foreach ($offer->MediumDescription as $medium_description) {
						$lang = (string)$medium_description->attributes()->language;
						$i18n[$lang]['description_medium'] = (string)$medium_description;
					}

					foreach ($offer->LongDescription as $long_description) {
						$lang = (string)$long_description->attributes()->language;
						$i18n[$lang]['description_long'] = (string)$long_description;
					}

					foreach ($offer->AdditionalInfos as $additional_infos) {
						$lang = (string)$additional_infos->attributes()->language;
						$i18n[$lang]['additional_informations'] = (string)$additional_infos;
					}

					foreach ($offer->Details as $details) {
						$lang = (string)$details->attributes()->language;
						$i18n[$lang]['details'] = (string)$details;
					}

					foreach ($offer->PriceInfos as $price) {
						$lang = (string)$price->attributes()->language;
						$i18n[$lang]['price'] = (string)$price;
					}

					foreach ($offer->LocationDetails as $location_details) {
						$lang = (string)$location_details->attributes()->language;
						$i18n[$lang]['location_details'] = (string)$location_details;
					}

					foreach ($offer->OpeningHours as $opening_hours) {
						$lang = (string)$opening_hours->attributes()->language;
						$i18n[$lang]['opening_hours'] = (string)$opening_hours;
					}

					foreach ($offer->OtherInfrastructure as $other_infrastructure) {
						$lang = (string)$other_infrastructure->attributes()->language;
						$i18n[$lang]['other_infrastructure'] = (string)$other_infrastructure;
					}

					foreach ($offer->Benefits as $benefits) {
						$lang = (string)$benefits->attributes()->language;
						$i18n[$lang]['benefits'] = (string)$benefits;
					}

					foreach ($offer->Requirements as $requirements) {
						$lang = (string)$requirements->attributes()->language;
						$i18n[$lang]['requirements'] = (string)$requirements;
					}

					foreach ($offer->CateringInfos as $catering_infos) {
						$lang = (string)$catering_infos->attributes()->language;
						$i18n[$lang]['catering_informations'] = (string)$catering_infos;
					}

					foreach ($offer->MaterialRent as $material_rent) {
						$lang = (string)$material_rent->attributes()->language;
						$i18n[$lang]['material_rent'] = (string)$material_rent;
					}

					foreach ($offer->SafetyInstructions as $safety_instructions) {
						$lang = (string)$safety_instructions->attributes()->language;
						$i18n[$lang]['safety_instructions'] = (string)$safety_instructions;
					}

					foreach ($offer->Signalization as $signalization) {
						$lang = (string)$signalization->attributes()->language;
						$i18n[$lang]['signalization'] = (string)$signalization;
					}

					if (isset($offer->Route->URL)) {
						foreach ($offer->Route->URL as $url) {
							$lang = (string)$url->attributes()->language;
							$i18n[$lang]['route_url'] = (string)$url;
						}
					}

					// Insert/Update I18n data for offer
					foreach ($i18n as $language => $data) {
						if (!empty($data)) {
							$this->_insert_or_update('offer_i18n', $data, array('offer_id' => $offer_id, 'language' => $language));
						}
					}


					// Dates
					$this->db->delete('offer_date', array('offer_id' => $offer_id));
					foreach ($offer->Dates->Date as $date) {
						$date_from = $date->DateFrom.($date->TimeFrom ? "T".$date->TimeFrom : "");
						$date_to = NULL;
						if ($date->DateTo) {
							$date_to = $date->DateTo.($date->TimeTo ? "T".$date->TimeTo : "");
						}

						$fields = array();
						$fields['offer_id'] = $offer_id;
						$fields['date_from'] = empty($date_from) ? NULL : $this->_datetime($date_from);
						$fields['date_to'] = empty($date_to) ? NULL : $this->_datetime($date_to);

						$this->db->insert('offer_date', $fields);
					}


					// TargetGroups
					$this->db->delete('target_group_link', array('offer_id' => $offer_id));
					if ($offer->TargetGroups) {
						foreach ($offer->TargetGroups->TargetGroup as $target_group) {
							$target_group_id = $target_group->attributes()->identifier;
							$this->db->insert('target_group_link', array('offer_id' => $offer_id, 'target_group_id' => $target_group_id));
						}
					}


					// Images
					$this->db->delete('image', array('offer_id' => $offer_id));
					if ($offer->Images) {
						foreach ($offer->Images->Image as $image) {
							$fields = array();

							$fields['offer_id'] = $offer_id;
							$fields['small'] = (string)$image->Small;
							$fields['medium'] = (string)$image->Medium;
							$fields['large'] = (string)$image->Large;
							$fields['original'] = (string)$image->Original;
							$fields['copyright'] = (string)$image->Copyright;

							$this->db->insert('image', $fields);
						}
					}


					// Documents
					$this->db->delete('document', array('offer_id' => $offer_id));
					if ($offer->Documents) {
						foreach ($offer->Documents->Document as $document) {
							$fields = array();

							$fields['offer_id'] = $offer_id;
							$fields['language'] = (string)$document->attributes()->language;
							$fields['title'] = (string)$document->Title;
							$fields['url'] = (string)$document->URL;

							$this->db->insert('document', $fields);
						}
					}


					// Hyperlinks
					$this->db->delete('hyperlink', array('offer_id' => $offer_id));
					if ($offer->Hyperlinks) {
						foreach ($offer->Hyperlinks->Hyperlink as $hyperlink) {
							$fields = array();

							$fields['offer_id'] = $offer_id;
							$fields['language'] = (string)$hyperlink->attributes()->language;
							$fields['title'] = (string)$hyperlink->Title;
							$fields['url'] = (string)$hyperlink->URL;

							$this->db->insert('hyperlink', $fields);
						}
					}


					$root_category_id = $this->_get_root_category($offer->Categories->Category[0]->attributes()->identifier);
					$fields = array();


					if ($root_category_id == CATEGORY_EVENT) {
						$fields['is_park_event'] = (int)$offer->ParkEvent;
						$fields['is_park_partner_event'] = (int)$offer->ParkPartnerEvent;
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['kind_of_event'] = (string)$offer->Kind;
						$fields['subscription_mandatory'] = (int)$offer->SubscriptionMandatory;
						$fields['subscription_contact'] = $this->_address($offer->SubscriptionContact);
						$fields['subscription_link'] = (string)$offer->SubscriptionLink;
						$fields['subscription_details'] = (string)$offer->SubscriptionDetails;

						$this->_insert_or_update('event', $fields, array('offer_id' => $offer_id));
					}
					else if ($root_category_id == CATEGORY_PRODUCT) {
						$fields['available_from'] = empty($offer->AvailableFrom) ? NULL : $this->_datetime($offer->AvailableFrom);
						$fields['available_to'] = empty($offer->AvailableTo) ? NULL : $this->_datetime($offer->AvailableTo);
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['number_of_rooms'] = (int)$offer->NumberOfRooms;
						$fields['has_conference_room'] = (int)$offer->HasConferenceRoom;
						$fields['has_playground'] = (int)$offer->HasPlayground;
						$fields['has_picnic_place'] = (int)$offer->HasPicnicPlace;
						$fields['has_fireplace'] = (int)$offer->HasFireplace;
						$fields['has_washrooms'] = (int)$offer->HasWashrooms;

						$this->_insert_or_update('product', $fields, array('offer_id' => $offer_id));

						// Suppliers
						$this->db->delete('supplier', array('offer_id' => $offer_id));
						if ($offer->Suppliers) {
							foreach ($offer->Suppliers->Supplier as $supplier) {
								$this->db->insert('supplier', array('offer_id' => $offer_id, 'contact' => $this->_address($supplier)));
							}
						}
					}
					else if ($root_category_id == CATEGORY_BOOKING) {
						$fields['is_park_partner'] = (int)$offer->IsParkPartner;
						$fields['min_group_subscriber'] = (int)$offer->MinGroupSubscribers;
						$fields['max_group_subscriber'] = (int)$offer->MaxGroupSubscribers;
						$fields['min_individual_subscriber'] = (int)$offer->MinIndividualSubscribers;
						$fields['max_individual_subscriber'] = (int)$offer->MaxIndividualSubscribers;
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['subscription_mandatory'] = (int)$offer->SubscriptionMandatory;
						$fields['subscription_contact'] = $this->_address($offer->SubscriptionContact);
						$fields['subscription_link'] = (string)$offer->SubscriptionLink;
						$fields['subscription_details'] = (string)$offer->SubscriptionDetails;

						$this->_insert_or_update('booking', $fields, array('offer_id' => $offer_id));

						// Accommodations
						$this->db->delete('accommodation', array('offer_id' => $offer_id));
						if ($offer->Accommodations) {
							foreach ($offer->Accommodations->Accommodation as $accommodation) {
								$this->db->insert('accommodation', array('offer_id' => $offer_id, 'contact' => $this->_address($accommodation)));
							}
						}
					}
					else if ($root_category_id == CATEGORY_ACTIVITY) {
						$fields['start_place_info'] = (string)$offer->StartPlaceInfo;
						$fields['start_place_altitude'] = (int)$offer->StartPlaceAltitude;
						$fields['goal_place_info'] = (string)$offer->GoalPlaceInfo;
						$fields['goal_place_altitude'] = (int)$offer->GoalPlaceAltitude;
						$fields['route_length'] = (float)$offer->RouteLength;
						$fields['untarred_route_length'] = (float)$offer->UntarredRouteLength;
						$fields['public_transport_start'] = (string)$offer->PublicTransportStart;
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['altitude_differential'] = (int)$offer->AltitudeDifferential;
						$fields['altitude_ascent'] = (int)$offer->AltitudeAscent;
						$fields['altitude_descent'] = (int)$offer->AltitudeDescent;
						$fields['time_required'] = (string)$offer->TimeRequired;
						$fields['level_technics'] = $this->mappings['levels'][(string)$offer->LevelTechnics];
						$fields['level_condition'] = $this->mappings['levels'][(string)$offer->LevelCondition];
						$fields['has_playground'] = (int)$offer->HasPlayground;
						$fields['has_picnic_place'] = (int)$offer->HasPicnicPlace;
						$fields['has_fireplace'] = (int)$offer->HasFireplace;
						$fields['has_washrooms'] = (int)$offer->HasWashrooms;

						$this->_insert_or_update('activity', $fields, array('offer_id' => $offer_id));

						// Route
						$this->db->delete('offer_route', array('offer_id' => $offer_id));
						if (isset($offer->Route->Point)) {
							foreach ($offer->Route->Point as $point) {

								$fields = array();
								$fields['offer_id'] = $offer_id;
								$fields['latitude'] = (float)$point->Latitude;
								$fields['longitude'] = (float)$point->Longitude;
								$fields['sort'] = (int)$point->Index;

								$this->db->insert('offer_route', $fields);
							}
						}
					}


					// check off this offer
					array_push($offers_checklist, $offer_id);
					$ctr_imported++;

					$this->logger->info("\tImported offer with ID ".$offer_id);
				}
			}

			$this->logger->info("Successfully imported ".$ctr_imported." offers.");

			// delete offers which did not get updated
			if ($force === TRUE) {
				$this->logger->info("Deleting offers which were not updated...");
				$all_offers = $this->db->get('offer', NULL, NULL, array('offer_id'));
				while ($offer = mysql_fetch_assoc($all_offers)) {
					if (!in_array($offer['offer_id'], $offers_checklist)) {
						$this->db->delete('offer', array('offer_id' => $offer['offer_id']));
						$this->logger->info("\tDeleted offer with ID ".$offer['offer_id']);
						$ctr_deleted++;
					}
				}

				if ($ctr_deleted == 0) {
					$this->logger->info("\tNothing to delete");
				}
			}
			else {
				$this->logger->info("Deleted ".$ctr_deleted." offers.");
			}

			$this->db->update('api', array('last_import' => time()));
			$this->logger->info("Import finished successfully.");
		}
		else {
			$this->logger->error("Unknown Error when reading XML file");
			die("Unknown Error when reading XML file");
		}

	}


	/**
	 * Private method for retrieving the root category
	 *
	 * @param category_id
	 * @return integer|boolean
	 */
	private function _get_root_category($category_id) {
		if (!empty($category_id)) {

			while($category_id > 0) {
				$q_category = $this->db->get('category', array('category_id' => $category_id));
				if (mysql_num_rows($q_category) > 0) {
					$category = mysql_fetch_object($q_category);
					$category_id = $category->parent_id;
					$last_category_id = $category->category_id;
				}
			}

			return $last_category_id;
		}

		return FALSE;
	}


	/**
	 * Private method for inserting or updating db record
	 *
	 * @param table Table name
	 * @param fields Array of fields with values
	 * @param where Array of fields with values
	 * @return resource
	 */
	private function _insert_or_update($table, $fields, $where) {
		// check if offer exists in database
		$exists = $this->db->get($table, $where);

		if (mysql_num_rows($exists) > 0) {
			// update db record
			return $this->db->update($table, $fields, $where);
		}
		else {
			// insert new db record
			$fields = array_merge($fields, $where);
			return $this->db->insert($table, $fields);
		}
	}


	/**
	 * Private method for parsing Date/Time
	 *
	 * @param value Date/Time string
	 * @param format Desired format
	 * @return string
	 */
	private function _datetime($value, $format = "Y-m-d H:i:s") {
		$datetime = new DateTime($value);
		return $datetime->format($format);
	}


	/**
	 * Private method for parsing Address from XML
	 *
	 * @param contact Element with contact info
	 * @return string
	 */
	private function _address($contact) {
		$address = $contact->Company."\n";
		$address .= $contact->Address."\n";
		$address .= ($contact->ZipCode > 0 ? $contact->ZipCode." " : "").$contact->Locality."\n";
		$address .= $contact->Phone."\n";
		$address .= $contact->Email."\n";
		$address .= $contact->URL."\n";

		return (string)trim($address);
	}

}