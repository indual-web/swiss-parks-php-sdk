<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Startup session
 */
@session_start();


/**
 * Paths to API directory (must be correctly set, otherwise the API won't work)
 * ---------------------------------------------------------------------------
 * 'ABSOLUTE_PATH' = The absolute path on your server where the API is located
 * 'WEB_PATH' = The public URL where the API is accessible on your site
 */
define('ABSOLUTE_PATH', "/path/to/the/api");
define('WEB_PATH', "http://YOUR-DOMAIN/api");


/**
 * Include required files
 */
require_once(ABSOLUTE_PATH."/config.php");
foreach (glob(ABSOLUTE_PATH."/classes/*.php") as $filename) {
	require_once($filename);
}
foreach (glob(ABSOLUTE_PATH."/custom/*.php") as $filename) {
	require_once($filename);
}


/**
 * Main API class
 *
 * @author indual GmbH
 * @version 1.0
 * @copyright 2012 by indual GmbH
 */
class PaerkeAPI {


	/**
	 * API Hash
	 */
	private $hash;


	/**
	 * Configuration items
	 */
	public $config;


	/**
	 * Current language
	 */
	public $language = DEFAULT_LANGUAGE;


	/**
	 * API info from DB
	 */
	private $api;


	/**
	 * Offer object
	 */
	public $offer;


	/**
	 * Filter object and data
	 */
	private $filter = FALSE;
	private $filter_data = array();


	/**
	 * Language object
	 */
	public $lang;


	/**
	 * View object
	 */
	private $view;


	/**
	 * Pagination
	 */
	private $page;
	private $total;


	/**
	 * Session
	 */
	public $session_name;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @param  string
	 * @return void
	 */
	function __construct($language = DEFAULT_LANGUAGE, $hash = NULL) {

		// Get global config
		global $config;

		// Initialize object vars
		$this->hash = $hash ? $hash : $config['api_hash'];
		$this->config = $config;
		$this->language = $language;

		$this->lang = new PaerkeLanguage($this->language);
		$this->offer = new PaerkeOffer($this);

		if (class_exists($this->config['class_view'])) {
			$this->view = new $this->config['class_view']($this);
		}
		else {
			$this->view = new PaerkeView($this);
		}

		$this->_setup();

		if ($this->config['use_sessions']) {
			$this->session_name = $this->config['session_name'].'_'.md5($_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"]);
		}

		$paramname = FORM_PREFIX.'reset';
		if (isset($_GET[$paramname])) {
			$this->_reset_filter();
		}
		else {
			$this->_init_filter();
		}
	}


	/**
	 * Updates database from XML export
	 *
	 * @access public
	 * @return void
	 */
	public function update($force = FALSE) {
		$xml = $this->config['xml_export_url'].'xml/'.$this->hash;

		// Import data from XML into database
		$importer = new PaerkeImport();
		$importer->import($xml, $force);
	}


	/**
	 * Displays filter for offers
	 *
	 * @access public
	 * @return void
	 */
	public function show_offers_filter($park_id = NULL, $categories = array(), $additional_infos = array()) {

		if (!$this->is_offer_detail() || $this->config['always_show_filter'] == TRUE) {

			// Prepare categories for select
			$categories = is_array($categories) ? $categories : array($categories);
			$first = reset($categories);
			if (count($categories) == 0 || (count($categories) == 1 && empty($first))) {
				$categories = FALSE;
			}

			$categories = $this->_prepare_categories($categories, FALSE, $additional_infos);

			$category_links = $this->offer->get_all_category_links();
			$categories = $this->_format_categories_for_select($categories, $category_links, 0, 0, TRUE);

			// Prepare parks/users for select
			$users = array();

			if (empty($park_id)) {
				$flat_categories = $this->_prepare_categories($categories, TRUE);
				$users = $this->offer->get_all_users(array_keys($flat_categories), $additional_infos);
			}

			$this->view->show_offers_filter(array('categories' => $categories, 'selected' => $this->filter_data, 'filter' => $this->filter, 'users' => $users));
		}
	}


	/**
	 * Displays list of offers (optionally filtered)
	 *
	 * @access public
	 * @param  integer
	 * @return void
	 */
	public function show_offers_list($categories = array(), $additional_infos = array(), $park_id = NULL) {

		if (!$this->is_offer_detail()) {
			$this->page = 1;
			$paramname = PARAM_PREFIX.'page';
			if (isset($_GET[$paramname]) && $_GET[$paramname] >= 1) {
				$this->page = $_GET[$paramname];
				if ($this->config['use_sessions']) {
					$_SESSION[$this->session_name]['page'] = $this->page;
				}
			}
			else if ($this->config['use_sessions'] && isset($_SESSION[$this->session_name]['page']) && $_SESSION[$this->session_name]['page'] >= 1) {
				$this->page = $_SESSION[$this->session_name]['page'];
			}

			$offers = $this->_get_offers($categories, NULL, $additional_infos, $park_id);

			$this->total = ceil(count($offers) / $this->config['offers_per_page']);
			if (count($offers) > $this->config['offers_per_page']) {
				$offset = ($this->page-1) * $this->config['offers_per_page'];
				$offers = array_slice($offers, $offset, $this->config['offers_per_page'], TRUE);
			}

			$this->view->show_offers_list($offers);
		}

	}


	/**
	 * Displays pagination
	 *
	 * @access public
	 * @return void
	 */
	public function show_offers_pagination() {

		if (!$this->is_offer_detail()) {
			$this->view->show_pagination($this->page, $this->total);
		}
	}


	/**
	 * Displays map of offers (optionally filtered)
	 *
	 * @access public
	 * @param  integer
	 * @return void
	 */
	public function show_offers_map($categories = array(), $additional_infos = array(), $park_id = NULL, $show_layers_at_start = FALSE, $custom_map_layers = array()) {

		if (!$this->is_offer_detail()) {
			$this->_load_maps_api();

			if (is_numeric($park_id) && $park_id > 0) {
				if ($this->config['use_sessions']) {
					$_SESSION[$this->session_name]['selectedPark'] = $this->offer->parkAbbreviations[$park_id];
				}
				else {
					unset($_SESSION[$this->session_name]['selectedPark']);
				}
			}

			$offers = $this->_get_offers($categories, NULL, $additional_infos, $park_id);
			$this->view->show_offers_map($offers, $show_layers_at_start, $custom_map_layers);
		}
	}


	/**
	 * Display detail of offer
	 *
	 * @access public
	 * @param  integer
	 * @return void
	 */
	public function show_offer_detail() {

		if ($this->is_offer_detail()) {
			$this->_load_maps_api();

			$paramname = PARAM_PREFIX.'offer';
			$offer_id = intval($_GET[$paramname]);
			$offer = $this->offer->get_offer($offer_id);

			$this->view->show_offer_detail($offer);
		}
	}


	/**
	 * Returns if detail page should be displayed
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_offer_detail() {
		$paramname = PARAM_PREFIX.'offer';

		if (isset($_GET[$paramname])) {
			$offer_id = intval($_GET[$paramname]);
			return $this->offer->offer_exists($offer_id);
		}

		return FALSE;
	}


	/**
	 * Returns if filter is active
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_filter_activated() {
		return $this->filter;
	}


	/**
	 * Returns filter data
	 *
	 * @access public
	 * @return boolean
	 */
	public function get_filter_data() {
		return $this->filter_data;
	}


	/**
	 * Get list of offers
	 *
	 * @access public
	 * @param  integer
	 * @return mixed
	 */
	public function get_offers_list($categories = array(), $page = NULL, $additional_infos = array(), $park_id = NULL) {
		return $this->_get_offers($categories, $page, $additional_infos, $park_id);
	}


	/**
	 * Get offer details
	 *
	 * @access public
	 * @param  integer
	 * @return mixed
	 */
	public function get_offer_detail($offer_id) {
		return $this->offer->get_offer($offer_id);
	}


	/**
	 * Get list of categories
	 *
	 * @access public
	 * @return mixed
	 */
	public function get_categories_list() {
		return $this->offer->get_all_categories();
	}


	/**
	 * Get list of categories preformatted for select inputs
	 *
	 * @access public
	 * @return mixed
	 */
	public function get_categories_list_for_select() {
		// Prepare categories for select
		$categories = $this->_prepare_categories();
		$category_links = $this->offer->get_all_category_links();
		$categories = $this->_format_categories_for_select($categories, $category_links, 0);

		return $categories;
	}


	/**
	 * Private Methods
	 */
	private function _setup() {
		$this->_security_checks();

		if (!$this->_validate_hash()) {
			die("No valid API hash found: " . $this->hash);
		}

		$db = new PaerkeMySQL($this->config['db_hostname'], $this->config['db_username'], $this->config['db_password'], $this->config['db_database']);
		$q_api = $db->get('api');

		if ($q_api) {
			if (mysql_num_rows($q_api) > 0) {
				$this->api = mysql_fetch_object($q_api);
			}
			else {
				$this->api->initialized = false;
				$this->api->version = API_VERSION;

				$db->insert('api', (array)$this->api);
			}

			if (version_compare(API_VERSION, $this->api->version)) {
				$logger = new PaerkeLog();
				$logger->info('The current API version is out of date. Please update database (see docs/database_changes.sql).');
			}

			if (!$this->api->initialized) {

				// Initalize API
				$xml = $this->config['xml_export_url'].'xml/'.$this->hash;

				// Import data from XML into database
				$importer = new PaerkeImport();
				$importer->import($xml);

				$this->api->initialized = true;
				$db->update('api', array('initialized' => 1));
			}
		}
		else {
			die("API could not be initialized.");
		}
	}

	private function _validate_hash() {
		$validate = @file_get_contents($this->config['xml_export_url'].'validate/'.$this->hash);

		if ($validate == "Valid") {
			return TRUE;
		}
		else if (!empty($this->hash) && strlen($this->hash) >= 32) {
			return TRUE;
		}

		return FALSE;
	}

	private function _init_filter() {

		$paramname = FORM_PREFIX.'filter';
		$post_data = $_POST[$paramname];

		$fields = array('categories', 'date_from', 'date_to', 'search', 'park_id');

		foreach ($fields as $field) {

			$this->filter_data[$field] = NULL;

			if (isset($post_data[$field]) && !empty($post_data[$field])) {
				$this->filter_data[$field] = $post_data[$field];
				$this->filter = TRUE;
				if ($this->config['use_sessions']) {
					unset($_SESSION[$this->session_name]['page']);
				}
			}
			else if ($this->config['use_sessions'] && (isset($_SESSION[$this->session_name]['filter'][$field]) && !empty($_SESSION[$this->session_name]['filter'][$field]))) {
				$this->filter_data[$field] = $_SESSION[$this->session_name]['filter'][$field];
				$this->filter = TRUE;
			}
		}

		if ($this->config['use_sessions']) {
			$_SESSION[$this->session_name]['filter'] = $this->filter_data;
		}
	}

	private function _reset_filter() {

		$this->filter_data = array();
		if ($this->config['use_sessions']) {
			unset($_SESSION[$this->session_name]['filter']);
			unset($_SESSION[$this->session_name]['page']);
		}

	}

	private function _get_offers($categories = array(), $page = NULL, $additional_infos = array(), $park_id = NULL) {

		$filter = array();
		foreach ($this->filter_data as $field => $value) {
			if (!empty($value)) {
				$fieldname = substr($field, strlen(FORM_PREFIX), strlen($field));
				$filter[$fieldname] = $value;
			}
		}

		// overwrite filter fields
		if (!empty($categories) && !isset($filter['categories'])) {
			$filter['categories'] = $categories;
		}

		// offer settings
		if (isset($additional_infos['offer_settings']) && !empty($additional_infos['offer_settings'])) {
			$filter['offer_settings'] = $additional_infos['offer_settings'];
		}

		// target groups
		if (isset($additional_infos['target_groups']) && !empty($additional_infos['target_groups'])) {
			$filter['target_groups'] = $additional_infos['target_groups'];
		}

		// search words
		if (isset($additional_infos['search']) && !empty($additional_infos['search'])) {
			$filter['search'] = $additional_infos['search'];
		}

		// park id
		if (!empty($park_id)) {
			$filter['park_id'] = $park_id;
		}

		// get page limits
		$per_page = NULL;
		$limit = NULL;
		if (!empty($page) && is_numeric($page)) {
			$per_page = $this->config['offers_per_page'];
			$limit = ($page - 1) * $this->config['offers_per_page'];
		}

		$offers = array();
		if (!empty($filter)) {
			$offers = $this->offer->get_filtered_offers($filter, $per_page, $limit);
		}
		else {
			$offers = $this->offer->get_all_offers($per_page, $limit);
		}

		return $offers;
	}

	private function _load_maps_api() {
		echo '<script type="text/javascript">var dojoConfig = { locale: "'.$this->language.'", parseOnLoad: true, packages: [{ name: "apl", location : "'.WEB_PATH.'/js/apl" }] };</script>'."\n";
		echo '<script type="text/javascript" src="http://serverapi.arcgisonline.com/jsapi/arcgis/?v=3.1compact"></script>'."\n";
		echo '<script type="text/javascript" src="http://angebote.paerke.ch/swissmap/swissmap.js"></script>'."\n";
	}

	private function _format_categories_for_select($categories, $category_links, $index, $level = 0, $optgroups = FALSE) {
		$return = array();
		if (!empty($categories[$index])) {
			foreach($categories[$index] as $id => $category) {

				if (!empty($category_links) && in_array($id, $category_links) && !($optgroups && (($level == 0 && !in_array($id, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))) || ($level == 1 && in_array($index, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))))) ) {
					$repeat = $optgroups ? ($level-1) : $level;
					$return[$id] = ($repeat > 0 ? str_repeat("&nbsp;&nbsp;&nbsp;", $repeat) : '').$category;
				}

				if (isset($categories[$id])) {
					$childs = $this->_format_categories_for_select($categories, $category_links, $id, $level+1, $optgroups);
					if (!empty($childs)) {
						if ($optgroups && (($level == 0 && !in_array($id, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))) || ($level == 1 && in_array($index, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))))) {
							$return[$category] = $childs;
						}
						else {
							$return += $childs;
						}
					}
				}
			}
		}

		return $return;
	}

	private function _prepare_categories($categories = FALSE, $flatten = FALSE, $additional_infos = array()) {
		$return = array();
		$parents = array();

		$all_categories = $this->offer->get_all_categories($additional_infos);
		if ($categories) {
			foreach($categories as $category_id) {
				$category_id = intval($category_id);
				if ($all_categories[$category_id]) {
					$parents = array_merge($parents, $all_categories[$category_id]->parents);
				}
			}
		}

		foreach($all_categories as $id => $category) {
			$parent_id = $category->parent_id ? $category->parent_id : 0;
			$parents_intersect = is_array($categories) ? array_intersect($category->parents, $categories) : array();
			if (!$categories || (in_array($id, $categories) || count($parents_intersect) > 0 || in_array($id, $parents))) {
				if ($flatten) {
					$return[$id] = $category->body;
				}
				else {
					$return[$parent_id][$id] = $category->body;
				}
			}
		}

		return $return;
	}

	private function _security_checks() {
		// add slashes (only if magic_quotes_gpc is disabled in php.ini)
		if (!get_magic_quotes_gpc()) {
			array_walk_recursive($_GET, array($this, '_add_slashes'));
		}

		if (is_array($_GET)) {
			foreach($_GET as $key => $value) {
				// sql injection protection
				$tmp = str_replace(array("*", "'", '"', ";", "="), "", $value);
				// cross site scripting protection
				$tmp = str_replace(array("<", ">"), array("&lt;", "&gt;"), $tmp);
				$_GET[$key] = $tmp;
			}
		}
	}

	private function _add_slashes(&$item, $key) {
		$item = (!is_array($item) ? addslashes($item) : $item);
	}

}