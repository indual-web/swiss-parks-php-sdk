<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


// Include API
require("PaerkeAPI.php");

// Update offer data
$api = new PaerkeAPI();
$api->migrate();