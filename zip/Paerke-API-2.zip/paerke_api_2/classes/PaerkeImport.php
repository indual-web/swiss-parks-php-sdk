<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Importing XML data into database
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeImport {

	/**
	 * Database object
	 */
	private $db;


	/**
	 * Logger object
	 */
	private $logger;


	/**
	 * XML object containing all data
	 */
	private $xml;


	/**
	 * Necessary Key-Value mappings for XML data
	 */
	private $mappings;


	/**
	 * Constructor
	 */
	function __construct() {

		// Get global config
		if (!isset($config)) {
			include(ABSOLUTE_PATH.'/config.php');
		}
		$this->db = new PaerkeMySQL($config['db_hostname'], $config['db_username'], $config['db_password'], $config['db_database']);
		$this->logger = new PaerkeLog();

		// setup mappings necessary for XML import
		$this->mappings = array(
			'langs' => array(
				'de' => 'de',
				'fr' => 'fr',
				'it' => 'it',
				'en' => 'en'
			),
			'levels' => array(
				'' 			=> 0,
				'easy' 		=> 1,
				'medium' 	=> 2,
				'hard' 		=> 3
			)
		);
	}


	/**
	 * Method for importing xml map layers into database
	 *
	 * @param url Location of XML file
	 * @return boolean
	 */
	public function import_map_layers($url) {

		// load xml
		$this->xml = simplexml_load_file($url);

		if ($this->xml !== FALSE) {

			// remove all layers
			$this->db->delete('map_layer');

			// import custom layers
			if (count($this->xml->MapLayers) > 0) {

				// remove first all elements
				foreach ($this->xml->MapLayers->MapLayer as $layer) {
					$map_fields = array();
					$map_i18n_fields = array();
					$content = '';
					$map_fields['map_layer_id'] = intval($layer->attributes()->identifier);
					$map_fields['url'] = (string) trim($layer->URL);
					$map_fields['languages'] = (string) $layer->URL->attributes()->language;
					$map_fields['layer_position'] = (int) $layer->URL->attributes()->position;
					$map_fields['visible_by_default'] = (int) $layer->URL->attributes()->visibility;

					if (isset($layer->URL->Popup)) {
						$map_fields['popup_title'] = (string) $layer->URL->Popup->Title;

						if (isset($layer->URL->Popup->Logo)) {
							$map_fields['popup_logo'] = (string) $layer->URL->Popup->Logo;
							$map_fields['popup_logo_width'] = (int) $layer->URL->Popup->Logo->attributes()->width;
							$map_fields['popup_logo_height'] = (int) $layer->URL->Popup->Logo->attributes()->height;
						}
					}

					// insert
					if (!$this->db->insert('map_layer', $map_fields)) {
						$this->logger->error("MySQL Error: ".$this->db->get_last_error());
						continue;
					}
					// if insert success
					else {

						$map_layer_id = $this->_get_last_id('map_layer_id', 'map_layer');

						if (isset($layer->URL->Popup->Content) && !empty($map_layer_id)) {
							foreach ($layer->URL->Popup->Content as $content) {
								$map_i18n_fields['map_layer_id'] = $map_layer_id;
								$map_i18n_fields['popup_content'] = (string) $content;
								$map_i18n_fields['language'] = (string) $content->attributes()->lang;

								if (!$this->db->insert('map_layer_i18n', $map_i18n_fields)) {
									$this->logger->error("MySQL Error: ".$this->db->get_last_error());
									continue;
								}
							}
						}
						$this->logger->info("Map layer i18n import finished successfully.");
					}
				}
				$this->logger->info("Map layer import finished successfully.");
			}
		}
	}


	/**
	 * Method for importing xml offers into database
	 *
	 * @param url Location of XML file
	 * @param force Forces import of all offers (including those who haven't changed)
	 * @return boolean
	 */
	public function import($url, $force = FALSE) {

		if (empty($url)) {
			$this->logger->error("No URL for XML file specified");
			die("No URL for XML file specified");
		}

		// add param to url with last import timestamp
		if ($force !== TRUE) {
			$api_info = mysqli_fetch_assoc($this->db->get('api'));
			$last_import = $api_info['last_import'];
			if (!empty($last_import)) {
				$url .= '?since='.$last_import;
			}
			else {
				$force = TRUE;
				$this->logger->info("Enabling FORCE mode because timestamp for last import is empty");
			}
		}
		else {
			$this->logger->info("FORCE mode is enabled");
		}

		$this->xml = simplexml_load_file($url);

		if ($this->xml !== FALSE) {

			$this->logger->info("Starting XML import from ".$url);
			$ctr_imported = 0;
			$ctr_deleted = 0;

			$offers_checklist = array();


			if (count($this->xml->Offer) > 0) {

				// import every offer
				foreach ($this->xml->Offer as $offer) {
					$offer_id = intval($offer->attributes()->identifier);
					$deleted_at = $offer->attributes()->deletedAt;
					$status = $offer->attributes()->status;

					// check if offer should be deleted
					if (!empty($deleted_at) || $status != OFFER_STATUS_ACTIVE) {
						if ($force !== TRUE) {
							// delete offer from db and continue
							$this->db->delete('offer', array('offer_id' => $offer_id));
							$this->logger->info("\tDeleted offer with ID ".$offer_id);
							$ctr_deleted++;
						}

						continue;
					}

					// Offer
					$fields = array();

					$fields['park_id'] = (int)$offer->ParkId;
					$fields['park'] = (string)$offer->Park;
					$fields['institution'] = $this->_address($offer->Institution);
					$fields['institution_is_park_partner'] = (int)$offer->Institution->ParkPartner;

					$fields['contact'] = $this->_address($offer->Contact);
					$fields['contact_is_park_partner'] = (int)$offer->Contact->ParkPartner;

					$fields['barrier_free'] = (int)$offer->BarrierFree;
					$fields['learning_opportunity'] = (int)$offer->LearningOpportunity;
					$fields['child_friendly'] = (int)$offer->ChildFriendly;
					$fields['park_day'] = (int)$offer->ParkDay;
					$fields['enjoy_week'] = (int)$offer->EnjoyWeek;

					$fields['latitude'] = (float)$offer->Latitude;
					$fields['longitude'] = (float)$offer->Longitude;

					$fields['created_at'] = $this->_datetime($offer->attributes()->createdAt);
					$fields['modified_at'] = $this->_datetime($offer->attributes()->modifiedAt);

					// error handling
					if (!$this->_insert_or_update('offer', $fields, array('offer_id' => $offer_id))) {
						$this->logger->error("MySQL Error: ".$this->db->get_last_error());
						continue;
					}

					// categories
					$this->db->delete('category_link', array('offer_id' => $offer_id));
					foreach ($offer->Categories->Category as $category) {
						$category_id = $category->attributes()->identifier;
						$this->db->insert('category_link', array('offer_id' => $offer_id, 'category_id' => $category_id));
					}

					// offer_i18n
					$i18n = array();
					foreach ($this->mappings['langs'] as $lang) {
						$i18n[$lang] = array();
					}

					// define i18n fields
					$i18n_fields = array(
						'Title' => 'title',
						'Abstract' => 'abstract',
						'MediumDescription' => 'description_medium',
						'LongDescription' => 'description_long',
						'AdditionalInfos' => 'additional_informations',
						'Details' => 'details',
						'PriceInfos' => 'price',
						'LocationDetails' => 'location_details',
						'OpeningHours' => 'opening_hours',
						'OtherInfrastructure' => 'other_infrastructure',
						'Benefits' => 'benefits',
						'Requirements' => 'requirements',
						'CateringInfos' => 'catering_informations',
						'MaterialRent' => 'material_rent',
						'SafetyInstructions' => 'safety_instructions',
						'Signalization' => 'signalization',
					);

					// setup i18n values
					$available_languages = array();
					foreach	($i18n_fields as $xml_node_name => $db_column_name) {
						// node is set in xml
						if (!empty($offer->{$xml_node_name})) {
							foreach ($offer->{$xml_node_name} as $node) {
								$lang = (string)$node->attributes()->language;
								$available_languages[$lang] = NULL;
								$i18n[$lang][$db_column_name] = (string)$node;
							}
						}
						// node is not set > clean this value from db
						else {
							foreach (array_keys($available_languages) as $lang) {
								$i18n[$lang][$db_column_name] = '';
							}
						}
					}

					// Offer route url
					if (isset($offer->Route->URL)) {
						foreach ($offer->Route->URL as $url) {
							$lang = (string)$url->attributes()->language;
							$i18n[$lang]['route_url'] = (string)$url;
						}
					}

					// insert/update i18n data for offer
					foreach ($i18n as $language => $data) {
						if (!empty($data)) {
							$this->_insert_or_update('offer_i18n', $data, array('offer_id' => $offer_id, 'language' => $language));
						}
					}

					// dates
					$this->db->delete('offer_date', array('offer_id' => $offer_id));
					if (!empty($offer->Dates)) {
						foreach ($offer->Dates->Date as $date) {
							$date_from = $date->DateFrom.($date->TimeFrom ? "T".$date->TimeFrom : "");
							$date_to = NULL;
							if ($date->DateTo) {
								$date_to = $date->DateTo.($date->TimeTo ? "T".$date->TimeTo : "");
							}

							$fields = array();
							$fields['offer_id'] = $offer_id;
							$fields['date_from'] = empty($date_from) ? NULL : $this->_datetime($date_from);
							$fields['date_to'] = empty($date_to) ? NULL : $this->_datetime($date_to);

							$this->db->insert('offer_date', $fields);
						}
					}

					// targetGroups
					$this->db->delete('target_group_link', array('offer_id' => $offer_id));
					if ($offer->TargetGroups) {
						foreach ($offer->TargetGroups->TargetGroup as $target_group) {
							$target_group_id = $target_group->attributes()->identifier;
							$this->db->insert('target_group_link', array('offer_id' => $offer_id, 'target_group_id' => $target_group_id));
						}
					}

					// images
					$this->db->delete('image', array('offer_id' => $offer_id));
					if ($offer->Images) {
						foreach ($offer->Images->Image as $image) {
							$fields = array();

							$fields['offer_id'] = $offer_id;
							$fields['small'] = (string)$image->Small;
							$fields['medium'] = (string)$image->Medium;
							$fields['large'] = (string)$image->Large;
							$fields['original'] = (string)$image->Original;
							$fields['copyright'] = (string)$image->Copyright;

							$this->db->insert('image', $fields);
						}
					}

					// documents
					$this->db->delete('document', array('offer_id' => $offer_id));
					if ($offer->Documents) {
						foreach ($offer->Documents->Document as $document) {
							$fields = array();

							$fields['offer_id'] = $offer_id;
							$fields['language'] = (string)$document->attributes()->language;
							$fields['title'] = (string)$document->Title;
							$fields['url'] = (string)$document->URL;

							$this->db->insert('document', $fields);
						}
					}

					// hyperlinks
					$this->db->delete('hyperlink', array('offer_id' => $offer_id));
					if ($offer->Hyperlinks) {
						foreach ($offer->Hyperlinks->Hyperlink as $hyperlink) {
							$fields = array();

							$fields['offer_id'] = $offer_id;
							$fields['language'] = (string)$hyperlink->attributes()->language;
							$fields['title'] = (string)$hyperlink->Title;
							$fields['url'] = (string)$hyperlink->URL;

							$this->db->insert('hyperlink', $fields);
						}
					}

					// get root category id
					$root_category_id = $this->_get_root_category($offer->Categories->Category[0]->attributes()->identifier);

					// subscription
					if (($root_category_id == CATEGORY_EVENT) || ($root_category_id == CATEGORY_BOOKING)) {
						$fields = array();

						$fields['subscription_mandatory'] = (int)$offer->Subscription->SubscriptionMandatory;
						$fields['online_subscription_enabled'] = (int)$offer->Subscription->OnlineSubscriptionEnabled;
						$fields['subscription_contact'] = $this->_address($offer->Subscription->SubscriptionContact);
						$fields['subscription_link'] = (string)$offer->Subscription->SubscriptionLink;
						$this->_insert_or_update('subscription', $fields, array('offer_id' => $offer_id));

						// subscription i18n
						if (isset($offer->Subscription->Details)) {
							foreach ($offer->Subscription->Details as $detail) {
								$subscription_detail = array();
								$subscription_detail['offer_id'] = $offer_id;
								$subscription_detail['language'] = (string)$detail->attributes()->language;
								$subscription_detail_where = $subscription_detail;
								$subscription_detail['subscription_details'] = (string)$detail;
								$this->_insert_or_update('subscription_i18n', $subscription_detail, $subscription_detail_where);
							}
						}
					}

					$fields = array();

					// Events
					if ($root_category_id == CATEGORY_EVENT) {
						$fields['is_park_event'] = (int)$offer->ParkEvent;
						$fields['is_park_partner_event'] = (int)$offer->ParkPartnerEvent;
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['kind_of_event'] = (string)$offer->Kind;

						$this->_insert_or_update('event', $fields, array('offer_id' => $offer_id));
					}

					// Products
					else if ($root_category_id == CATEGORY_PRODUCT) {
						$fields['available_from'] = empty($offer->AvailableFrom) ? NULL : $this->_datetime($offer->AvailableFrom);
						$fields['available_to'] = empty($offer->AvailableTo) ? NULL : $this->_datetime($offer->AvailableTo);
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['number_of_rooms'] = (int)$offer->NumberOfRooms;
						$fields['has_conference_room'] = (int)$offer->HasConferenceRoom;
						$fields['has_playground'] = (int)$offer->HasPlayground;
						$fields['has_picnic_place'] = (int)$offer->HasPicnicPlace;
						$fields['has_fireplace'] = (int)$offer->HasFireplace;
						$fields['has_washrooms'] = (int)$offer->HasWashrooms;

						$this->_insert_or_update('product', $fields, array('offer_id' => $offer_id));

						// Suppliers
						$this->db->delete('supplier', array('offer_id' => $offer_id));
						if ($offer->Suppliers) {
							foreach ($offer->Suppliers->Supplier as $supplier) {
								$this->db->insert('supplier', array('offer_id' => $offer_id, 'contact' => $this->_address($supplier), 'is_park_partner' => (int)$offer->Contact->ParkPartner));
							}
						}
					}

					// Bookings
					else if ($root_category_id == CATEGORY_BOOKING) {
						$fields['is_park_partner'] = (int)$offer->IsParkPartner;
						$fields['min_group_subscriber'] = (int)$offer->MinGroupSubscribers;
						$fields['max_group_subscriber'] = (int)$offer->MaxGroupSubscribers;
						$fields['min_individual_subscriber'] = (int)$offer->MinIndividualSubscribers;
						$fields['max_individual_subscriber'] = (int)$offer->MaxIndividualSubscribers;
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;

						$this->_insert_or_update('booking', $fields, array('offer_id' => $offer_id));

						// Accommodations
						$this->db->delete('accommodation', array('offer_id' => $offer_id));
						if ($offer->Accommodations) {
							foreach ($offer->Accommodations->Accommodation as $accommodation) {
								$this->db->insert('accommodation', array('offer_id' => $offer_id, 'contact' => $this->_address($accommodation)));
							}
						}
					}

					// Activities
					else if ($root_category_id == CATEGORY_ACTIVITY) {
						$fields['start_place_info'] = (string)$offer->StartPlaceInfo;
						$fields['start_place_altitude'] = (int)$offer->StartPlaceAltitude;
						$fields['goal_place_info'] = (string)$offer->GoalPlaceInfo;
						$fields['goal_place_altitude'] = (int)$offer->GoalPlaceAltitude;
						$fields['route_length'] = (float)$offer->RouteLength;
						$fields['untarred_route_length'] = (float)$offer->UntarredRouteLength;
						$fields['public_transport_start'] = (string)$offer->PublicTransportStart;
						$fields['public_transport_stop'] = (string)$offer->PublicTransportStop;
						$fields['altitude_differential'] = (int)$offer->AltitudeDifferential;
						$fields['altitude_ascent'] = (int)$offer->AltitudeAscent;
						$fields['altitude_descent'] = (int)$offer->AltitudeDescent;
						$fields['time_required'] = (string)$offer->TimeRequired;
						$fields['level_technics'] = $this->mappings['levels'][(string)$offer->LevelTechnics];
						$fields['level_condition'] = $this->mappings['levels'][(string)$offer->LevelCondition];
						$fields['has_playground'] = (int)$offer->HasPlayground;
						$fields['has_picnic_place'] = (int)$offer->HasPicnicPlace;
						$fields['has_fireplace'] = (int)$offer->HasFireplace;
						$fields['has_washrooms'] = (int)$offer->HasWashrooms;

						// POI
						$fields['poi'] = NULL;
						if (isset($offer->POI) && !empty($offer->POI->OfferId)) {
							foreach ($offer->POI->OfferId as $poi) {
								$fields['poi'][] = $poi;
							}
							$fields['poi'] = implode(',', $fields['poi']);
						}

						$this->_insert_or_update('activity', $fields, array('offer_id' => $offer_id));

						// Route
						$this->db->delete('offer_route', array('offer_id' => $offer_id));
						if (isset($offer->Route->Point)) {
							foreach ($offer->Route->Point as $point) {

								$fields = array();
								$fields['offer_id'] = $offer_id;
								$fields['latitude'] = (float)$point->Latitude;
								$fields['longitude'] = (float)$point->Longitude;
								$fields['sort'] = (int)$point->Index;

								$this->db->insert('offer_route', $fields);
							}
						}
					}

					// Projects
					else if ($root_category_id == CATEGORY_PROJECT) {
						$fields['duration_from'] = (string)$offer->DurationFrom;
						$fields['duration_to'] = (int)$offer->DurationTo;
						$fields['status'] = intval($offer->Status->attributes()->identifier);

						// POI
						$fields['poi'] = NULL;
						if (isset($offer->POI) && !empty($offer->POI->OfferId)) {
							foreach ($offer->POI->OfferId as $poi) {
								$fields['poi'][] = $poi;
							}
							$fields['poi'] = implode(',', $fields['poi']);
						}

						$this->_insert_or_update('project', $fields, array('offer_id' => $offer_id));

					}

					// check off this offer
					array_push($offers_checklist, $offer_id);
					$ctr_imported++;

					$this->logger->info("\tImported offer with ID ".$offer_id);
				}
			}

			$this->logger->info("Successfully imported ".$ctr_imported." offers.");

			// delete offers which did not get updated
			if ($force === TRUE) {
				$this->logger->info("Deleting offers which were not updated...");
				$all_offers = $this->db->get('offer', NULL, NULL, array('offer_id'));
				while ($offer = mysqli_fetch_assoc($all_offers)) {
					if (!in_array($offer['offer_id'], $offers_checklist)) {
						$this->db->delete('offer', array('offer_id' => $offer['offer_id']));
						$this->logger->info("\tDeleted offer with ID ".$offer['offer_id']);
						$ctr_deleted++;
					}
				}

				if ($ctr_deleted == 0) {
					$this->logger->info("\tNothing to delete");
				}
			}
			else {
				$this->logger->info("Deleted ".$ctr_deleted." offers.");
			}

			$this->db->update('api', array('last_import' => time()));
			$this->logger->info("Import finished successfully.");
		}
		else {
			$this->logger->error("Unknown Error when reading XML file");
			die("Unknown Error when reading XML file");
		}

	}


	/**
	 * Clean up offers (remove inactive offers with active id)
	 *
	 * @access public
	 * @param mixed $url
	 * @return void
	 */
	public function clean_up_offers($url) {

		// load xml
		$this->xml = simplexml_load_file($url);

		$active_offers = array();
		$ctr_deleted = 0;

		// retrieve active offers
		if ($this->xml !== FALSE) {
			if (count($this->xml) > 0) {
				foreach ($this->xml->Offer as $active_offer) {
					$active_offers[] = intval($active_offer->attributes()->identifier);
				}
			}
		}

		// remove inactive offers
		$this->logger->info("Clean up offers");
		$all_offers = $this->db->get('offer', NULL, NULL, array('offer_id'));

		while ($offer = mysqli_fetch_assoc($all_offers)) {

			// offer is inactive, delete it!
			if (!in_array($offer['offer_id'], $active_offers)) {
				$this->db->delete('offer', array('offer_id' => $offer['offer_id']));
				$this->logger->info("\tDeleted inactive offer with ID ".$offer['offer_id']);
				$ctr_deleted++;
			}

		}

		// log result
		if ($ctr_deleted == 0) {
			$this->logger->info("\tNo inactive offers");
		} else {
			$this->logger->info("Deleted ".$ctr_deleted." inactive offer(s).");
		}

	}


	/**
	 * Private method for retrieving the root category
	 *
	 * @param category_id
	 * @return integer|boolean
	 */
	private function _get_root_category($category_id) {
		if (!empty($category_id)) {

			while($category_id > 0) {
				$q_category = $this->db->get('category', array('category_id' => $category_id));
				if (mysqli_num_rows($q_category) > 0) {
					$category = mysqli_fetch_object($q_category);
					$category_id = $category->parent_id;
					$last_category_id = $category->category_id;
				}
			}

			return $last_category_id;
		}

		return FALSE;
	}


	/**
	 * Private method for inserting or updating db record
	 *
	 * @param table Table name
	 * @param fields Array of fields with values
	 * @param where Array of fields with values
	 * @return resource
	 */
	private function _insert_or_update($table, $fields, $where) {
		if (!empty($table) && !empty($fields) && !empty($where)) {
			// check if offer exists in database
			$exists = $this->db->get($table, $where);

			if (mysqli_num_rows($exists) > 0) {
				// update db record
				return $this->db->update($table, $fields, $where);
			}
			else {
				// insert new db record
				$fields = array_merge($fields, $where);
				return $this->db->insert($table, $fields);
			}
		}
	}


	/**
	 * Private method for parsing Date/Time
	 *
	 * @param value Date/Time string
	 * @param format Desired format
	 * @return string
	 */
	private function _datetime($value, $format = "Y-m-d H:i:s") {
		$datetime = new DateTime($value);
		return $datetime->format($format);
	}


	/**
	 * Private method for parsing Address from XML
	 *
	 * @param contact Element with contact info
	 * @return string
	 */
	private function _address($contact) {
		$address = '';
		if (!empty($contact->Company)) {
			$address .= $contact->Company."\n";
		}
		if (!empty($contact->FirstName) && !empty($contact->LastName)) {
			$address .= $contact->FirstName.' '.$contact->LastName."\n";
		}
		if (isset($contact->Address) && !empty($contact->Address)) {
			$address .= $contact->Address."\n";
		}
		$address .= ($contact->ZipCode > 0 ? $contact->ZipCode." " : "").$contact->Locality."\n";
		if (isset($contact->Phone) && !empty($contact->Phone)) {
			$address .= $contact->Phone."\n";
		}
		if (isset($contact->Mobile) && !empty($contact->Mobile)) {
			$address .= $contact->Mobile."\n";
		}
		$address .= $contact->Email."\n";
		$address .= $contact->URL."\n";

		return (string)trim($address);
	}


	/**
	 * get Last insert.
	 *
	 * @access private
	 * @param mixed $table
	 * @return void
	 */
	private function _get_last_id($name_id, $table) {
		$query =  $this->db->query('select MAX('. $name_id. ') as id FROM '. $table);
		$result = mysqli_fetch_object($query);

		return $result->id;
	}

}