<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Manage languages of API
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeLanguage {

	/**
	 * Strings for current language
	 */
	private $strings = array();

	private $lang;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	function __construct($language = DEFAULT_LANGUAGE) {

		global $config;

		if (in_array($language, $config['available_languages']) && file_exists(ABSOLUTE_PATH.'/language/'.strtolower($language).'.php')) {
			// load language file
			require_once(ABSOLUTE_PATH.'/language/'.strtolower($language).'.php');
			$this->lang = strtolower($language);
		}
		else {
			// load default language file
			require_once(ABSOLUTE_PATH.'/language/de.php');
			$this->lang = 'de';
		}

		$this->strings = $lang;

	}

	/**
	 * Get language string
	 *
	 * @access public
	 * @param  string
	 * @return string
	 */
	public function get($key) {
		if (isset($this->strings[$key])) {
			return $this->strings[$key];
		}

		return $key;
	}

	public function get_lang() {
		return $this->lang;
	}

}