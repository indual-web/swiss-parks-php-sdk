<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/



/**
 * Startup session
 */
@session_start();



/*
|--------------------------------------------------------------------------
| Define API location
|--------------------------------------------------------------------------
|
| 'ABSOLUTE_PATH' = The absolute path on your server where the API is located
| 'WEB_PATH' = The public URL where the API is accessible on your site
*/
define('ABSOLUTE_PATH', "/path/to/your/environment/without/slash");
define('WEB_PATH', "http://www.example.com");



/*
|--------------------------------------------------------------------------
| Include configuration
|--------------------------------------------------------------------------
|
*/
require_once(ABSOLUTE_PATH.'/config.php');



/*
|--------------------------------------------------------------------------
| Include main API classes
|--------------------------------------------------------------------------
|
*/
foreach (glob(ABSOLUTE_PATH.'/classes/*.php') as $file_path) {
	require_once($file_path);
}


/*
|--------------------------------------------------------------------------
| Include custom views
|--------------------------------------------------------------------------
|
*/
foreach (glob(ABSOLUTE_PATH.'/custom/*.php') as $file_path) {
	require_once($file_path);
}