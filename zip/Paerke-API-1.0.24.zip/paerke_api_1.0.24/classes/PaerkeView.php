<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Default view class for API
 *
 * @author indual GmbH
 * @version 1.0
 * @copyright 2012 by indual GmbH
 */
class PaerkeView {

	/**
	 * API object
	 */
	private $api;

	/**
	 * Language object
	 */
	private $lang;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	function __construct($api) {
		$this->api = $api;
		$this->lang = $api->lang;

		$this->target_group_restrictions = array(2 => '50+'); // target groups, which won't be shown in offer detail view (target_group_id => group_name)
	}


	/**
	 * Show offer filter
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_offers_filter($params = array()) {
		$output = "";
		$output .= '<div class="offer_filter">';
		$output .= '<form action="'.$_SERVER['SCRIPT_NAME'].'" method="POST">';
		$output .= '<div class="offer_filter_form">';

		$fieldname = FORM_PREFIX.'filter';

		// Select for categories
		if (!empty($params['categories'])) {
			$output .= '<p class="offer_filter_categories"><label for="'.$fieldname.'">'.$this->lang->get('offer_category').'</label>';
			$output .= '<select id="'.$fieldname.'_categories" name="'.$fieldname.'[categories][]" multiple="multiple" size="1">';
			foreach ($params['categories'] as $label => $childs) {
				if (is_array($childs)) {
					$output .= '<optgroup label="'.$label.'">';
					foreach ($childs as $id => $category) {
						$output .= '	<option value="'.$id.'"'.(is_array($params['selected']['categories']) && in_array($id, $params['selected']['categories']) ? ' selected="selected"' : '').'>'.$category.'</option>';
					}
					$output .= '</optgroup>';
				}
			}
			$output .= '</select></p>';

		}

		$output .= '<script type="text/javascript">
						$(document).ready(function() {
							$("#route_length_slider").slider({
								range: true,
								min: 0,
								max: 50,
								values: [ 0, 50 ],
								step: 1,
								slide: function( event, ui ) {
									$(ui.handle).text((ui.value == 50 ? "+50" : ui.value)+"km");
									$("#offer_filter_route_length_min").val(ui.values[0]);
									$("#offer_filter_route_length_max").val(ui.values[1]);
								},
								change: function( event, ui ) {
									$(ui.handle).text((ui.value == 50 ? "+50" : ui.value)+"km");
								}
							});
							$("#route_length_slider").slider("values", [$("#offer_filter_route_length_min").val(),$("#offer_filter_route_length_max").val()]);
							$("#'.$fieldname.'_categories").multiselect({
								header: true,
								checkAllText: "'.$this->lang->get('general_all').'",
								uncheckAllText: "'.$this->lang->get('general_none').'",
								height: "auto",
								selectedText: "'.sprintf($this->lang->get('offer_selected_category'), '#').'",
								noneSelectedText: "'.$this->lang->get('offer_select_category').'",
								selectedList: 1,
								minWidth: 228
								});
						});
					</script>';

		// Select for users/parks
		if (!empty($params['users']) && count($params['users']) > 1) {
			$output .= '<p class="offer_filter_users"><label for="'.$fieldname.'_park_id">'.$this->lang->get('offer_contact').'</label>';
			$output .= '<select id="'.$fieldname.'_park_id" name="'.$fieldname.'[park_id]">';
			$output .= '	<option value="0">'.$this->lang->get('offer_parks_all').'</option>';
			foreach ($params['users'] as $park_id => $park) {
				$output .= '	<option value="'.$park_id.'"'.($params['selected']['park_id'] == $park_id ? ' selected="selected"' : '').'>'.$park.'</option>';
			}
			$output .= '</select></p>';
		}

		$output .= '<div class="cf"></div>';

		// Input for date_from
		$output .= '<p class="offer_filter_date_from"><label for="'.$fieldname.'_date_from">'.$this->lang->get('offer_date_from').'</label>';
		$output .= '<input type="text" name="'.$fieldname.'[date_from]" id="'.$fieldname.'_date_from" class="datepicker"'.($params['selected']['date_from'] ? ' value="'.$params['selected']['date_from'].'"' : '').' placeholder="'.$this->lang->get('offer_date_from').'" /></p>';

		// Input for date_to
		$output .= '<p class="offer_filter_date_to"><label for="'.$fieldname.'_date_to">'.$this->lang->get('offer_date_to').'</label>';
		$output .= '<input type="text" name="'.$fieldname.'[date_to]" id="'.$fieldname.'_date_to" class="datepicker"'.($params['selected']['date_to'] ? ' value="'.$params['selected']['date_to'].'"' : '').' placeholder="'.$this->lang->get('offer_date_to').'" /></p>';

		// Input for search
		$output .= '<p class="offer_filter_search"><label for="'.$fieldname.'_search">'.$this->lang->get('offer_search').'</label>';
		$output .= '<input type="text" name="'.$fieldname.'[search]" id="'.$fieldname.'_search"'.($params['selected']['search'] ? ' value="'.$params['selected']['search'].'"' : '').' placeholder="'.$this->lang->get('offer_search').'..." /></p>';

		// Route filter
		if ($params['show_route_filter']) {
			$output .= '<span class="route_label">'.$this->lang->get('offer_routes').'</span>';
			$output .= '<input type="hidden" name="'.$fieldname.'[route_length_min]" id="offer_filter_route_length_min" value="'.(isset($params['selected']['route_length_min']) ? $params['selected']['route_length_min'] : '0').'" />';
			$output .= '<input type="hidden" name="'.$fieldname.'[route_length_max]" id="offer_filter_route_length_max" value="'.(isset($params['selected']['route_length_max']) ? $params['selected']['route_length_max'] : '50').'"/>';
			$output .= '<div id="route_length_slider"></div>';
			$output .= '<p class="offer_filter_time_required">';
			$output .= '<label for="'.$fieldname.'_time_required">'.$this->lang->get('offer_time_required').'</label>';

			$output .= '<select id="'.$fieldname.'_time_required" name="'.$fieldname.'[time_required]">';
			$output .= '	<option value="0">'.$this->lang->get('offer_time_required').'</option>';
			$times_array = array($this->lang->get('offer_time_required_2h'), $this->lang->get('offer_time_required_2_4h'), $this->lang->get('offer_time_required_4h'));
			foreach ($times_array as $time) {
				$output .= '	<option value="'.$time.'"'.($params['selected']['time_required'] == $time ? ' selected="selected"' : '').'>'.$time.'</option>';
			}
			$output .= '</select></p>';

			$output .= '<p class="offer_filter_level_technics">';
			$output .= '<label for="'.$fieldname.'_level_technics">'.$this->lang->get('offer_level_technics').'</label>';
			$output .= '<select id="'.$fieldname.'_level_technics" name="'.$fieldname.'[level_technics]">';
			$output .= '	<option value="0">'.$this->lang->get('offer_level_technics').'</option>';
			$level_array = array(1 => $this->lang->get('offer_easy'), 2 => $this->lang->get('offer_average'), 3 => $this->lang->get('offer_difficult'));
			foreach ($level_array as $level => $level_value) {
				$output .= '	<option value="'.$level.'"'.($params['selected']['level_technics'] == $level ? ' selected="selected"' : '').'>'.$level_value.'</option>';
			}
			$output .= '</select></p>';

			$output .= '<p class="offer_filter_level_condition">';
			$output .= '<label for="'.$fieldname.'_level_condition">'.$this->lang->get('offer_level_condition').'</label>';

			$output .= '<select id="'.$fieldname.'_level_condition" name="'.$fieldname.'[level_condition]">';
			$output .= '	<option value="0">'.$this->lang->get('offer_level_condition').'</option>';
			foreach ($level_array as $level => $level_value) {
				$output .= '	<option value="'.$level.'"'.($params['selected']['level_condition'] == $level ? ' selected="selected"' : '').'>'.$level_value.'</option>';
			}
			$output .= '</select></p>';

		}

		$output .= '</div>';
		$output .= '<div class="offer_filter_buttons">';

		// Submit button
		$output .= '<p class="offer_filter_submit"><input type="submit" name="'.$fieldname.'[submit]" value="'.$this->lang->get('offer_search').'" /></p>';

		// Reset button
		if ($params['filter'] == TRUE) {
			$output .= '<p class="offer_filter_reset"><button type="button" name="'.$fieldname.'[reset]" onclick="window.location.href=\''.$_SERVER['SCRIPT_NAME'].'?reset\'">'.$this->lang->get('offer_reset').'</button></p>';
		}

		$output .= '</div>';

		$output .= '</form>';
		$output .= '<div class="cf"></div></div>';

		echo $output;

	}


	/**
	 * Show offer list
	 *
	 * @access public
	 * @param  array
	 * @param  integer
	 * @param  integer
	 * @return void
	 */
	public function show_offers_list($offers, $in_tab = FALSE, $poi = FALSE) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");

		$output = "";

		if (!empty($offers)) {

			foreach ($offers as $offer) {

				if (!empty($offer)) {

					$paramname = PARAM_PREFIX.'offer';
					$offer_detail_url = $_SERVER['SCRIPT_NAME'].(strstr($_SERVER['SCRIPT_NAME'], '?') ? '&amp' : '?').$paramname.'='.$offer->offer_id;

					// Allow to get back to routes
					if ($poi) {
						$offer_detail_url .= '&amp;poi='.$poi.'&amp;tab=poi';
					}

					// Start Offer
					$output .= '<div id="offer_'.$offer->offer_id.'" class="offer_listing'.((isset($offer->images) && (count($offer->images) > 0)) ? ' with_image' : '').'" onclick="window.location.href=\''.$offer_detail_url.'\'">';

					// Offer image
					if (isset($offer->images) && (count($offer->images) > 0)) {
						$output .= '<img class="image" src="'.$offer->images[0]->small.'" alt="'.$offer->title;
						if (!empty($offer->images[0]->copyright)) {
							$output .= ' - &copy; '.$offer->images[0]->copyright;
						}
						$output .= '" width="180" />';
					}

					// Offer title
					$output .= '<h2 class="title"><a href="'.$offer_detail_url.'">'.$offer->title.'</a></h2>';

					// Offer date
					$category_parent_id = (is_array($offer->categories) && !empty($offer->categories)) ? array_values($offer->categories) : NULL;
					$category_parent_id = array_shift($category_parent_id);
					if (isset($offer->date_from) && !empty($offer->date_from) && is_object($category_parent_id) && in_array($category_parent_id->parent_id, array(CATEGORY_EVENT, CATEGORY_RESEARCH))) {
						$date_from = mysql2date($offer->date_from, true);
						$date_to = mysql2date($offer->date_to, true);
						$output .= show_date(array('date_from'=>mysql2form($date_from), 'date_to' => mysql2form($date_to)));
					}

					$output .= '<div class="inner">';

						// Offer description and park
						$output .= '<p class="park">'.$offer->park.'</p>';
						$output .= '<p class="description">'.nl2br($offer->description_medium).'</p>';

						// Offer categories
						$output .= '<ul class="categories">';
						foreach ($offer->categories as $category) {
							$output .= '<li>'.$category->body.'</li>';
						}
						$output .= '</ul>';

					$output .= '</div>';

					$output .= '<div class="cf"></div>';
					$output .= '</div>';
				}
			}

		}
		else {

			$output .= '<p class="no_results">'.$this->lang->get('offer_not_found').'</p>';

		}

		// if true list offer inside a div for tab
		if ($in_tab) {
			return $output;
		}
		else {
			echo $output;
		}

	}


	/**
	 * Show map with offer(s)
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_pagination($page = 1, $total = 1) {

		$output = '<div class="offer_pagination">';

		// previous link
		if ($page > 1) {
			$paramname = FORM_PREFIX.'page';
			$link = $_SERVER['REQUEST_URI'];

			$output .= '<div class="offer_pagination_previous">';

			// set link
			if (strpos($_SERVER['REQUEST_URI'], $paramname)) {
				$link = str_replace($paramname.'='.$page, $paramname.'='.($page-1), $_SERVER['REQUEST_URI']);
			}
			else {
				$link .= (strstr($link, '?') ? '&' : '?').$paramname.'='.($page-1);
			}
			$output .= '<a href="'.$link.'" class="previous">'.$this->lang->get('pagination_prev').'</a>';

			$output .= '</div>';
		}

		// page numbers
		if ($total > 1) {
			$paramname = FORM_PREFIX.'page';

			$output .= '<div class="offer_pagination_pages">';
			for ($i=1 ; $i<=$total ; $i++) {

				// set link
				$link = $_SERVER['REQUEST_URI'];
				if (strpos($_SERVER['REQUEST_URI'], $paramname)) {
					$link = str_replace($paramname.'='.$page, $paramname.'='.$i, $_SERVER['REQUEST_URI']);
				}
				else {
					$link .= (strstr($link, '?') ? '&' : '?').$paramname.'='.$i;
				}
				$output .= '<a href="'.$link.'"'.(($page == $i) ? ' class="current"' : '').'>'.$i.'</a> ';

			}
			$output .= '</div>';
		}

		// next page link
		if ($page < $total) {
			$paramname = FORM_PREFIX.'page';
			$link = $_SERVER['REQUEST_URI'];

			$output .= '<div class="offer_pagination_next">';

			// set link
			if (strpos($_SERVER['REQUEST_URI'], $paramname)) {
				$link = str_replace($paramname.'='.$page, $paramname.'='.($page+1), $_SERVER['REQUEST_URI']);
			}
			else {
				$link .= (strstr($link, '?') ? '&' : '?').$paramname.'='.($page+1);
			}
			$output .= '<a href="'.$link.'" class="next">'.$this->lang->get('pagination_next').'</a>';

			$output .= '</div>';
		}

		$output .= '</div>';

		if ($total > 1) {
			echo $output;
		}

	}


	/**
	 * Show map with offer(s)
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_offers_map($offers, $show_layers_at_start = FALSE, $map_layers = FALSE, $poi_detail = FALSE, $offer_id = FALSE) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeMapHelper.php");
		require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");

		$output = "";

		$output .= '<div class="offer_map_container">';

		$add_markers_function = 'var swissmap;';
		$add_markers_function .= 'function loadSwissMap() {';
		$add_markers_function .= 'swissmap = new SwissMap("#mapContainer", function() {';
		$add_markers_function .= '		var that = this;';

		// Custom map layers
		$map_layers = $this->api->offer->get_custom_layers();


		// Add custom map layers
		if (isset($map_layers) && is_array($map_layers)) {
			// Set quantity of custom layers
			$add_markers_function .= 'this.setCustomLayerQuantity('. (isset($map_layers) ? count($map_layers) : 0) .');';
			foreach ($map_layers as $layer) {

				// set popup content
				$popup = $this->_build_popup($layer);

				// add custom layers with/without layers
				$add_markers_function .= 'this.addCustomMapLayer(	"'.$layer->url.'", { id: "'.$layer->map_layer_id.'", visible: '. (($layer->visible_by_default) ? $layer->visible_by_default : 'false') .', position: '. (($layer->layer_position) ? $layer->layer_position : 0) . $popup .'});';
			}
		}

		$paramname = PARAM_PREFIX.'offer';

		$filter_data = $this->api->get_filter_data();
		$filter_categories = isset($filter_data['categories']) ? $filter_data['categories'] : array();

		$all_categories = $this->api->offer->get_all_categories();

		if (!empty($offers)) {
			$categories = array();
			$category_groups = array();
			$js_output = "";

			foreach ($offers as $offer) {

				if ($offer->latitude > 0 && $offer->longitude > 0) {
					$offer_categories = array();

					$max_level = 0;
					if (!empty($offer->categories)) {
						foreach ($offer->categories as $category) {
							if (!$this->api->is_filter_activated() || count($filter_categories) == 0 || (in_array($category->category_id, $filter_categories) || in_array($category->parent_id, $filter_categories))) {
								$path = $this->api->offer->get_category_path($category->parent_id);
								$category->group = $all_categories[reset($path)];

								if (!in_array($category->group->category_id, array(CATEGORY_PRODUCT, CATEGORY_ACTIVITY))) {

									if (count($path) > $max_level) {
										$offer_categories = array();
										$max_level = count($path);
									}

									$offer_categories[] = $category;
								}
							}
						}
					}

					$marker_id = md5($offer->offer_id);

					$date = FALSE;
					if ($offer->root_category == CATEGORY_EVENT) {
						$marker_id = md5($marker_id.$offer->date_from.$offer->date_to);

						$date_from = mysql2date($offer->date_from, true);
						$date_to = mysql2date($offer->date_to, true);
						$date = show_date(array('date_from'=>mysql2form($date_from), 'date_to' => mysql2form($date_to)));
					}

					$url = $_SERVER['SCRIPT_NAME'].'?'.$paramname.'='.$offer->offer_id;
					$image = (isset($offer->images) && count($offer->images) > 0) ? $offer->images[0]->medium : FALSE;

					$position = convertLatLonToCH1903($offer->latitude, $offer->longitude);

					if (isset($offer->route)) {
						$route = array();
						foreach ($offer->route as $waypoint) {
							$point = convertLatLonToCH1903($waypoint->latitude, $waypoint->longitude);
							$route[] = '['.$point['y'].', '.$point['x'].']';
						}
						$path = '['.implode(',', $route).']';
					}

					$offer_categories_ids = array();
					foreach ($offer_categories as $offer_category) {
						$categories[intval($offer_category->sort)] = $offer_category;
						$category_groups[intval($offer_category->group->sort)] = $offer_category->group;

						$offer_categories_ids[] = $offer_category->sort;
					}

					$js_output .= '		this.addMarkerForMultipleLayers(['.implode(",", $offer_categories_ids).'], function() {
											return {
												id: \''.$marker_id.'\',
												point: new esri.geometry.Point('.$position['y'].', '.$position['x'].', that.spatialReference),
												'.(isset($offer->route) ? ' route: new esri.geometry.Polyline({ paths: ['.$path.'], spatialReference: that.spatialReference }),' : '').'
												attributes: {
													title: \''.addslashes($offer->title).'\',
													'.($date ? ' date: \''.$date.'\',' : '').'
													'.($offer->route_length ? ' route_length: \''.$offer->route_length.' '.$this->lang->get('offer_route_length_km').'\',' : '').'
													'.($offer->time_required ? ' time_required: \''.$offer->time_required.'\',' : '').'
													'.($offer->level_technics ? ' level_technics: \''.$offer->level_technics.'\',' : '').'
													content: '.json_encode($offer->description_medium).',
													'.($image ? ' image: \''.$image.'\',' : '').' link: \''.$url.'\'
												}
											}
										});';

				}
			}

			// create category groups
			foreach ($category_groups as $group) {
				$add_markers_function .= '		this.createOfferLayerGroup('.$group->sort.', \''.addslashes($group->body).'\', \''.$group->marker.'\');';
			}

			// create categories
			foreach ($categories as $category) {
				$add_markers_function .= '		this.createOfferLayer('.$category->sort.', \''.addslashes($category->body).'\', \''.$category->marker.'\', '.$category->group->sort.', '.($this->api->is_filter_activated() ? 'true' : 'false').');';
			}

			$add_markers_function .= $js_output;
		}

		$config = array(
			'cookieOptions' => array('expires' => 1, 'path' => $_SERVER['SCRIPT_NAME']),
			'offerLayerVisibility' => TRUE,
			'lang' => $this->lang->get_lang(),
			'hash' => $this->api->config['api_hash'],
			'base_url' => $this->api->config['base_url'],
			'type' => 'api'
		);

		if (!$poi_detail) {
			$config['cookieName'] = 'swissmap_overview';
			$config['printUrl'] = $this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'?logo=true';
			$config['resetMapExtent'] = FALSE; // set to FALSE if caching is activated
			$config['resetOfferLayerVisibility'] = TRUE;
			$config['overviewMap'] = TRUE;
		}
		else {
			$config['defaultBaseMap'] = 'pixelkarte';
			$config['cookieName'] = 'swissmap_poi_detail';
			$config['disableClustering'] = TRUE;
			$config['fitOfferExtent'] = TRUE;
			$config['printUrl'] = $this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'/'.$offer->offer_id.'?logo=true';
			$config['hasPoi'] = TRUE;
			$config['offerId'] = (isset($offer_id) ? $offer_id : 0);
		}

		$config_ui = array(
			'canvasWidth' => 78
		);

		if ($poi_detail) {
			$config_ui['noPrint'] = TRUE;

			if ($offer->route) {
				$config_ui['showElevationProfile'] = TRUE;
			}
		}

		if (isset($_SESSION[$this->api->session_name]['selectedPark']) && !empty($_SESSION[$this->api->session_name]['selectedPark'])) {
			$config['selectedPark'] = $_SESSION[$this->api->session_name]['selectedPark'];
		}

		// show allways all layers on the map
		if (($this->api->is_filter_activated()) || ($show_layers_at_start == TRUE)) {
			$config['offerLayerVisibility'] = TRUE;
		}

		if (isset($_POST[FORM_PREFIX.'filter']) && !empty($offers)) {
			$config['fitOfferExtent'] = TRUE;
		}

		if ($this->api->is_filter_activated() || isset($_SESSION['offer_detail_view']) && ($_SESSION['offer_detail_view'] == TRUE)) {
			$config['resetMapExtent'] = FALSE;
			$config['resetOfferLayerVisibility'] = FALSE;
			$config['resetMapLayerVisibility'] = FALSE;

			if ($_SESSION['offer_detail_view'] == TRUE) {
				$_SESSION['offer_detail_view'] = FALSE;
			}
		}

		$add_markers_function .= '	}, '.json_encode($config).', '.json_encode($config_ui).');';
		$add_markers_function .= '}';

		if ($poi_detail) {
			return $this->_get_detail_view_output($output, $add_markers_function);
		}
		else {
			$output .= $this->_get_swissmap_html();

			$output .= '<script type="text/javascript">';
			$output .= 'var mapInit = false;';
			$output .= '$(document).ready(function() {';
			$output .= '	var tab = $("#mapContainer").closest(".ui-tabs-panel");';
			$output .= '	if (tab.length > 0) {';
			$output .= '		if ($("#offer_listing_tabs").tabs("option", "selected") == 1) {';
			$output .= '			$("div.offer_pagination").hide();';
			$output .= '			if (!mapInit) {';
			$output .= '				dojo.addOnLoad(function() {';
			$output .= '					loadSwissMap();';
			$output .= '				});';
			$output .= '				mapInit = true;';
			$output .= '			}';
			$output .= '		}';
			$output .= '		$("#offer_listing_tabs").bind("tabsshow.swissmap", function(event, ui) {';
			$output .= '			if (ui.panel == tab[0]) {';
			$output .= '				$("div.offer_pagination").hide();';
			$output .= '				if (!mapInit) {';
			$output .= '					dojo.addOnLoad(function() {';
			$output .= '						loadSwissMap();';
			$output .= '					});';
			$output .= '					mapInit = true;';
			$output .= '				}';
			$output .= '			} else {';
			$output .= '				$("div.offer_pagination").show();';
			$output .= '			}';
			$output .= '		});';
			$output .= '	} else {';
			$output .= '		dojo.addOnLoad(function() {';
			$output .= '			loadSwissMap();';
			$output .= '		});';
			$output .= '	}';
			$output .= '});';
			$output .= $add_markers_function;
			$output .= '</script>';

			$output .= '</div>';

			echo $output;
		}
	}


	/**
	 * Show offer detail page
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function show_offer_detail($offer) {

		$show_subscription = FALSE;
		if (isset($offer->subscription_mandatory) && ($offer->subscription_mandatory == TRUE)) {
			$show_subscription = TRUE;
		}

		$_SESSION['offer_detail_view'] = TRUE;

		$output = "";

		$output .= '<div class="offer_heading">';
		$output .= '	<h1>'.$offer->title.'</h1>';

		if (isset($_GET["poi"])) {
			$output .= '	<button name="back_to_route" class="back" onclick="window.location.href=\''.$_SERVER['SCRIPT_NAME'].(strstr($_SERVER['SCRIPT_NAME'], '?') ? '&amp' : '?').'offer='.$_GET["poi"].(isset($_GET['tab']) ? ('#offer-tab-'.$_GET['tab']) : '#offer-tab-map').'\'">'.$this->lang->get('back_to_route').'</button>';
		}
		else {
			$output .= '	<button name="back_to_overview" class="back" onclick="window.location.href=\''.$_SERVER['SCRIPT_NAME'].'\'">'.$this->lang->get('back_to_overview').'</button>';
		}
		$output .= '	<button name="print" class="print" onclick="swissmap_detail_print(\''.$this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'/'.$offer->offer_id.'?logo=true\', \''.$this->lang->get('swissmap_print_title').'\');">'.$this->lang->get('swissmap_print').'</button>';
		$output .= '<div class="cf"></div></div>';

		$output .= '<div id="offer_detail_tabs">';
		$output .= '	<ul/>';
		$output .= '		<li><a href="#offer-tab-description">'.$this->lang->get('offer_description').'</a></li>';
		$output .= '		<li><a href="#offer-tab-detail">'.$this->lang->get('offer_detail').'</a></li>';
		$output .= '		<li id="offer-li-tab-map"><a href="#offer-tab-map">'.$this->lang->get('offer_map').'</a></li>';
		if ($show_subscription) {
			$output .= '		<li><a href="#offer-tab-subscription">'.$this->lang->get('offer_subscription').'</a></li>';
		}
		if (isset($offer->poi) && !empty($offer->poi)) {
			$output .= '		<li><a href="#offer-tab-poi">'.$this->lang->get('offer_poi').'</a></li>';
		}
		$output .= '	</ul>';
		$output .= '	<div id="offer-tab-description">';
		$output .= '		<div class="offer_detail">';

		$output .= $this->_get_detail_description($offer);

		$output .= '			<div class="cf"></div>';
		$output .= '		</div>';
		$output .= '	</div>';
		$output .= '	<div id="offer-tab-detail">';
		$output .= '		<div class="offer_detail">';

		switch ($offer->root_category) {
			case CATEGORY_EVENT:
				$output .= $this->_get_detail_event($offer);
				break;
			case CATEGORY_PRODUCT:
				$output .= $this->_get_detail_product($offer);
				break;
			case CATEGORY_BOOKING:
				$output .= $this->_get_detail_booking($offer);
				break;
			case CATEGORY_ACTIVITY:
				$output .= $this->_get_detail_activity($offer);
				break;
			case CATEGORY_RESEARCH:
				$output .= $this->_get_detail_research($offer);
				break;
		}

		// Show detail hyperlinks
		if (!empty($offer->hyperlinks) && count($offer->hyperlinks) > 0) {
			$links = '';
			foreach($offer->hyperlinks as $hyperlink) {
				if (in_array($this->lang->get_lang(), explode(',', $hyperlink->language))) {
					$links .= '<a href="'.$hyperlink->url.'" target="_blank">'.$hyperlink->title.'</a><br />';
				}
			}
			if (!empty($links)) {
				$output .= $this->_detail_block($this->lang->get('offer_links'), '<p>'.$links.'</p>');
			}
		}

		$output .= '			<div class="cf"></div>';
		$output .= '		</div>';
		$output .= '	</div>';
		$output .= '	<div class="cf page_break"></div>';
		$output .= '	<div id="offer-tab-map">';

		if (isset($offer->poi) && !empty($offer->poi)) {
			$output .= $this->_get_detail_map_poi($offer);
		}
		else {
			$output .= $this->_get_detail_map($offer);
		}

		$output .= '		<div class="cf"></div>';
		$output .= '	</div>';

		if ($show_subscription) {
			$output .= '	<div id="offer-tab-subscription">';
			$output .= '		<div class="offer_detail">';

			$output .= $this->_get_detail_subscription($offer);

			$output .= '			<div class="cf"></div>';
			$output .= '		</div>';
			$output .= '	</div>';
		}

		// points of interest
		if (isset($offer->poi) && !empty($offer->poi)) {
			$output .= '	<div id="offer-tab-poi">';
			$output .= '		<div class="offer_tab">';
			$output .= 					$this->_get_poi_content($offer->poi, $offer->offer_id);
			$output .= '			<div class="cf"></div>';
			$output .= '		</div>';
			$output .= '	</div>';
		}

		$output .= '</div/>';

		echo $output;

	}


	/**
	 * Get detail description
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_description($offer) {
		$return = "";

		// Images
		if (count($offer->images) > 0) {
			$return .= '<div class="api_images images '.(count($offer->images) > 2 ? 'three' : 'two').'">';
			foreach ($offer->images as $image) {
				$return .= '<a href="'.$image->large.'"';
				if (!empty($image->copyright)) {
					$return .= ' title="&copy; '.$image->copyright.'"';
				}
				$return .= '><img src="'.$image->medium.'" class="image" alt="'.$offer->title.'" /></a>';
				if (!empty($image->copyright)) {
					$return .= '<p class="copyright">&copy; '.$image->copyright.'</p>';
				}
			}
			$return .= '</div>';
		}

		// Description
		$return .= '<p class="description">'.nl2br($offer->description_long).'</p>';

		// Suppliers
		if (isset($offer->suppliers) && !empty($offer->suppliers)) {
			$return .= '<h2>'.$this->lang->get('offer_supplier').'</h2>';
			foreach ($offer->suppliers as $supplier) {
				if ($supplier['is_park_partner'] == 1) {
					$supplier['contact'] = '<span class="partner">'.$this->lang->get('offer_park_partner').'</span>' . $supplier['contact'];
				}
				$return .= $this->_detail_block('', $supplier['contact'], 'park');
			}
		}

		// Institution
		if (isset($offer->institution) && !empty($offer->institution) && ($offer->institution != $offer->contact) && ($offer->root_category != CATEGORY_EVENT) && ($offer->root_category != CATEGORY_RESEARCH)) {
			if ($offer->institution_is_park_partner == 1) {
				$offer->institution = '<span class="partner">'.$this->lang->get('offer_park_partner').'</span>' . $offer->institution;
			}
			$return .= $this->_detail_block($this->lang->get('offer_organizer'), $offer->institution, 'park');
		}

		// Park
		if ($offer->root_category != CATEGORY_RESEARCH) {
			if ($offer->contact_is_park_partner == 1) {
				$offer->contact = '<span class="partner">'.$this->lang->get('offer_contact').'</span>' . $offer->contact;
			}
			$return .= $this->_detail_block($this->lang->get('offer_contact'), $offer->contact, 'park');
		}

		// TargetGroups
		if (count($offer->target_groups) > 0) {
			if (is_array($this->target_group_restrictions)) {
				foreach($this->target_group_restrictions as $target_group_id => $name) {
					if (array_key_exists($target_group_id, $offer->target_groups)) {
						unset($offer->target_groups[$target_group_id]);
					}
				}
			}
			$target_groups = "<ul><li>".implode("</li><li>", $offer->target_groups)."</li></ul>";
			$return .= $this->_detail_block($this->lang->get('offer_target_group'), $target_groups, 'target_groups');
		}

		// Additional Info
		$additional_info = array();
		if (!empty($offer->barrier_free)) $additional_info[] = $this->lang->get('offer_barrier_free');
		if (!empty($offer->learning_opportunity)) $additional_info[] = $this->lang->get('offer_learning_opportunity');
		if (!empty($offer->child_friendly)) $additional_info[] = $this->lang->get('offer_child_friendly');
		if (!empty($offer->park_day)) $additional_info[] = $this->lang->get('offer_park_day');
		if (!empty($offer->enjoy_week)) $additional_info[] = $this->lang->get('offer_enjoy_week');
		$additional_info = (count($additional_info) > 0) ? "<ul><li>".implode("</li><li>", $additional_info)."</li></ul>\n" : "";
		$return .= $this->_detail_block($this->lang->get('offer_additional_info'), $additional_info.$offer->additional_informations, 'additional_informations');

		// Documents
		if (isset($offer->documents) && (count($offer->documents) > 0)) {
			$return .= '<div class="documents">';
			$return .= '	<h2>'.$this->lang->get('offer_documents_public').'</h2>';
			$return .= '	<ul>';

			foreach ($offer->documents as $document) {
				$return .= '		<li class="'.pathinfo($document->url, PATHINFO_EXTENSION).'">';
				$return .= '			<a href="'.$document->url.'" target="_blank">'.($document->title ? $document->title : $document->url).'</a>';
				$return .= '		</li>';
			}

			$return .= '	</ul>';
			$return .= '</div>';
		}

		return $return;
	}


	/**
	 * Get Poi content
	 * @access private
	 * @param mixed $pois
	 * @return list view with offers
	 */
	private function _get_poi_content($pois, $offer_id) {
		$offers = $this->api->show_offer_poi_list($pois);
		$output = $this->show_offers_list($offers, true, $offer_id);
		return $output;
	}


	/**
	 * Get detail view
	 *
	 * @access private
	 * @param mixed $return
	 * @param mixed $add_markers_function
	 * @return void
	 */
	private function _get_detail_view_output($return, $add_markers_function) {

		$return = isset($return) ? $return : '';
		$return .= $this->_get_swissmap_html();
		$return .= '<script type="text/javascript">';
		$return .= '$(document).ready(function() {';
		$return .= '	var tab = $("#mapContainer").closest(".ui-tabs-panel");';
		$return .= '	if (tab.length > 0) {';
		$return .= '		$("#offer_detail_tabs").bind("tabsshow.offer_map", function(event, ui) {';
		$return .= '			if (ui.panel == tab[0]) {';
		$return .= '				$("#offer_detail_tabs").unbind("tabsshow.offer_map");';
		$return .= '				dojo.addOnLoad(function() {';
		$return .= '					loadSwissMap();';
		$return .= '				});';
		$return .= '			}';
		$return .= '		});';
		$return .= '		if ($(".ui-state-active a").attr("href") == "#offer-tab-map") {';
		$return .= '			dojo.addOnLoad(function() {';
		$return .= '				loadSwissMap();';
		$return .= '			});';
		$return .= '		}';
		$return .= '	} else {';
		$return .= '		dojo.addOnLoad(function() {';
		$return .= '			loadSwissMap();';
		$return .= '		});';
		$return .= '	}';
		$return .= '});';
		$return .= 'function swissmap_detail_print(url, title) {';
		$return .= '	if ((this.swissmap != undefined) && (this.swissmap.ui != undefined)) {';
		$return .= '		var params = this.swissmap.ui._getParamsForPrint(true);';
		$return .= '		window.open(url+\'?\'+params, title, \'width=820,height=1140\');';
		$return .= '	}';
		$return .= '	else {';
		$return .= '		window.open(url, title, \'width=820,height=1140\');';
		$return .= '	}';
		$return .= '}';
		$return .= $add_markers_function;
		$return .= '</script>';

		$return .= '</div>';

		return $return;
	}


	/**
	 * Get event detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_event($offer) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");

		$return = "";

		// Dates
		if ($offer->dates && count($offer->dates) > 0) {
			$return .= '<div class="dates">';
			$return .= '	<h2>'.$this->lang->get('offer_dates').'</h2>';
			$return .= '	<ul>';

			foreach ($offer->dates as $date) {
				$return .= '		<li>'.show_date(array('date_from'=>mysql2form($date->date_from), 'date_to' => mysql2form($date->date_to))).'</li>';
			}

			$return .= '	</ul>';
			$return .= '</div>';
		}

		// Institution
		$return .= $this->_detail_block($this->lang->get('offer_event_location'), $offer->institution, 'event_location address');

		// LocationDetails
		$return .= $this->_detail_block($this->lang->get('offer_location_details'), $offer->location_details, 'location_details');

		// PublicTransportStop
		$return .= $this->_detail_block($this->lang->get('offer_public_transport_stop'), $offer->public_transport_stop, 'public_transport_stop');

		// Details
		$return .= $this->_detail_block($this->lang->get('offer_date_details'), $offer->details, 'details');

		// Price
		$return .= $this->_detail_block($this->lang->get('offer_price'), $offer->price, 'price');

		return $return;
	}


	/**
	 * Get product detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_product($offer) {
		$return = "";

		// OpeningHours
		$return .= $this->_detail_block($this->lang->get('offer_opening_hours'), $offer->opening_hours, 'opening_hours');

		// PublicTransportStop
		$return .= $this->_detail_block($this->lang->get('offer_public_transport_stop'), $offer->public_transport_stop, 'public_transport_stop');

		// Price
		$return .= $this->_detail_block($this->lang->get('offer_price'), $offer->price, 'price');

		// Infrastructure
		$infrastructure = array();
		if (!empty($offer->number_of_rooms)) $infrastructure[] = sprintf($this->lang->get('offer_rooms'), $offer->number_of_rooms);
		if (!empty($offer->has_conference_room)) $infrastructure[] = $this->lang->get('offer_conference_room');
		if (!empty($offer->has_playground)) $infrastructure[] = $this->lang->get('offer_playground');
		if (!empty($offer->has_picnic_place)) $infrastructure[] = $this->lang->get('offer_picnic_place');
		if (!empty($offer->has_fireplace)) $infrastructure[] = $this->lang->get('offer_fireplace');
		if (!empty($offer->has_washrooms)) $infrastructure[] = $this->lang->get('offer_washroom');
		$infrastructure = (count($infrastructure) > 0) ? "<ul><li>".implode("</li><li>", $infrastructure)."</li></ul>\n" : "";
		$return .= $this->_detail_block($this->lang->get('offer_infrastructure'), $infrastructure.$offer->other_infrastructure, 'infrastructure');

		// Saison
		$season = $this->lang->get('offer_all_season');
		if (!empty($offer->available_from)) $season = $this->lang->get('general_from_2').' '.$offer->available_from;
		if (!empty($offer->available_to)) $season .= ' '.$this->lang->get('general_to').' '.$offer->available_to;
		$return .= $this->_detail_block($this->lang->get('offer_saison'), $season, 'saison');

		return $return;
	}


	/**
	 * Get booking detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_booking($offer) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");

		$return = "";

		// Dates
		if ($offer->dates && count($offer->dates) > 0) {
			$return .= '<div class="dates">';
			$return .= '	<h2>'.$this->lang->get('offer_execution_times').'</h2>';
			$return .= '	<ul>';

			foreach ($offer->dates as $date) {
				$return .= '		<li>'.show_date(array('date_from'=>mysql2form($date->date_from), 'date_to' => mysql2form($date->date_to))).'</li>';
			}

			$return .= '	</ul>';
			$return .= '</div>';
		}

		// PublicTransportStop
		$return .= $this->_detail_block($this->lang->get('offer_public_transport_stop'), $offer->public_transport_stop, 'public_transport_stop');

		// Benefits
		$return .= $this->_detail_block($this->lang->get('offer_benefits'), $offer->benefits, 'benefits');

		// Requirements
		$return .= $this->_detail_block($this->lang->get('offer_requirements'), $offer->requirements, 'requirements');

		// Price
		$return .= $this->_detail_block($this->lang->get('offer_price'), $offer->price, 'price');

		// Accommodations
		if (isset($offer->accommodations) && !empty($offer->accommodations)) {
			$return .= '<h2>'.$this->lang->get('offer_accommodation').'</h2>';
			foreach ($offer->accommodations as $accommodation) {
				$return .= $this->_detail_block('', $accommodation, 'park');
			}
		}

		return $return;
	}


	/**
	 * Get activity detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_activity($offer) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");
		$return = "";

		// Infrastructure
		$infrastructure = array();
		if (!empty($offer->has_playground)) $infrastructure[] = $this->lang->get('offer_playground');
		if (!empty($offer->has_picnic_place)) $infrastructure[] = $this->lang->get('offer_picnic_place');
		if (!empty($offer->has_fireplace)) $infrastructure[] = $this->lang->get('offer_fireplace');
		if (!empty($offer->has_washrooms)) $infrastructure[] = $this->lang->get('offer_washroom');
		$infrastructure = (count($infrastructure) > 0) ? "<ul><li>".implode("</li><li>", $infrastructure)."</li></ul>\n" : "";
		$return .= $this->_detail_block($this->lang->get('offer_infrastructure'), $infrastructure.$offer->other_infrastructure, 'infrastructure');

		// StartPlace
		$start_place = "";
		$start_place .= $this->_get_string($offer->start_place_info, '</dd>', '<dt>'.$this->lang->get('offer_start_place').'</dt><dd>');
		$start_place .= $this->_get_string($offer->public_transport_start, '</dd>', '<dt>'.$this->lang->get('offer_public_transport_stop').'</dt><dd>');
		$start_place .= $this->_get_string($offer->start_place_altitude, ' '.$this->lang->get('offer_altitude_meter').'</dd>', '<dt>'.$this->lang->get('offer_altitude').'</dt><dd>');
		$return .= $this->_detail_block($this->lang->get('offer_start_place'), $this->_get_string($start_place, '</dl>', '<dl>'), 'start_place');

		// GoalPlace
		$goal_place = "";
		$goal_place .= $this->_get_string($offer->goal_place_info, '</dd>', '<dt>'.$this->lang->get('offer_goal_place').'</dt><dd>');
		$goal_place .= $this->_get_string($offer->public_transport_stop, '</dd>', '<dt>'.$this->lang->get('offer_public_transport_stop').'</dt><dd>');
		$goal_place .= $this->_get_string($offer->goal_place_altitude, ' '.$this->lang->get('offer_altitude_meter').'</dd>', '<dt>'.$this->lang->get('offer_altitude').'</dt><dd>');
		$return .= $this->_detail_block($this->lang->get('offer_goal_place'), $this->_get_string($goal_place, '</dl>', '<dl>'), 'goal_place');

		// RouteInfo
		$route_info = "";
		$route_info .= $this->_get_string($offer->route_length, ' '.$this->lang->get('offer_route_length_km').'</dd>', '<dt>'.$this->lang->get('offer_route_length').'</dt><dd>');
		$route_info .= $this->_get_string($offer->untarred_route_length, ' '.$this->lang->get('offer_route_length_km').'</dd>', '<dt>'.$this->lang->get('offer_untarred_route_length').'</dt><dd>');
		$route_info .= $this->_get_string($offer->altitude_differential, ' '.$this->lang->get('offer_altitude_meter').'</dd>', '<dt>'.$this->lang->get('offer_altitude_differential').'</dt><dd>');
		$route_info .= $this->_get_string($offer->altitude_ascent, ' '.$this->lang->get('offer_altitude_meter').'</dd>', '<dt>'.$this->lang->get('offer_altitude_ascent').'</dt><dd>');
		$route_info .= $this->_get_string($offer->altitude_descent, ' '.$this->lang->get('offer_altitude_meter').'</dd>', '<dt>'.$this->lang->get('offer_altitude_descent').'</dt><dd>');
		$route_info .= $this->_get_string($offer->time_required, '</dd>', '<dt>'.$this->lang->get('offer_time_required').'</dt><dd>');
		$route_info .= $this->_get_string($offer->level_technics, '</dd>', '<dt>'.$this->lang->get('offer_level_technics').'</dt><dd>');
		$route_info .= $this->_get_string($offer->level_condition, '</dd>', '<dt>'.$this->lang->get('offer_level_condition').'</dt><dd>');
		$return .= $this->_detail_block($this->lang->get('offer_route_info'), $this->_get_string($route_info, '</dl>', '<dl>'), 'route_info');

		// Price
		$return .= $this->_detail_block($this->lang->get('offer_price'), $offer->price, 'price');

		// CateringInformations
		$return .= $this->_detail_block($this->lang->get('offer_catering_informations'), $offer->catering_informations, 'catering_informations');

		// MaterialRent
		$return .= $this->_detail_block($this->lang->get('offer_material_rent'), $offer->material_rent, 'material_rent');

		// SafetyInstructions
		$return .= $this->_detail_block($this->lang->get('offer_safety_instructions'), $offer->safety_instructions, 'safety_instructions');

		// Signalization
		$return .= $this->_detail_block($this->lang->get('offer_signalization'), $offer->signalization, 'signalization');

		// Dates
		if ($offer->dates && count($offer->dates) > 0) {
			$return .= '<div class="dates">';
			$return .= '	<h2>'.$this->lang->get('offer_saison').'</h2>';
			$return .= '	<ul>';

			foreach ($offer->dates as $date) {
				$return .= '		<li>'.show_date(array('date_from'=>mysql2form($date->date_from), 'date_to' => mysql2form($date->date_to))).'</li>';
			}

			$return .= '	</ul>';
			$return .= '</div>';
		}

		return $return;
	}


	/**
	 * Get research detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_research($offer) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeDateHelper.php");

		$return = "";

		// Dates
		if ($offer->dates && count($offer->dates) > 0) {
			$return .= '<div class="dates">';
			$return .= '	<h2>'.$this->lang->get('offer_dates').'</h2>';
			$return .= '	<ul>';

			foreach ($offer->dates as $date) {
				$return .= '		<li>'.show_date(array('date_from'=>mysql2form($date->date_from), 'date_to' => mysql2form($date->date_to))).'</li>';
			}

			$return .= '	</ul>';
			$return .= '</div>';
		}

		// Institution
		$return .= $this->_detail_block($this->lang->get('offer_research_responsibility'), $offer->institution, 'event_location address');

		// Contact
		$return .= $this->_detail_block($this->lang->get('offer_contact'), $offer->institution, 'event_location address');

		return $return;
	}


	/**
	 * get overview map with POI elements
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_map_poi($offer) {

		// merge offer with poi offer
		$offers = $this->api->show_offer_poi_list($offer->poi);
		array_push($offers, $offer);

		// call overview and return content
		return $this->show_offers_map($offers, NULL, NULL, TRUE, $offer->offer_id);
	}



	/**
	 * Get detail map
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_map($offer) {
		require_once(ABSOLUTE_PATH."/helpers/PaerkeMapHelper.php");

		$return = "";

		$return .= '<div class="offer_map_container">';

		$add_markers_function = 'var swissmap;';
		$add_markers_function .= 'function loadSwissMap() {';
		$add_markers_function .= '	swissmap = new SwissMap("#mapContainer", function() {';
		$add_markers_function .= '		var that = this;';


		// Custom Map Layers
		$map_layers = $this->api->offer->get_custom_layers();


		// Add custom map layers
		if (isset($map_layers) && is_array($map_layers)) {
			// Set quantity of custom layers
			$add_markers_function .= 'this.setCustomLayerQuantity('. (isset($map_layers) ? count($map_layers) : 0) .');';
			foreach ($map_layers as $layer) {
				$popup = $this->_build_popup($layer);
				$add_markers_function .= 'this.addCustomMapLayer("'.$layer->url.'", { id: "'.$layer->map_layer_id.'", position: '. (($layer->layer_position) ? $layer->layer_position : 0). ', visible: '. (($layer->visible_by_default) ? $layer->visible_by_default : 'false'). $popup .' });';
			}
		}

		$paramname = PARAM_PREFIX.'offer';

		$all_categories = $this->api->offer->get_all_categories();

			$offer_category = NULL;
			$offer_category_group = NULL;
			$current_level = 0;
			foreach ($offer->categories as $category) {
				$path = $this->api->offer->get_category_path($category->parent_id);

				if (count($path) > $current_level) {
					$offer_category_group = $all_categories[reset($path)];
					$offer_category = $category;
					$current_level = count($path);
				}
			}

			$categories = $this->api->offer->get_all_categories();


			$add_markers_function .= '		var marker;';
			$add_markers_function .= '		this.createOfferLayerGroup('.$offer_category_group->sort.', \''.addslashes($offer_category_group->body).'\');';
			$add_markers_function .= '		this.createOfferLayer('.$offer_category->category_id.', \''.addslashes($offer_category->body).'\', \''.$offer_category->marker.'\', '.$offer_category_group->sort.');';

			if ($offer->latitude > 0 && $offer->longitude > 0) {
				$position = convertLatLonToCH1903($offer->latitude, $offer->longitude);

				if (isset($offer->route) && !empty($offer->route)) {
					$route = array();
					foreach ($offer->route as $waypoint) {
						$point = convertLatLonToCH1903($waypoint->latitude, $waypoint->longitude);
						$route[] = '['.$point['y'].', '.$point['x'].']';
					}
					$path = '['.implode(',', $route).']';
				}

				$add_markers_function .= '		this.addMarkerForLayer('.$offer_category->category_id.', function() { return { point: new esri.geometry.Point('.$position['y'].', '.$position['x'].', that.spatialReference),'.((isset($offer->route) && !empty($offer->route)) ? ' route: new esri.geometry.Polyline({ paths: ['.$path.'], spatialReference: that.spatialReference }),' : '').' symbol: \''.$offer_category->marker.'\' } });';
			}

		$config = array(
			'defaultBaseMap' => 'pixelkarte',
			'cookieName' => 'swissmap_detail',
			'cookieOptions' => array('expires' => 1, 'path' => $_SERVER['SCRIPT_NAME']),
			'offerLayerVisibility' => TRUE,
			'disableClustering' => TRUE,
			'fitOfferExtent' => TRUE,
			'lang' => $this->lang->get_lang(),
			'hash' => $this->api->config['api_hash'],
			'base_url' => $this->api->config['base_url'],
			'type' => 'api',
			'printUrl' => $this->api->config['base_url'].$this->lang->get_lang().'/export/iframe/print/'.$this->api->config['api_hash'].'/'.$offer->offer_id.'?logo=true'
		);

		$config_ui = array(
			'canvasWidth' => 78,
			'sidebarVisible' => FALSE,
			'noPrint' => TRUE
		);

		if (isset($_SESSION[$this->api->session_name]['selectedPark']) && !empty($_SESSION[$this->api->session_name]['selectedPark'])) {
			$config['selectedPark'] = $_SESSION[$this->api->session_name]['selectedPark'];
		}

		if (isset($offer->route) && !empty($offer->route)) {
			$config_ui['showElevationProfile'] = TRUE;
		}

		$add_markers_function .= '	}, '.json_encode($config).', '.json_encode($config_ui).');';
		$add_markers_function .= '}';

		return $this->_get_detail_view_output($return, $add_markers_function);
	}


	/**
	 * Returns HTML required for displaying the SwissMap
	 *
	 * @access private
	 * @return string
	 */
	private function _get_swissmap_html() {
		$output  = '<div id="mapContainer">';
		$output .= '	<div class="mapToolbar">';
		$output .= '		<div class="mapToolbarSelects">';
		$output .= '			<select class="mapBasemapSelect" name="basemapSelect">';
		$output .= '				<option value="0">'.$this->lang->get('swissmap_basemap').'</option>';
		$output .= '			</select>';
		$output .= '			<select class="mapParkSelect" name="parkSelect">';
		$output .= '				<option value="all">'.$this->lang->get('swissmap_select_all_parks').'</option>';
		$output .= '			</select>';
		$output .= '		</div>';
		$output .= '		<div class="mapToolbarSearch">';
		$output .= '			<input class="mapSearchInput" type="text" name="searchInput" value="'.$this->lang->get('swissmap_search').'" />';
		$output .= '		</div>';
		$output .= '		<div class="mapToolbarButtons">';
		$output .= '			<button class="mapHomeButton" title="'.$this->lang->get('swissmap_home_title').'">'.$this->lang->get('swissmap_home').'</button>';
		$output .= '			<button class="mapBackButton" title="'.$this->lang->get('swissmap_back_title').'">'.$this->lang->get('swissmap_back').'</button>';
		$output .= '			<button class="mapForwardButton" title="'.$this->lang->get('swissmap_next_title').'">'.$this->lang->get('swissmap_next').'</button>';
		$output .= '			<button class="mapToolsButton" title="'.$this->lang->get('swissmap_tools_title').'">'.$this->lang->get('swissmap_tools').'</button>';
		$output .= '			<button class="mapPrintButton" title="'.$this->lang->get('swissmap_print_title').'">'.$this->lang->get('swissmap_print').'</button>';
		$output .= '			<button class="mapHelpButton" title="'.$this->lang->get('swissmap_help_title').'">'.$this->lang->get('swissmap_help').'</button>';
		$output .= '			<button class="mapToggleLayersButton">'.$this->lang->get('swissmap_hide_sidebar').'</button>';
		$output .= '		</div>';
		$output .= '		<div class="cf"></div>';
		$output .= '	</div>';
		$output .= '	<div id="mapCanvasContainer" class="mapCanvasContainer">';
		$output .= '		<div id="mapCanvas" class="mapCanvas">';
		$output .= '			<div class="mapLoading">'.$this->lang->get('swissmap_loading').'</div>';
		$output .= '			<div class="mapControls">';
		$output .= '				<button class="mapZoomInButton">'.$this->lang->get('swissmap_zoom_in').'</button>';
		$output .= '				<div class="mapZoomSlider"></div>';
		$output .= '				<button class="mapZoomOutButton">'.$this->lang->get('swissmap_zoom_out').'</button>';
		$output .= '			</div>';
		$output .= '			<div class="mapCopyright">';
		$output .= '				<p>© Copyright: Netzwerk Schweizer Pärke<br />';
		$output .= '				'.$this->lang->get('swissmap_source_swisstopo').'</p>';
		$output .= '			</div>';
		$output .= '			<div id="mapOverview"></div>';
		$output .= '			<div class="mapOverviewToggle ui-icon ui-icon-triangle-1-se"></div>';
		$output .= '		</div>';
		$output .= '		<div class="cf"></div>';
		$output .= '		<div id="mapElevationChart"></div>';
		$output .= '	</div>';
		$output .= '	<div class="mapSidebar">';
		$output .= '		<div class="mapInformation">';
		$output .= '			<div class="inner">';
		$output .= '				<div class="mapPrint">';
		$output .= '					<div class="mapPrintClose"></div>';
		$output .= '					<h3>'.$this->lang->get('swissmap_print').'</h3>';
		$output .= '					<div class="mapPrintActions">';
		$output .= '						<button class="mapPrintPreview">'.$this->lang->get('swissmap_print').'</button>';
		$output .= '						<button class="mapPrintCancel">'.$this->lang->get('swissmap_cancel').'</button>';
		$output .= '					</div>';
		$output .= '				</div>';
		$output .= '				<div class="mapTools">';
		$output .= '					<div class="mapToolsClose"></div>';
		$output .= '					<h3>'.$this->lang->get('swissmap_tools').'</h3>';
		$output .= '					<div class="mapToolsMeasurement">';
		$output .= '						<input type="radio" name="mapToolsTool" value="none" checked="checked" id="mapToolsNone" class="mapToolsNone" /><label for="mapToolsNone">'.$this->lang->get('swissmap_tools_none').'</label>';
		$output .= '						<input type="radio" name="mapToolsTool" value="point" id="mapToolsPoint" class="mapToolsPoint" /><label for="mapToolsPoint">'.$this->lang->get('swissmap_tools_point').'</label>';
		$output .= '						<input type="radio" name="mapToolsTool" value="distance" id="mapToolsDistance" class="mapToolsDistance" /><label for="mapToolsDistance">'.$this->lang->get('swissmap_tools_distance').'</label>';
		$output .= '						<input type="radio" name="mapToolsTool" value="area" id="mapToolsArea" class="mapToolsArea" /><label for="mapToolsArea">'.$this->lang->get('swissmap_tools_area').'</label>';
		$output .= '					</div>';
		$output .= '					<div class="mapToolsMeasurementResult">'.$this->lang->get('swissmap_tools_choose_tool').'</div>';
		$output .= '				</div>';
		$output .= '				<div class="mapOffers">';
		$output .= '					<h3>'.$this->lang->get('swissmap_offers').'</h3>';
		$output .= '				</div>';
		$output .= '				<div class="mapLayers">';
		$output .= '					<h3>'.$this->lang->get('swissmap_baseinfo').'</h3>';
		$output .= '				</div>';
		$output .= '				<div class="mapInfo">';
		$output .= '					<h3>'.$this->lang->get('swissmap_coordinates').'</h3>';
		$output .= '					<div class="mapInfoCoordinates"></div>';
		$output .= '				</div>';
		$output .= '			</div>';
		$output .= '		</div>';
		$output .= '		<div class="mapLegend">';
		$output .= '			<div class="inner">';
		$output .= '				<div class="mapLegendClose"></div>';
		$output .= '				<h3 class="mapLegendTitle"></h3>';
		$output .= '				<div class="mapLegendContent"></div>';
		$output .= '				<div class="mapLegendDescription"></div>';
		$output .= '			</div>';
		$output .= '		</div>';
		$output .= '	</div>';
		$output .= '	<div class="cf"></div>';
		$output .= '</div>';

		return $output;
	}


	/**
	 * Get subscription detail
	 *
	 * @access private
	 * @param mixed $offer
	 * @return void
	 */
	private function _get_detail_subscription($offer) {

		$return = '<p class="description">'.(($offer->subscription_mandatory == 2) ? $this->lang->get('offer_subscription_info_recommended') : $this->lang->get('offer_subscription_info_mandatory')).'</p>';

		// Subscribe now button!
		if ($offer->online_subscription_enabled == 1) {
			$subscribe_button = '<button class="button" type="button" name="subscribe_now" onclick="window.open(\''.$this->api->config['base_url'].'subscription/subscriber/'.$offer->offer_id.'\');">'.$this->lang->get('offer_subscription_subscribe_now').'</button>';
			$return .= $this->_detail_block('', $subscribe_button, 'subscription_subscribe_now');
		}

		// SubscriptionContact
		if (!empty($offer->subscription_contact)) {
			$return .= $this->_detail_block($this->lang->get('offer_subscription_contact'), $offer->subscription_contact, 'subscription_contact address');
		}

		// SubscriptionLink
		if (!empty($offer->subscription_link)) {
			$return .= $this->_detail_block($this->lang->get('offer_subscription_link'), '<a href="'.$offer->subscription_link.'" target="_blank">'.$offer->subscription_link.'</a>', 'subscription_link');
		}

		// SubscriptionDetails
		if (!empty($offer->subscription_details)) {
			$return .= $this->_detail_block($this->lang->get('offer_subscription_details'), $offer->subscription_details, 'subscription_details');
		}

		return $return;
	}


	/**
	 * Get string
	 *
	 * @access private
	 * @param mixed $string
	 * @param string $suffix (default: "")
	 * @param string $prefix (default: "")
	 * @return void
	 */
	private function _get_string($string, $suffix = "", $prefix = "") {
		if (!empty($string)) {
			return $prefix.$string.$suffix;
		}

		return "";
	}


	/**
	 * Truncate string
	 *
	 * @access private
	 * @param mixed $string
	 * @param mixed $length
	 * @return void
	 */
	private function _truncate_string($string, $length) {
		if (mb_strlen($string) > $length) {
			return mb_substr($string, 0, $length)."...";
		}

		return $string;
	}


	/**
	 * Prepare detail block
	 *
	 * @access private
	 * @param mixed $title
	 * @param mixed $content
	 * @param string $class (default: "")
	 * @return void
	 */
	private function _detail_block($title, $content, $class = "") {

		$return = "";

		if (!empty($content)) {
			$return .= '<div class="api_detail_block '.$class.'">';

			if (!empty($title)) {
				$return .= '	<h2>'.$title.'</h2>';
			}

			$return .= $this->_auto_text_format($content);
			$return .= '</div>';
		}

		return $return;
	}


	/**
	 * Auto text format
	 *
	 * @access private
	 * @param mixed $string
	 * @return void
	 */
	private function _auto_text_format($string) {
		$return = "";

		$html_tags = array('ul', 'li', 'ol', 'dl', 'dd');

		$paragraphs = explode("\n", $string);
		foreach ($paragraphs as $p) {
			if (substr($p, 0, 7) == 'http://') {
				$return .= "<p><a href=\"".$p."\" target=\"_blank\">".$p."</a></p>";
			}
			else if (!preg_match("/\<(".implode("|", $html_tags).")\>/i", $p)) {
				$return .= "<p>".$p."</p>\n";
			}
			else {
				$return .= $p;
			}
		}

		return $return;
	}


	/**
	 * Build popup of custom layer
	 *
	 * @access private
	 * @param mixed $layer
	 * @return void
	 */
	private function _build_popup($layer) {

		$popup = ', popup: { ';

		// set title
		$popup .= isset($layer->popup_title) ? ('title: "'. $layer->popup_title .'", ') : NULL;

		// set logo with size
		if (isset($layer->popup_logo)) {
			$popup .= 'logo: "'. $this->api->config['base_url'].$layer->popup_logo .'", ';
			$popup .= (isset($layer->popup_logo_width) && ($layer->popup_logo_width > 0)) ? ('logo_width: "'. $layer->popup_logo_width .'",  ') : 'width : "auto",';
			$popup .= (isset($layer->popup_logo_height) && ($layer->popup_logo_height > 0)) ? ('logo_height: "'. $layer->popup_logo_height .'",  ') : 'height :"auto",';
		}

		// set content
		$popup .= isset($layer->popup_content) ? ('content: '. json_encode($layer->popup_content) .' ') : '';
		$popup .= ' }';

		return $popup;

	}


	/*
	 * Helper func: Transform mysql date to readable version
	 *
	 * @access public
	 * @param string
	 * @param bool
	 * @param bool
	 */
	public function mysql2date($mysql_date, $time = false, $ts = false) {
		$date = mb_substr($mysql_date, 0, 10);
		$date_time = '';
		if ($time != false) {
			$date_time = ' '.mb_substr($mysql_date, 11, 5);
		}

		$date_explode = explode("-", $date);

		if (count($date_explode) < 3 || (intval($date_explode[0]) == 0) && (intval($date_explode[1]) == 0) && (intval($date_explode[2]) == 0)) {
			return '';
		}

		$date_explode_ts = mktime(0, 0, 0, $date_explode[1], $date_explode[2], $date_explode[0]);
		if ($ts == true) {
			return $date_explode_ts;
		}
		return '<strong>'.date('d.m.Y', $date_explode_ts).'</strong>'.$date_time;
	}

}