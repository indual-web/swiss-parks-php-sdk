<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| Global configuration for Parks API
|
*/

$config = array();


/*
|--------------------------------------------------------------------------
| API Hash Key
|--------------------------------------------------------------------------
|
| This hash is needed to import the data via XML.
| Create an export configuration on http://angebote.paerke.ch and
| put your Hashkey in here.
|
*/
$config['api_hash'] = "insert-your-hash-here";


/*
|--------------------------------------------------------------------------
| Your park
|--------------------------------------------------------------------------
|
| Set your park ID here.
|
*/
$config['park_id'] = NULL;


/*
|--------------------------------------------------------------------------
| MySQL Database
|--------------------------------------------------------------------------
|
| A MySQL Database is required to use the API.
| Imported offers will be stored there for better performance.
|
*/
$config['db_hostname'] = "localhost";
$config['db_username'] = "root";
$config['db_password'] = "root";
$config['db_database'] = "parks_api";


/*
|--------------------------------------------------------------------------
| Custom view
|--------------------------------------------------------------------------
|
| Set your custom view, located in your "custom" folder.
| example: "MyView"
|
*/
$config['class_view'] = "MyView";


/*
|--------------------------------------------------------------------------
| Template
|--------------------------------------------------------------------------
|
| Set the template placed in the parks_api/template/ folder.
| Create your individual template by creating your own folder,
| copied from the standard folder.
|
 */
$config['template_folder'] = 'standard';


/*
|--------------------------------------------------------------------------
| Custom view options
|--------------------------------------------------------------------------
|
| 'always_show_filter' => Show filter on detail pages
| 'show_route_filter' => Show route filter
| 'show_target_group_filter' => Show target group filter
| 'show_route_filter_min_count' => Define minimum activities for route filter
| 'offers_per_page' => How many offers should be displayed per page?
| 'n_th_point' => Each n-th point of routes shown on the overview map (speeds up overviews with map)
| 'n_th_point_min_count' => Routes with less than this amount of route points won't be shortened
| 'pagination_max_numbers' => Define how many pages should be displayed in the pagination (in overviews)
| 'detail_thumbnail_size' => Thumbnail size on detail pages
| 'placeholder_image' => Set the path to your default placeholder image (if no image is set)
| 'image_enlargement' => Link image enlargements while using plugins like fancybox or lightbox
| 'detail_limit_dates' => Limit amount of dates displayed after loading on the offer detail page
| 'filter_keywords_with_and' => Filter offers by keywords with AND restriction (default: OR)
| 'show_park_name' => Show park name on overview and on detail page
|
*/
$config['always_show_filter'] = FALSE;
$config['show_route_filter'] = TRUE;
$config['show_target_group_filter'] = TRUE;
$config['show_route_filter_min_count'] = 5;
$config['offers_per_page'] = 10;
$config['n_th_point'] = 2;
$config['n_th_point_min_count'] = 100;
$config['pagination_max_numbers'] = 5;
$config['overview_thumbnail_size'] = 'medium';
$config['detail_thumbnail_size'] = 'large';
$config['placeholder_image'] = 'https://angebote.paerke.ch/img/placeholder.png';
$config['image_enlargement'] = TRUE;
$config['detail_limit_dates'] = 5;
$config['filter_keywords_with_and'] = FALSE;
$config['show_park_name'] = FALSE;


/*
|--------------------------------------------------------------------------
| View mode
|--------------------------------------------------------------------------
|
| Set if view should be returned or directly displayed
| Default: FALSE, output will automatically displayed
|
*/
$config['return_output'] = FALSE;


/*
|--------------------------------------------------------------------------
| Favorites
|--------------------------------------------------------------------------
|
| Enable favorites module to list all favorites
| If enabled, set the script path to the parks_api/scripts/favorites.php
| file, e.g. /plugins/parks_api/scripts (without an ending slash)
|
*/
$config['favorites_extension_available'] = FALSE;
$config['favorites_script_path'] = '';


/*
|--------------------------------------------------------------------------
| API prefixes
|--------------------------------------------------------------------------
|
| Prevent equal namespaces with a unique prefix
|
*/
$config['form_prefix'] = '';
$config['url_param_prefix'] = '';


/*
|--------------------------------------------------------------------------
| Languages
|--------------------------------------------------------------------------
|
| Set all available languages in your environment and your default language.
| Also specifiy if offers should be displayed or not whether it exists in the selected language
|
*/
$config['default_language'] = 'de';
$config['available_languages'] = array('de', 'fr', 'it', 'en');
$config['language_independence'] = TRUE;
$config['language_priority'] = array(
	'de' => array('fr', 'it', 'en'),
	'fr' => array('de', 'it', 'en'),
	'it' => array('fr', 'de', 'en'),
	'en' => array('de', 'fr', 'it'),
);


/*
|--------------------------------------------------------------------------
| PHP session
|--------------------------------------------------------------------------
|
*/
$config['use_sessions'] = TRUE;
$config['session_name'] = "parks_api";


/*
|--------------------------------------------------------------------------
| Logs
|--------------------------------------------------------------------------
|
| Define the folder where log files are stored.
| Make sure this directory is writeable.
|
*/
$config['log_directory'] = "log/";


/*
|--------------------------------------------------------------------------
| Formats
|--------------------------------------------------------------------------
|
| Specify date format for PHP & MySQL
|
*/
$config['mysql_date_format'] = "%d.%m.%Y %H:%i";
$config['php_date_format'] = "d.m.Y H:i";

