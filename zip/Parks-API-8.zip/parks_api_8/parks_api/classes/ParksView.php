<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| Default view class for API
|
*/


class ParksView {


	/**
	 * API
	 */
	public $api;


	/**
	 * Configuration
	 */
	public $config;


	/**
	 * Script url
	 */
	public $script_url;
	public $script_url_with_params;


	/**
	 * SBB links
	 */
	public $sbb_link;


	/**
	 * Detail template tags of each offer type
	 */
	public $detail_template_tags;



	/**
	 * Constructor
	 *
	 * @access public
	 * @param  array $api
	 * @return void
	 */
	function __construct($api) {

		// api instance
		$this->api = $api;

		// get api informations
		$this->config = $api->config;

		// set return output method
		$this->return_output = isset($this->config['return_output']) ? $this->config['return_output'] : FALSE;

		// specific target groups
		$this->specific_target_groups = array(7, 8, 9, 10);

		// init sbb links for each language
		$sbb_i18n = array(
			'de' => 'https://www.sbb.ch/de/kaufen/pages/fahrplan/fahrplan.xhtml',
			'fr' => 'https://www.sbb.ch/fr/acheter/pages/fahrplan/fahrplan.xhtml',
			'it' => 'https://www.sbb.ch/it/acquistare/pages/fahrplan/fahrplan.xhtml',
			'en' => 'https://www.sbb.ch/en/buying/pages/fahrplan/fahrplan.xhtml',
		);
		$this->sbb_link = $sbb_i18n[$this->api->lang_id];

		// set script url with all params
		if (!empty($_SERVER['REQUEST_URL'])) {
			$this->script_url_with_params = $_SERVER['REQUEST_URL'];
		}
		elseif (!empty($_SERVER['REQUEST_URI'])) {
			$this->script_url_with_params = $_SERVER['REQUEST_URI'];
		}

		// set script url without params
		$this->script_url = $this->script_url_with_params;
		$param_start = strpos($this->script_url_with_params, '?');
		if ($param_start > 0) {
			$this->script_url = substr($this->script_url_with_params, 0, $param_start);
		}

	}



	/**
	 * Show offer filter
	 *
	 * @access public
	 * @param array $params (default: array())
	 * @return void
	 */
	public function filter($params = array()) {

		// init template data
		$template_data = array();

		// set name
		$fieldname = $this->config['form_prefix'].'filter';

		// show filter
		$template_data['FILTER_SHOW_LINK'] = '<a class="show_filter"><i>a</i>'.$this->api->lang->get('offer_filter_show').'</a>';
		$template_data['FILTER_FORM_START'] = '<form action="'.$this->script_url.'" method="post" autocomplete="off">';
		$template_data['FILTER_FORM_STOP'] = '</form>';
		$search_val = (isset($params['selected']['search']) ? ' value="'.(isset($params['selected']['search']) ? $params['selected']['search'] : '').'"' : '');

		// filter: free text search
		$template_data['FILTER_TEXT_SEARCH'] = '
			<p class="form_element search">
				<span class="element_wrap">
					<input type="text" name="'.$fieldname.'[search]" id="offer_filter_search"'.$search_val.' placeholder="'.$this->api->lang->get('offer_search').'" />
				</span>
			</p>
		';

		// filter: select categories
		if (is_array($params['categories']) && !empty($params['categories'])) {
			$template_data['FILTER_CATEGORIES'] = '
				<div class="form_element mega_dropdown">
					<div class="form_group">
						<label>'.$this->api->lang->get('offer_category').'</label>
						<h4>
							<i class="deselect_icon">m</i>
							<span class="selected_option"></span>
							<span class="all">'.$this->api->lang->get('offer_all').'</span>
						</h4>
						<div class="form_group_dropdown">
							<span class="dropdown_filter">
								<label class="select_all"><i>f</i>'.$this->api->lang->get('offer_filter_all').'</label>
								<label class="deselect_all"><i>m</i>'.$this->api->lang->get('offer_filter_none').'</label>
							</span>';
							foreach ($params['categories'] as $key1 => $level1) {
								if (is_array($level1) && !empty($level1)) {
									// check, if there is more than 1 level down
									$first_level2 = reset($level1);
									if (!is_array($first_level2)) {
										$template_data['FILTER_CATEGORIES'] .= '<span class="label_wrapper">
														<label class="category_title">
															<span></span>
															'.$key1.'
														</label>';
									}
									foreach ($level1 as $key2 => $level2) {
										// level 3
										if (is_array($level2) && !empty($level2)) {
											$template_data['FILTER_CATEGORIES'] .= '<span class="label_wrapper">
														<label class="category_title">
															<span></span>
															'.$key2.'
														</label>';
											foreach ($level2 as $key3 => $level3) {
												$checked = (isset($params['selected']['categories']) && is_array($params['selected']['categories']) && in_array($key3, $params['selected']['categories']) ? 'checked="checked"' : '');
												$template_data['FILTER_CATEGORIES'] .= '
													<label>
														<input name="'.$fieldname.'[categories][]" '.$checked.' value="'.$key3.'" type="checkbox">
														<span></span>
														'.$level3.'
													</label>';
											}
											$template_data['FILTER_CATEGORIES'] .= '</span>';
										}
										// level 2
										else {
											$checked = (isset($params['selected']['categories']) && is_array($params['selected']['categories']) && in_array($key2, $params['selected']['categories']) ? 'checked="checked"' : '');
											$template_data['FILTER_CATEGORIES'] .= '
												<label>
													<input name="'.$fieldname.'[categories][]" '.$checked.' value="'.$key2.'" type="checkbox">
													<span></span>
													'.$level2.'
												</label>';
										}
									}
									// close group
									if (!is_array($first_level2)) {
										$template_data['FILTER_CATEGORIES'] .= '</span>';
									}
								}
							}
						$template_data['FILTER_CATEGORIES'] .= '
						</div>
					</div>
				</div>
			';
		}

		// filter: date from and date to
		if (isset($params['show_event_filter']) && ($params['show_event_filter'] == TRUE)) {
			$date_from_val = (isset($params['selected']['date_from']) && !empty($params['selected']['date_from']) ? ' value="'.$params['selected']['date_from'].'"' : '');
			$date_to_val = (isset($params['selected']['date_to']) && !empty($params['selected']['date_to']) ? ' value="'.$params['selected']['date_to'].'"' : '');
			$template_data['FILTER_DATES'] = '
				<div class="form_element date_wrap">
					<label>'.$this->api->lang->get('offer_park_events_short').'</label>
					<span class="element_wrap">
						<i class="icon">e</i>
						<input id="date_start" name="'.$fieldname.'[date_from]"'.$date_from_val.' class="datepicker" type="text" placeholder="'.$this->api->lang->get('general_date').' '.$this->api->lang->get('general_from').'">
					</span>
					<span class="element_wrap">
						<i class="icon">e</i>
						<input id="date_end" name="'.$fieldname.'[date_to]"'.$date_to_val.' class="datepicker" type="text" placeholder="'.$this->api->lang->get('general_date').' '.$this->api->lang->get('general_to').'">
					</span>
					<div class="cf"></div>
				</div>
			';
		}

		// filter: target group
		if (isset($params['show_target_group_filter']) && ($params['show_target_group_filter'] == TRUE)) {
			$template_data['FILTER_TARGET_GROUPS'] = '
				<div class="form_element mega_dropdown">
					<div class="form_group">
						<label>'.$this->api->lang->get('offer_filter_suited_for').'</label>
						<h4>
							<i class="deselect_icon">m</i>
							<span class="selected_option"></span>
							<span class="all">'.$this->api->lang->get('offer_target_group_general_info').'</span>
						</h4>
						<div class="form_group_dropdown">
							<span class="dropdown_filter">
								<label class="select_all"><i>f</i>'.$this->api->lang->get('offer_filter_all').'</label>
								<label class="deselect_all"><i>m</i>'.$this->api->lang->get('offer_filter_none').'</label>
							</span>
							<span class="label_wrapper">';
								$row_index = 0;
								foreach ($this->api->model->target_groups as $target_group_id => $target_label) {
									if ($row_index > 6) {
										break;
									}
									$target_val = isset($params['selected']['target_groups']) && in_array($target_group_id, $params['selected']['target_groups']) ? 'checked="checked"' : '';
									$template_data['FILTER_TARGET_GROUPS'] .= '<label>
													<input name="'.$fieldname.'[target_groups][]" '.$target_val.' value="'.$target_group_id.'" type="checkbox">
													<span></span>
													'.$target_label.'
												</label>
									';
									$row_index++;
								}
								$template_data['FILTER_TARGET_GROUPS'] .= '
							</span>
						</div>
					</div>
				</div>
			';
		}

		// filter: park
		if (!empty($params['users']) && count($params['users']) > 1) {
			$template_data['FILTER_PARKS'] = '
				<div class="form_element mega_dropdown">
					<div class="form_group">
						<label>'.$this->api->lang->get('offer_park_single').'</label>
						<h4>
							<i class="deselect_icon">m</i>
							<span class="selected_option"></span>
							<span class="all">'.$this->api->lang->get('offer_parks_all').'</span>
						</h4>
						<div class="form_group_dropdown">
							<span class="dropdown_filter">
								<label class="select_all"><i>f</i>'.$this->api->lang->get('offer_filter_all').'</label>
								<label class="deselect_all"><i>m</i>'.$this->api->lang->get('offer_filter_none').'</label>
							</span>
							<span class="label_wrapper">';
								foreach ($params['users'] as $park_id => $park) {
									$park_val = isset($params['selected']['park_id']) && in_array($park_id, $params['selected']['park_id']) ? 'checked="checked"' : '';
									$template_data['FILTER_PARKS'] .= '<label>
										<input name="'.$fieldname.'[park_id][]" '.$park_val.' value="'.$park_id.'" type="checkbox">
										<span></span>
										'.$park.'
									</label>';
								}
								$template_data['FILTER_PARKS'] .= '
							</span>
						</div>
					</div>
				</div>
			';
		}

		// filter: project status
		if (isset($params['show_project_filter']) && ($params['show_project_filter'] == TRUE)) {
			$all_project_status = $this->config['project_status_'.$this->api->lang_id];
			$template_data['FILTER_PROJECT'] = '
				<div class="form_element mega_dropdown">
					<div class="form_group">
						<label>'.$this->api->lang->get('offer_project_status').'</label>
						<h4>
							<i class="deselect_icon">m</i>
							<span class="selected_option"></span>
							<span class="all">'.$this->api->lang->get('offer_project_status').'</span>
						</h4>
						<div class="form_group_dropdown">
							<span class="dropdown_filter">
								<label class="select_all"><i>f</i>'.$this->api->lang->get('offer_filter_all').'</label>
								<label class="deselect_all"><i>m</i>'.$this->api->lang->get('offer_filter_none').'</label>
							</span>
							<span class="label_wrapper">';
								foreach ($all_project_status as $status_id => $status_label) {
									$project_val = isset($params['selected']['project_status']) && in_array($status_id, $params['selected']['project_status']) ? 'checked="checked"' : '';
									$template_data['FILTER_PROJECT'] .= '<label>
													<input name="'.$fieldname.'[project_status][]" '.$project_val.' value="'.$status_id.'" type="checkbox">
													<span></span>
													'.$status_label.'
												</label>
									';
								}
								$template_data['FILTER_PROJECT'] .= '
							</span>
						</div>
					</div>
				</div>
			';
		}

		// filter: routes
		if (isset($params['show_route_filter']) && ($params['show_route_filter'] == TRUE)) {

			// route length
			$template_data['FILTER_ROUTE_LENGTH'] = '
				<div class="form_element range_wrap">
					<label>'.$this->api->lang->get('offer_routes_length').'</label>
					<input id="route_min" name="'.$fieldname.'[route_length_min]" type="hidden" value="'.(isset($params['selected']['route_length_min']) ? $params['selected']['route_length_min'] : '0').'">
					<input id="route_max" name="'.$fieldname.'[route_length_max]" type="hidden" value="'.(isset($params['selected']['route_length_max']) ? $params['selected']['route_length_max'] : '50').'">
					<div class="range"></div>
					<span class="range_text">
						<span class="minimum" data-label="'.$this->api->lang->get('offer_routes_length').'"></span>
						<span class="maximum"></span>
					</span>
					<div class="cf"></div>
				</div>
			';

			// route time
			$template_data['FILTER_ROUTE_TIME'] = '
				<div class="form_element mega_dropdown">
					<div class="form_group">
						<label>'.$this->api->lang->get('offer_routes_time_required').'</label>
						<h4>
							<i class="deselect_icon">m</i>
							<span class="selected_option"></span>
							<span class="all">'.$this->api->lang->get('offer_routes_time_required').'</span>
						</h4>
						<div class="form_group_dropdown">
							<span class="dropdown_filter">
								<label class="select_all"><i>f</i>'.$this->api->lang->get('offer_filter_all').'</label>
								<label class="deselect_all"><i>m</i>'.$this->api->lang->get('offer_filter_none').'</label>
							</span>
							<span class="label_wrapper">';
								foreach ($this->config['route_times'] as $time) {
									$time_checked = isset($params['selected']['time_required']) && in_array($time, $params['selected']['time_required']) ? 'checked="checked"' : '';
									$template_data['FILTER_ROUTE_TIME'] .= '
										<label>
											<input name="'.$fieldname.'[time_required][]" '.$time_checked.' value="'.$time.'" type="checkbox">
											<span></span>
											'.$time.'
										</label>
									';
								}
								$template_data['FILTER_ROUTE_TIME'] .= '
							</span>
						</div>
					</div>
				</div>
			';

			// route condition and technic
			$title_condition = $this->api->lang->get('offer_routes_condition');
			$title_technic = $this->api->lang->get('offer_routes_technic');
			$template_data['FILTER_ROUTE_CONDITION'] = '
				<div class="form_element mega_dropdown">
					<div class="form_group">
						<label>'.$this->api->lang->get('offer_routes_requirements').'</label>
						<h4>
							<i class="deselect_icon">m</i>
							<span class="selected_option selected_conditions_technics"></span>
							<span class="all">'.$this->api->lang->get('offer_routes_requirements').'</span>
						</h4>
						<div class="form_group_dropdown">
							<span class="dropdown_filter">
								<label class="select_all"><i>f</i>'.$this->api->lang->get('offer_filter_all').'</label>
								<label class="deselect_all"><i>m</i>'.$this->api->lang->get('offer_filter_none').'</label>
							</span>
							<span class="label_wrapper">
								<label class="category_title">
									<span></span>
									'.$title_condition.'
								</label>';
								foreach ($this->config['route_levels'] as $level => $level_value) {
									$level_checked = isset($params['selected']['level_condition']) && in_array($level, $params['selected']['level_condition']) ? 'checked="checked"' : '';
									$template_data['FILTER_ROUTE_CONDITION'] .= '
										<label>
											<input name="'.$fieldname.'[level_condition][]" '.$level_checked.' value="'.$level.'" type="checkbox">
											<span></span>
											<span class="hidden">'.$title_condition[0].': </span>'.$level_value.'
										</label>
									';
								}
								$template_data['FILTER_ROUTE_CONDITION'] .= '
							</span>
							<span class="label_wrapper">
								<label class="category_title">
									<span></span>
									'.$title_technic.'
								</label>';
								foreach ($this->config['route_levels'] as $level => $level_value) {
									$level_checked = isset($params['selected']['level_technics']) && in_array($level, $params['selected']['level_technics']) ? 'checked="checked"' : '';
									$template_data['FILTER_ROUTE_CONDITION'] .= '
										<label>
											<input name="'.$fieldname.'[level_technics][]" '.$level_checked.' value="'.$level.'" type="checkbox">
											<span></span>
											<span class="hidden">'.$title_technic[0].': </span>'.$level_value.'
										</label>
									';
								}
								$template_data['FILTER_ROUTE_CONDITION'] .= '
							</span>
						</div>
					</div>
				</div>
			';

		}

		// filter buttons
		$reset_link = $this->script_url_with_params;
		if (strstr($reset_link, '?')) {
			$reset_link .= '&reset';
		}
		else {
			$reset_link .= '?reset';
		}
		if ($params['filter'] == TRUE) {
			$template_data['FILTER_RESET_BUTTON'] = '<a href="'.$reset_link.'" class="reset_link"><i>m</i>'.$this->api->lang->get('offer_reset').'</a>';
		}
		$template_data['FILTER_SUBMIT_BUTTON'] = '<input type="submit" name="'.$fieldname.'[submit]" value="'.$this->api->lang->get('general_search').'" class="button" />';

		// compile filter template
		$output = $this->api->compile_template('filter', $template_data);

		// show output
		if ($this->return_output === TRUE) {
			return $output;
		}
		else {
			echo $output;
		}
	}



	/**
	 * Show offer list
	 *
	 * @access public
	 * @param mixed $offers
	 * @param mixed $in_tab (default: FALSE)
	 * @param mixed $poi (default: FALSE)
	 * @param mixed $original_category (default: NULL)
	 * @return void
	 */
	public function list($offers, $in_tab = FALSE, $poi = FALSE, $original_category = NULL, $title_link = '') {
		$output = "";
		if (isset($offers['total']) && ($offers['total'] > 0) && isset($offers['data']) && !empty($offers['data'])) {

			// output
			$output .= '<div class="entries_wrap listing">';

			// show total
			if ($in_tab == FALSE) {
				$output .= '
					<div id="offer_total">
						<span class="offer_count">'.$offers['total'].' '.(($offers['total'] == 1) ? $this->api->lang->get('offer') : $this->api->lang->get('offers')).'</span>
					</div>
				';
			}

			foreach ($offers['data'] as $offer) {

				if (!empty($offer)) {

					$paramname = $this->config['url_param_prefix'].'offer';
					$offer_detail_url = $this->script_url.(strstr($this->script_url, '?') ? '&amp' : '?').$paramname.'='.$offer->offer_id;

					// allow to get back to routes
					if ($poi == TRUE) {
						$offer_detail_url .= '&amp;poi='.$poi.'&amp;original_category='.$original_category.'&amp;tab=tab_5';
					}

					// prepare dates
					$date_from = NULL;
					$date_to = NULL;
					if (isset($offer->date_from) && !empty($offer->date_from)) {
						$date_from = new DateTime($offer->date_from);
					}
					if (isset($offer->date_to) && !empty($offer->date_to)) {
						$date_to = new DateTime($offer->date_to);
					}

					// prepare categories
					$category_parent_id = (is_array($offer->categories) && !empty($offer->categories)) ? array_values($offer->categories) : NULL;
					$category_parent_id = array_shift($category_parent_id);

					// start Offer
					$output .= '<div id="offer_'.$offer->offer_id.'" class="listing_entry">';

					// favorites
					if (!empty($this->config['favorites_extension_available']) && !empty($this->config['favorites_script_path'])) {
						$favorite_link_title = in_array($offer->offer_id, $this->api->favorites) ? $this->api->lang->get('favorites_remove') : $this->api->lang->get('favorites_add');
						$favorite_class = in_array($offer->offer_id, $this->api->favorites) ? 'active' : '';
						$output .= '
							<div class="favorite '.$favorite_class.'">
								<a href="'.$this->config['favorites_script_path'].'/favorite.php?offer_id='.$offer->offer_id.'" data-title="'.$favorite_link_title.'" data-label-add="'.$this->api->lang->get('favorites_add').'" data-label-remove="'.$this->api->lang->get('favorites_remove').'" class="tooltip" title="'.$favorite_link_title.'">i</a>
							</div>
						';
					}
					// offer image or date
					$has_image = isset($offer->images) && (count($offer->images) > 0);
					$config_thumbnail_size = isset($this->config['overview_thumbnail_size']) ? $this->config['overview_thumbnail_size'] : 'medium';

					// image
					if ($has_image == TRUE) {
						$output .= '<div class="pictures">';
						if ($offer->is_hint == TRUE) {
							$output .= '<div class="tipp">'.$this->api->lang->get('offer_hint').'</div>';
						}
						$output .= '<img class="attachment offer_images" src="'.$offer->images[0]->{$config_thumbnail_size}.'" alt="'.$offer->title;
						if (!empty($offer->images[0]->copyright)) {
							$output .= ' - &copy; '.$offer->images[0]->copyright;
						}
						$output .= '" />';
						$output .= '</div>';
					}
					else {
						$output .= '<div class="pictures empty_image">';
						if ($offer->is_hint == TRUE) {
							$output .= '<div class="tipp">'.$this->api->lang->get('offer_hint').'</div>';
						}
						if ($offer->root_category == CATEGORY_EVENT) {
							$output .= '<div class="date_wrap">';

							// prepare dates
							$date_from = NULL;
							$date_to = NULL;
							if (isset($offer->date_from) && !empty($offer->date_from)) {
								$date_from = new DateTime($offer->date_from);
							}
							if (isset($offer->date_to) && !empty($offer->date_to)) {
								$date_to = new DateTime($offer->date_to);
							}

							// date from
							if (!empty($date_from)) {
								$output .= '
									<div class="date">
										<span>'.$date_from->format('d').'</span>
										<span>'.$this->api->lang->get('month'.$date_from->format('m')).'</span>
									</div>
								';
							}

							// date to
							if (!empty($date_to) && ($date_from->format('dmY') != $date_to->format('dmY'))) {
								$output .= '
									<div class="date">
										<span>'.$date_to->format('d').'</span>
										<span>'.$this->api->lang->get('month'.$date_to->format('m')).'</span>
									</div>
								';
							}

							$output .= '</div>';
						}
						elseif (!empty($this->config['placeholder_image'])) {
							$output .= '
								<div class="placeholder_wrap">
									<div class="placeholder_image">
										<img src="'.$this->config['placeholder_image'].'" width="80" height="80">
									</div>
								</div>
							';
						}
						$output .= '</div>';
					}

					$output .= '<div class="description">';

					// Show park name
					if (!empty($this->config['show_park_name'])) {
						$output .= '<div class="introduction">'.$offer->park.'</div>';
					}

					// Offer title
					$output .= '<h3>'.$offer->title.'</h3>';

					// show dates
					if (isset($offer->date_from) && is_object($category_parent_id) && in_array($category_parent_id->parent_id, array(CATEGORY_EVENT, CATEGORY_RESEARCH))) {

						// date from
						$output .= '<span class="date"><strong>'.$date_from->format('d.m.Y').'</strong>';
						if (($date_from->format('H') != '00') || ($date_from->format('i') != '00')) {
							$output .= $date_from->format(' H:i');
						}

						// date to
						if (
							isset($offer->date_to)
							&&
							(
								($date_from->format('d.m.Y') != $date_to->format('d.m.Y'))
								||
								($date_to->format('H') != '00')
								||
								($date_to->format('i') != '00')
							)
						) {
							$output .= ' - ';
							if ($date_from->format('d.m.Y') != $date_to->format('d.m.Y')) {
								$output .= '<strong>'.$date_to->format('d.m.Y').'</strong>';
							}
							if (($date_to->format('H') != '00') || ($date_to->format('i') != '00')) {
								$output .= $date_to->format(' H:i');
							}
						}

						$output .= '</span>';
					}

					// Offer description and park
					$output .= '<p>'.auto_text_format($offer->description_medium).'</p>';

					// Offer categories
					if (isset($offer->categories) && !empty($offer->categories)) {
						$categories = array();
						$output .= '<div class="categories">';
						foreach ($offer->categories as $category) {
							if (!in_array($category->category_id, $this->config['hidden_categories'])) {
								$categories[] = $category->body;
								$output .= '<span>'.$category->body.'</span>';
							}
						}
						$output .= '</div>';

						// show route details
						if (!empty($offer->time_required) || (!empty($offer->route_length) && (intval($offer->route_length) > 0))) {
							$output .= '<div class="route_info">';
							if (!empty($offer->time_required)) {
								$output .= '<span>'.$this->api->lang->get('offer_time_required').': '.$offer->time_required.'</span>';
							}
							if (!empty($offer->route_length) && (intval($offer->route_length) > 0)) {
								$output .= '<span>'.$this->api->lang->get('offer_route_length').': '.$offer->route_length.$this->api->lang->get('offer_route_length_km').'</span>';
							}
							$output .= '</div>';
						}

					}

					$output .= '</div>';
					$output .= '<div class="cf"></div>';
					$output .= '<a href="'.$offer_detail_url.'" class="entry_link"></a>';
					$output .= '</div>';

				}
			}

			$output .= '</div>';

		}
		else {

			$output .= '<p class="no_results">'.$this->api->lang->get('offer_not_found').'</p>';

		}

		// if true list offer inside a div for tab
		if (($in_tab == TRUE) || ($this->return_output == TRUE)) {
			return $output;
		}
		else {
			echo $output;
		}

	}


	/**
	 * Show map with offer(s)
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function pagination($page = 1, $total = 1) {

		// init
		if ($page <= 0) {
			$page = 1;
		}

		// output
		$output = '<div class="offer_pagination">';

		// previous link
		if ($page > 1) {
			$paramname = $this->config['form_prefix'].'page';
			$link = $this->script_url_with_params;

			$output .= '<div class="prev_wrap">';

			// set links
			if (strpos($this->script_url_with_params, $paramname)) {
				$first_link = str_replace($paramname.'='.$page, $paramname.'=1', $this->script_url_with_params);
				$prev_link = str_replace($paramname.'='.$page, $paramname.'='.($page-1), $this->script_url_with_params);
			}
			else {
				$first_link = (strstr($link, '?') ? '&' : '?').$paramname.'=1';
				$prev_link = (strstr($link, '?') ? '&' : '?').$paramname.'='.($page-1);
			}

			$output .= '
				<a href="'.$first_link.'">'.$this->api->lang->get('offer_first').'</a>
				<a href="'.$prev_link.'" class="icon">o</a>
			';

			$output .= '</div>';
		}

		// next page link
		if ($page < $total) {
			$paramname = $this->config['form_prefix'].'page';
			$link = $this->script_url_with_params;

			$output .= '<div class="next_wrap">';

			// set link
			if (strstr($this->script_url_with_params, $paramname.'=')) {
				$last_link = str_replace($paramname.'='.$page, $paramname.'='.$total, $this->script_url_with_params);
				$next_link = str_replace($paramname.'='.$page, $paramname.'='.($page+1), $this->script_url_with_params);
			}
			else {
				$last_link = $this->script_url_with_params.(strstr($link, '?') ? '&' : '?').$paramname.'='.$total;
				$next_link = $this->script_url_with_params.(strstr($link, '?') ? '&' : '?').$paramname.'='.($page+1);
			}
			$output .= '
				<a href="'.$next_link.'" class="icon">p</a>
				<a href="'.$last_link.'">'.$this->api->lang->get('offer_last').'</a>
			';

			$output .= '</div>';
		}

		// page numbers
		if ($total > 1) {
			$paramname = $this->config['form_prefix'].'page';
			$pagination_max_numbers = $this->api->config['pagination_max_numbers'] ? intval($this->api->config['pagination_max_numbers']) : 5;
			$half_pages_start = floor($pagination_max_numbers/2);
			$half_pages_end = ceil($pagination_max_numbers/2)-1;
			$end = 0;

			// calculate start
			$start = intval($page - $half_pages_start);
			if ($start <= 0) {
				$start = 1;
				$end = $pagination_max_numbers;
			}
			elseif ($start < ($page - $half_pages_start)) {
				$start = ($page - $half_pages_start);
			}

			// calculate end
			if (($end == 0) || ($end > $total)) {
				$end = ($page + $half_pages_end);
				if ($end > $total) {
					if ($end == 0) {
						$start = $total - $pagination_max_numbers + 1;
					}
					$end = $total;
				}
			}

			$output .= '<div class="numbers">';
			for ($i=$start ; $i<=$end ; $i++) {

				// set link
				$link = $this->script_url_with_params;
				if (strpos($this->script_url_with_params, $paramname)) {
					$link = str_replace($paramname.'='.$page, $paramname.'='.$i, $this->script_url_with_params);
				}
				else {
					$link .= (strstr($link, '?') ? '&' : '?').$paramname.'='.$i;
				}
				$output .= '<a href="'.$link.'"'.(($page == $i) ? ' class="current"' : '').'>'.$i.'</a> ';

			}
			$output .= '</div>';
		}


		$output .= '</div>';

		if ($total > 1) {
			// show output
			if ($this->return_output === TRUE) {
				return $output;
			}
			else {
				echo $output;
			}
		}

	}


	/**
	 * Show map with offers
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function map($offers, $poi_detail = FALSE, $offer_id = FALSE) {
		$output = '<div class="offer_map_container">';

		$add_markers_function = 'var swissmap;';
		$add_markers_function .= 'function loadSwissMap() {';
		$add_markers_function .= 'swissmap = new SwissMap("#mapContainer", function() {';
		$add_markers_function .= '		var that = this;';

		// Custom map layers
		$map_layers = $this->api->model->get_custom_layers();

		// Add custom map layers
		if (!empty($map_layers) && is_array($map_layers)) {
			// Set quantity of custom layers
			$add_markers_function .= 'this.setCustomLayerQuantity('. (isset($map_layers) ? count($map_layers) : 0) .');';
			foreach ($map_layers as $layer) {

				// set popup content
				$popup = $this->_build_popup($layer);

				// add custom layers with/without layers
				$add_markers_function .= 'this.addCustomMapLayer(	"'.$layer->url.'", { id: "'.$layer->map_layer_id.'", visible: '. (($layer->visible_by_default) ? $layer->visible_by_default : 'false') .', position: '. (($layer->layer_position) ? $layer->layer_position : 0) . $popup .'});';
			}
		}

		$paramname = $this->config['url_param_prefix'].'offer';

		$filter_data = $this->api->get_filter_data();
		$filter_categories = isset($filter_data['categories']) ? $filter_data['categories'] : array();

		$all_categories = $this->api->model->get_all_categories();

		if (!empty($offers)) {
			$categories = array();
			$category_groups = array();
			$js_output = "";

			foreach ($offers as $offer) {

				if (isset($offer->latitude) && ($offer->latitude > 0) && isset($offer->longitude) && ($offer->longitude > 0)) {
					$offer_categories = array();

					$max_level = 0;
					if (!empty($offer->categories)) {
						foreach ($offer->categories as $category) {
							if (
								(is_object($this->api->model) && is_object($category))
								&&
								(
									// overview map: check filter
									!$this->api->is_filter_activated()
									||
									count($filter_categories) == 0
									||
									in_array($category->category_id, $filter_categories)
									||
									in_array($category->parent_id, $filter_categories)
									||

									// detail view: show every poi
									($poi_detail === TRUE)
								)
							) {
								$path = $this->api->model->get_category_path($category->parent_id);
								if (is_array($path)) {
									$path = reset($path);
								}
								$category->group = $all_categories[$path];

								if (!in_array($category->group->category_id, array(CATEGORY_PRODUCT, CATEGORY_ACTIVITY))) {

									if (count($path) > $max_level) {
										$offer_categories = array();
										$max_level = count($path);
									}
									$offer_categories[] = $category;
								}
							}
						}
					}

					$marker_id = md5($offer->offer_id);

					$date = FALSE;
					if ($offer->root_category == CATEGORY_EVENT) {
						$marker_id = md5($marker_id.$offer->date_from.$offer->date_to);

						$date_from = parks_mysql2date($offer->date_from, TRUE);
						$date_to = parks_mysql2date($offer->date_to, TRUE);
						$date = parks_show_date(array('date_from'=>parks_mysql2form($date_from), 'date_to' => parks_mysql2form($date_to)));
					}

					$url = $this->script_url_with_params.(strstr($this->script_url_with_params, '?') ? '&' : '?').$paramname.'='.$offer->offer_id;
					$image = (isset($offer->images) && count($offer->images) > 0) ? $offer->images[0]->medium : FALSE;

					$position = convertLatLonToCH1903($offer->latitude, $offer->longitude);

					if (isset($offer->route)) {
						$route = array();
						foreach ($offer->route as $waypoint) {
							$point = convertLatLonToCH1903($waypoint->latitude, $waypoint->longitude);
							$route[] = '['.$point['y'].', '.$point['x'].']';
						}
						$path = '['.implode(',', $route).']';
					}

					$offer_categories_ids = array();
					foreach ($offer_categories as $offer_category) {
						$categories[intval($offer_category->sort)] = $offer_category;
						$category_groups[intval($offer_category->group->sort)] = $offer_category->group;

						$offer_categories_ids[] = $offer_category->sort;
					}

					$js_output .= '
						this.addMarkerForMultipleLayers(['.implode(",", $offer_categories_ids).'], function() {
							return {
								id: \''.$marker_id.'\',
								point: new esri.geometry.Point('.$position['y'].', '.$position['x'].', that.spatialReference),
								'.(isset($offer->route) ? ' route: new esri.geometry.Polyline({ paths: ['.$path.'], spatialReference: that.spatialReference }),' : '').'
								attributes: {
									title: \''.addslashes($offer->title).'\',
									'.($date ? ' date: \''.$date.'\',' : '');

					if (isset($offer->route_length)) {
						$js_output .= ' route_length: \''.$offer->route_length.' '.$this->api->lang->get('offer_route_length_km').'\',';
					}

					if (isset($offer->time_required)) {
						$js_output .= ' time_required: \''.$offer->time_required.'\',';
					}

					if (isset($offer->level_technics)) {
						$js_output .= ' level_technics: \''.$offer->level_technics.'\',';
					}

					$js_output .= '	content: '.json_encode($offer->description_medium).',
									park_id: '.$offer->park_id.',
									'.($image ? ' image: \''.$image.'\',' : '').' link: \''.$url.'\'
								}
							}
						});';

				}
			}

			// create category groups
			foreach ($category_groups as $group) {
				$add_markers_function .= '		this.createOfferLayerGroup('.$group->sort.', \''.addslashes($group->body).'\', \''.$group->marker.'\');';
			}

			// create categories
			foreach ($categories as $category) {
				$add_markers_function .= '		this.createOfferLayer('.$category->sort.', \''.addslashes($category->body).'\', \''.$category->marker.'\', '.$category->group->sort.', '.($this->api->is_filter_activated() ? 'true' : 'false').');';
			}

			$add_markers_function .= $js_output;
		}

		$config = array(
			'cookieOptions' => array('path' => $this->script_url),
			'offerLayerVisibility' => FALSE,
			'lang' => $this->api->lang_id,
			'hash' => $this->config['api_hash'],
			'base_url' => $this->config['base_url'],
			'type' => 'api'
		);

		if ($poi_detail == FALSE) {
			$config['cookieName'] = 'swissmap_overview_'.md5($this->script_url);
			$config['printUrl'] = $this->config['base_url'].$this->api->lang_id.'/export/iframe/print/'.$this->config['api_hash'].'?logo=true';
			$config['resetMapExtent'] = FALSE; // set to FALSE if caching is activated
			$config['resetOfferLayerVisibility'] = FALSE;
			$config['overviewMap'] = TRUE;
		}
		else {
			$config['defaultBaseMap'] = 'pixelkarte';
			$config['cookieName'] = 'swissmap_poi_detail_'.md5($this->script_url);
			$config['disableClustering'] = TRUE;
			$config['fitOfferExtent'] = TRUE;
			$config['offerLayerVisibility'] = TRUE;
			$config['printUrl'] = $this->config['base_url'].$this->api->lang_id.'/export/iframe/print/'.$this->config['api_hash'].'/'.$offer->offer_id.'?logo=true';
			$config['hasPoi'] = TRUE;
			$config['offerId'] = (isset($offer_id) ? $offer_id : 0);
		}

		$config_ui = array(
			'canvasWidth' => 78
		);

		if ($poi_detail) {
			$config_ui['noPrint'] = TRUE;

			if (isset($offer->route) && !empty($offer->route)) {
				$config_ui['showElevationProfile'] = TRUE;
			}
		}

		if (isset($_SESSION[$this->api->session_name]['selectedPark']) && !empty($_SESSION[$this->api->session_name]['selectedPark'])) {
			$config['selectedPark'] = $_SESSION[$this->api->session_name]['selectedPark'];
		}

		// map option: show allways all layers on the map
		if (($this->api->is_filter_activated() === TRUE) || !empty($this->api->map_options['show_layers_at_start'])) {
			$config['offerLayerVisibility'] = TRUE;
		}

		// map option: link target
		$config['offerLinkTarget'] = '_self';
		if (!empty($this->api->map_options['link_target'])) {
			$config['offerLinkTarget'] = $this->api->map_options['link_target'];
		}

		// map option: init map extent
		if (!empty($this->api->map_options['map_extent'])) {
			$config['initExtent'] = $this->api->map_options['map_extent'];
		}

		// map option: full height
		$config_ui['fullHeight'] = FALSE;
		if (!empty($this->api->map_options['full_height']) && ($this->api->map_options['full_height'] == TRUE)) {
			$config_ui['fullHeight'] = TRUE;
		}

		// other map options
		if ($this->api->is_filter_activated() || isset($_SESSION['offer_detail_view']) && ($_SESSION['offer_detail_view'] == TRUE)) {
			$config['resetMapExtent'] = FALSE;
			$config['resetOfferLayerVisibility'] = FALSE;
			$config['resetMapLayerVisibility'] = FALSE;

			if (!empty($_SESSION['offer_detail_view'])) {
				$_SESSION['offer_detail_view'] = FALSE;
			}
		}

		$add_markers_function .= '	}, '.json_encode($config).', '.json_encode($config_ui).');';
		$add_markers_function .= '}';

		if ($poi_detail) {
			return $this->_get_detail_map_view($output, $add_markers_function);
		}
		else {
			$output .= $this->_get_swissmap_html().'
				<script type="text/javascript">
					'.$add_markers_function.'
				</script>
			</div>
			';

			// show output
			if ($this->return_output === TRUE) {
				return $output;
			}
			else {
				echo $output;
			}
		}
	}


	/**
	 * Show offer detail page
	 *
	 * @access public
	 * @param  array
	 * @return void
	 */
	public function detail($offer) {

		// init
		$output = '';
		$template_data = array();
		$template_conditions = array();

		// set view mode into session
		$_SESSION['offer_detail_view'] = TRUE;


		/*
		|--------------------------------------------------------------------------
		| Placeholder: title and description
		|--------------------------------------------------------------------------
		|
		*/
		$template_data['OFFER_TITLE'] = $offer->title;
		$description = '<div class="detail_text"><p>';
		if (!empty($this->config['show_park_name'])) {
			$description .= '<strong>'.$offer->park.'</strong> - ';
		}
		$description .= '<i>'.auto_link(nl2br($offer->description_medium), 'both', TRUE).'</i></p>';

		// Long description
		$long_description = trim($offer->description_long);
		if (!empty($long_description) && ($long_description != $offer->description_medium)) {
			$description .= '<p class="description">'.auto_link(nl2br($long_description), 'both', TRUE).'</p>';
		}
		$description .= '</div>';
		$template_data['OFFER_DESCRIPTION'] = $description;



		/*
		|--------------------------------------------------------------------------
		| Placeholder: short info by offer type
		|--------------------------------------------------------------------------
		|
		*/
		$short_info = '';
		switch ($offer->root_category) {
			case CATEGORY_EVENT:
			case CATEGORY_BOOKING:
			case CATEGORY_RESEARCH:
				if (!empty($offer->dates)) {

					// get next date
					$next_date = '';
					$now = new DateTime();
					foreach ($offer->dates as $date) {
						$date_from = new DateTime($date->date_from);
						$date_to = new DateTime($date->date_to);
						if (($date_from > $now) || (!empty($date->date_to) && ($date_to >= $now))) {
							$next_date = $date;
							break;
						}
					}

					// show label with next date
					$label = $this->api->lang->get('offer_next_date');
					$next_date = parks_show_date(array('date_from'=>parks_mysql2form($next_date->date_from), 'date_to' => parks_mysql2form($next_date->date_to)));
					$short_info .= '<span>'.$label.':</span> '.$next_date;

				}
				break;
			case CATEGORY_PRODUCT:
				if (empty($offer->dates)) {
					$short_info .= '<span>'.$this->api->lang->get('offer_saison').':</span> '.$this->api->lang->get('offer_all_season');
				}
				else {
					$first_date = $offer->dates[0];
					$label = $this->api->lang->get('offer_saison');
					$next_date = parks_show_date(array('date_from'=>parks_mysql2form($first_date->date_from), 'date_to' => parks_mysql2form($first_date->date_to)));
					$short_info .= '<span>'.$label.':</span> '.$next_date;
				}
				break;
			case CATEGORY_ACTIVITY:
				if (isset($offer->time_required) && !empty($offer->time_required)) {
					$short_info .= '<span>'.$this->api->lang->get('offer_time_required').':</span> '.$offer->time_required;
				}
				if (isset($offer->route_length) && (intval($offer->route_length) > 0)) {
					$short_info .= '<span>'.$this->api->lang->get('offer_route_length').':</span> '.$offer->route_length.' km ';
				}
				break;
			case CATEGORY_PROJECT:
				if (isset($offer->duration_from) && (intval($offer->duration_from) > 0)) {
					$short_info .= '<span>'.$this->api->lang->get('offer_project_duration').':</span> '.$offer->duration_from;
				}
				if (isset($offer->duration_to) && (intval($offer->duration_to) > 0)) {
					$short_info .= ' - '.$offer->duration_to;
				}
				break;
			default:
				break;
		}
		$template_data['OFFER_SHORT_INFO'] = $short_info;


		/*
		|--------------------------------------------------------------------------
		| Placeholder: categories
		|--------------------------------------------------------------------------
		|
		*/
		$template_data['OFFER_CATEGORIES'] = '';
		foreach ($offer->categories as $category) {
			if (!in_array($category->category_id, $this->config['hidden_categories'])) {
				$template_data['OFFER_CATEGORIES'] .= '<span>'.$category->body.'</span>';
			}
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: hyperlinks
		|--------------------------------------------------------------------------
		|
		*/
		if (isset($offer->hyperlinks) && !empty($offer->hyperlinks) && count($offer->hyperlinks) > 0) {
			$links = '';
			foreach($offer->hyperlinks as $hyperlink) {
				if (in_array($this->api->lang_id, explode(',', $hyperlink->language))) {
					$link_label = !empty($hyperlink->title) ? html_entity_decode($hyperlink->title) : $hyperlink->url;
					$links .= '<a href="'.$hyperlink->url.'" class="external_link" target="_blank">'.$link_label.'</a><br>';
				}
			}
			if (!empty($links)) {
				$template_data['OFFER_LINKS'] = $this->_show_text($this->api->lang->get('offer_links'), '<p>'.$links.'</p>', 'block offer_links');
			}
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: target groups
		|--------------------------------------------------------------------------
		|
		*/
		if (isset($offer->target_groups) && is_array($offer->target_groups) && !empty($offer->target_groups) && !in_array($offer->root_category, array(CATEGORY_RESEARCH))) {

			// handle target group restrictions
			$tg_main = array();
			$tg_special = array();
			$tg_restrictions = $this->specific_target_groups;
			foreach ($offer->target_groups as $target_group_id => $body) {
				if (in_array($target_group_id, $tg_restrictions)) {
					$tg_special[$target_group_id] = $body;
				}
				else {
					$tg_main[$target_group_id] = $body;
				}
			}

			// prepare main target groups
			if (!empty($tg_main)) {
				$tg_main = '<ul><li>'.implode('</li><li>', $tg_main).'</li></ul>';
			}
			else {
				$tg_main = '';
			}

			// prepare special target groups
			if (!empty($tg_special)) {
				$tg_special = '<ul><li>'.implode('</li><li>', $tg_special).'</li></ul>';
			}
			else {
				$tg_special = '';
			}

			$template_data['OFFER_TARGET_GROUPS'] = $this->_show_text($this->api->lang->get('offer_target_group_general_info'), $tg_main, 'block main_target_groups');
			$template_data['OFFER_TARGET_GROUPS'] .= $this->_show_text($this->api->lang->get('offer_target_group_specific_info'), $tg_special, 'block specific_target_groups');
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholders: addresses
		|--------------------------------------------------------------------------
		|
		*/

		// suppliers
		if (isset($offer->suppliers) && !empty($offer->suppliers)) {
			$suppliers = '';
			foreach ($offer->suppliers as $supplier) {
				if ($supplier['is_park_partner'] == 1) {
					$suppliers .= '<div class="partner"><i>'.$this->api->lang->get('offer_park_partner').'</i></div>';
				}
				$suppliers .= '<p>'.auto_text_format($supplier['contact']).'</p>';
			}
			$template_data['OFFER_SUPPLIERS'] = $this->_show_text($this->api->lang->get('offer_supplier'), $suppliers, 'block offer_suppliers');
		}

		// institution
		if (isset($offer->institution) && !empty($offer->institution) && !in_array($offer->root_category, array(CATEGORY_EVENT))) {
			if ($offer->institution_is_park_partner == 1) {
				$offer->institution = '<div class="partner"><i>'.$this->api->lang->get('offer_park_partner').'</i></div>' . auto_text_format($offer->institution);
			}

			// set title
			$title = '';
			switch ($offer->root_category) {
				case CATEGORY_PROJECT:
					$title = $this->api->lang->get('offer_project_responsibility');
					break;
				case CATEGORY_RESEARCH:
					$title = $this->api->lang->get('offer_research_responsibility');
					break;
				default:
					$title = $this->api->lang->get('offer_organizer');
					break;

			}

			// set placeholder
			$template_data['OFFER_INSTITUTION'] = $this->_show_text($title, $offer->institution, 'block offer_institution');
		}

		// park
		if ($offer->contact_is_park_partner == 1) {
			$offer->contact = '<div class="partner"><i>'.$this->api->lang->get('offer_park_partner').'</i></div>' . auto_text_format($offer->contact);
		}
		$template_data['OFFER_CONTACT'] = $this->_show_text($this->api->lang->get('offer_contact'), $offer->contact, 'block offer_contact');


		/*
		|--------------------------------------------------------------------------
		| Placeholder: subscription
		|--------------------------------------------------------------------------
		|
		*/
		if (isset($offer->subscription_mandatory) && ($offer->subscription_mandatory == TRUE)) {
			$template_data['OFFER_SUBSCRIPTION'] = $this->_get_detail_subscription($offer);
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: POIs
		|--------------------------------------------------------------------------
		|
		*/
		if (isset($offer->poi) && !empty($offer->poi)) {
			$template_data['OFFER_POI_LIST'] = $this->_get_poi_content($offer->poi, $offer->offer_id, $offer->root_category);
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholders: detail pages
		|--------------------------------------------------------------------------
		|
		*/
		switch ($offer->root_category) {
			case CATEGORY_EVENT:
				$template_data['OFFER_EVENT_DETAIL'] = $this->_get_detail_event($offer);
				$template_conditions['OFFER_EVENT'] = TRUE;
				break;
			case CATEGORY_PRODUCT:
				$template_data['OFFER_PRODUCT_DETAIL'] = $this->_get_detail_product($offer);
				$template_conditions['OFFER_PRODUCT'] = TRUE;
				break;
			case CATEGORY_BOOKING:
				$template_data['OFFER_BOOKING_DETAIL'] = $this->_get_detail_booking($offer);
				$template_conditions['OFFER_BOOKING'] = TRUE;
				break;
			case CATEGORY_ACTIVITY:
				$template_data['OFFER_ACTIVITY_DETAIL'] = $this->_get_detail_activity($offer);
				$template_conditions['OFFER_ACTIVITY'] = TRUE;
				break;
			case CATEGORY_PROJECT:
				$template_data['OFFER_PROJECT_DETAIL'] = $this->_get_detail_project($offer);
				$template_conditions['OFFER_PROJECT'] = TRUE;
				break;
			case CATEGORY_RESEARCH:
				$template_data['OFFER_RESEARCH_DETAIL'] = $this->_get_detail_research($offer);
				$template_conditions['OFFER_RESEARCH'] = TRUE;
				break;
			default:
				break;
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: images
		|--------------------------------------------------------------------------
		|
		*/
		$config_image_enlargement = isset($this->config['image_enlargement']) ? $this->config['image_enlargement'] : FALSE;
		$config_thumbnail_size = isset($this->config['detail_thumbnail_size']) ? $this->config['detail_thumbnail_size'] : 'medium';
		if (isset($offer->images) && is_array($offer->images) && !empty($offer->images)) {
			$template_data['OFFER_IMAGES'] = '<div class="detail_pictures pictures">';
			foreach ($offer->images as $image) {
				$template_data['OFFER_IMAGES'] .= '<div class="attachment picture">';

				if ($config_image_enlargement === TRUE) {
					$template_data['OFFER_IMAGES'] .= '<a href="'.$image->large.'" class="offer_image" rel="offer_images">';
				}

				$template_data['OFFER_IMAGES'] .= '<img src="'.$image->{$config_thumbnail_size}.'" alt="'.$offer->title.'" class="offer_detail_image">';

				if (!empty($image->copyright)) {
					$template_data['OFFER_IMAGES'] .= '<div class="image_description">';
					if (!strstr($image->copyright, '©') && !strstr($image->copyright, '&copy; ')) {
						$template_data['OFFER_IMAGES'] .= '&copy;';
					}
					$template_data['OFFER_IMAGES'] .= $image->copyright.'</div>';
				}

				if ($config_image_enlargement === TRUE) {
					$template_data['OFFER_IMAGES'] .= '</a>';
				}

				$template_data['OFFER_IMAGES'] .= '</div>';
			}
			$template_data['OFFER_IMAGES'] .= '</div>';
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: documents
		|--------------------------------------------------------------------------
		|
		*/
		if (isset($offer->documents) && (count($offer->documents) > 0)) {
			$documents = '';
			foreach ($offer->documents as $document) {
				$documents .= '<a href="'.$document->url.'" class="download_link" target="_blank">'.($document->title ? $document->title : $document->url).'</a><br>';
			}
			$template_data['OFFER_DOCUMENTS'] = $this->_show_text($this->api->lang->get('offer_documents_public'), $documents, 'block offer_documents');
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: print button
		|--------------------------------------------------------------------------
		|
		*/
		$template_data['OFFER_PRINT_LINK'] = '
			<a class="print" href="javascript:void(0);" onclick="iframe_detail_print(\''.$this->config['base_url'].$this->api->lang_id.'/export/iframe/print/'.$this->config['api_hash'].'/'.$offer->offer_id.'?logo=true\', \''.$this->api->lang->get('swissmap_print_title').'\');">
				<i>l</i><span>'.$this->api->lang->get('swissmap_print').'</span>
			</a>
		';


		/*
		|--------------------------------------------------------------------------
		| Placeholder: back link button
		|--------------------------------------------------------------------------
		|
		*/
		$template_data['OFFER_BACK_LINK'] = '';
		if (!isset($this->api->map_options['link_target']) || ($this->api->map_options['link_target'] != '_blank')) {

			// is poi detail
			if (isset($_GET["poi"])) {
				$back_button_label = (isset($_GET['original_category']) && ($_GET['original_category'] != CATEGORY_PROJECT)) ? $this->api->lang->get('back_to_route') : $this->api->lang->get('back_to_project');
				$template_data['OFFER_BACK_LINK'] = '<a class="back_to_overview" href="'.$this->script_url.(strstr($this->script_url, '?') ? '&amp' : '?').'offer='.intval($_GET["poi"]).(isset($_GET['tab']) ? ('#'.$_GET['tab']) : '').'"><i>c</i><span>'.$back_button_label.'</span></a>';
			}

			// history back button, referrer is set
			elseif (!empty($_SERVER['HTTP_REFERER']) && strstr($_SERVER['HTTP_REFERER'], $this->script_url) && !strstr($_SERVER['HTTP_REFERER'], '?offer=')) {
				// javascript back button
				$template_data['OFFER_BACK_LINK'] = '<a class="go_back" href="javascript:void(0);"><i>c</i><span>'.$this->api->lang->get('back_to_overview').'</span></a>';
			}

			// default back button with reload, referrer is empty
			else {
				$template_data['OFFER_BACK_LINK'] = '<a class="back_to_overview" href="'.$this->script_url.'"><i>c</i><span>'.$this->api->lang->get('back_to_overview').'</span></a>';
			}

		}
		else if (!empty($this->api->map_options['link_target']) && ($this->api->map_options['link_target'] == '_blank')) {
			// javascript close window button
			$template_data['OFFER_BACK_LINK'] = '<a class="close_window" href="javascript:void(0);"><i>c</i><span>'.$this->api->lang->get('back_to_overview').'</span></a>';
		}


		/*
		|--------------------------------------------------------------------------
		| Placeholder: map
		|--------------------------------------------------------------------------
		|
		*/
		if (!empty($offer->poi) && ($offer->root_category == CATEGORY_ACTIVITY)) {
			$template_data['OFFER_MAP'] = $this->_get_detail_map_poi($offer);
		}
		else {
			$template_data['OFFER_MAP'] = $this->_get_detail_map($offer);
		}


		/*
		|--------------------------------------------------------------------------
		| Merge detail template tags
		|--------------------------------------------------------------------------
		|
		*/
		if (!empty($this->detail_template_tags) && is_array($this->detail_template_tags)) {
			$template_data = array_merge($template_data, $this->detail_template_tags);
		}


		/*
		|--------------------------------------------------------------------------
		| Overwrite template data in MyView
		|--------------------------------------------------------------------------
		|
		*/
		$template_data = $this->overwrite_template_data($template_data, $offer);


		/*
		|--------------------------------------------------------------------------
		| Compile template
		|--------------------------------------------------------------------------
		|
		*/
		$output = $this->api->compile_template('detail', $template_data, $template_conditions);
		if ($this->return_output === TRUE) {
			return $output;
		}
		else {
			echo $output;
		}

	}


	/**
	 * Get detail description
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_offer_dates($offer) {

		$dates = '';

		if (isset($offer->dates) && ($offer->root_category != CATEGORY_PROJECT)) {

			// count all dates
			$now = new DateTime();
			$date_counter = 0;
			$total_dates = 0;
			if (!empty($offer->dates)) {
				foreach ($offer->dates as $date) {

					// prepare dates
					$date_from = new DateTime($date->date_from);
					$date_to = NULL;
					if (!empty($date->date_to)) {
						$date_to = new DateTime($date->date_to);
					}

					// count only future events (exception: category product)
					if (($now < $date_from) || (!empty($date_to) && ($now < $date_to)) || ($offer->root_category == CATEGORY_PRODUCT)) {
						$total_dates++;
					}
				}
			}

			// iterate all dates
			if (!empty($offer->dates)) {
				$dates = '<div class="dates">';
				foreach ($offer->dates as $date) {

					// prepare dates
					$date_from = new DateTime($date->date_from);
					$date_to = NULL;
					if (!empty($date->date_to)) {
						$date_to = new DateTime($date->date_to);
					}

					// show only future events (exception: category product)
					if (($now < $date_from) || (!empty($date_to) && ($now < $date_to)) || ($offer->root_category == CATEGORY_PRODUCT)) {

						// count date
						$date_counter++;

						// add date
						$dates .= parks_show_date(array('date_from'=>parks_mysql2form($date->date_from), 'date_to' => parks_mysql2form($date->date_to))).'<br>';

						// start hidden layer
						if ((!isset($print_mode) || ($print_mode == FALSE)) && ($total_dates > DETAIL_DATE_LIMIT)) {
							if (DETAIL_DATE_LIMIT == $date_counter) {
								$dates .= '</div><div class="hidden_content" style="display: none;">';
							}

							// end hidden layer
							if ($total_dates == $date_counter) {
								$dates .= '</div>';
							}
						}

					}
				}

				// show more/less buttons
				if ((!isset($print_mode) || ($print_mode == FALSE)) && ($total_dates > DETAIL_DATE_LIMIT)) {
					$dates .= '
						<div class="more_less_buttons">
							<a class="show_more" href="javascript:void(0);">'.$this->api->lang->get('show_more').'</a>
							<a class="show_less" href="javascript:void(0);" style="display: none;">'.$this->api->lang->get('show_less').'</a>
						</div>
					';
				}
				else {
					$dates .= '</div>';
				}

			}
			else {
				$dates .= '<p>'.$this->api->lang->get('offer_all_season').'</p>';
			}

			// date condition
			if (empty($offer->dates) || ($total_dates > 0)) {

				// set title
				$dates_title = $this->api->lang->get('offer_dates');
				if (($offer->root_category == CATEGORY_BOOKING) || ($offer->root_category == CATEGORY_RESEARCH)) {
					$dates_title = $this->api->lang->get('offer_execution_times');
				}
				if (($offer->root_category == CATEGORY_PRODUCT) || ($offer->root_category == CATEGORY_ACTIVITY)) {
					$dates_title = $this->api->lang->get('offer_saison');
				}

				// output
				$dates = $this->_show_text($dates_title, $dates, 'block offer_dates');
			}

		}

		return $dates;
	}


	/**
	 * Get POI content
	 *
	 * @access protected
	 * @param mixed $pois
	 * @param mixed $offer_id
	 * @param mixed $original_category
	 * @return void
	 */
	protected function _get_poi_content($pois, $offer_id, $original_category) {
		$offers = $this->api->show_offer_poi_list($pois);
		$offers = array('data' => $offers, 'total' => count($offers));
		$output = $this->list($offers, TRUE, $offer_id, $original_category);
		return $output;
	}


	/**
	 * Get detail map view
	 *
	 * @access protected
	 * @param mixed $return
	 * @param mixed $add_markers_function
	 * @return void
	 */
	protected function _get_detail_map_view($return, $add_markers_function) {

		$return .=

			$this->_get_swissmap_html().'
			<script type="text/javascript">
				'.$add_markers_function.'
			</script>
			</div>

		';

		return $return;
	}


	/**
	 * Get event detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_event($offer) {

		// load template data
		$template_data['OFFER_ADDITIONAL_INFO'] = $this->_prepare_additional_infos($offer);
		$template_data['OFFER_DATES'] = $this->_get_offer_dates($offer);
		$template_data['OFFER_EVENT_LOCATION'] = trim($this->_show_text($this->api->lang->get('offer_event_location'), $offer->institution, 'block event_location'));
		$template_data['OFFER_EVENT_DATE_DETAILS'] = trim($this->_show_text($this->api->lang->get('offer_date_details'), $offer->details, 'block date_details'));
		$template_data['OFFER_EVENT_LOCATION_DETAILS'] = trim($this->_show_text($this->api->lang->get('offer_location_details'), $offer->location_details, 'block location_details'));
		if (!empty($offer->public_transport_stop) && (strlen($offer->public_transport_stop) >= $this->config['min_chars_sbb_link'])) {
			$template_data['OFFER_EVENT_TRANSPORT'] = trim($this->_show_text($this->api->lang->get('offer_public_transport_stop'), $offer->public_transport_stop.' <a href="'.$this->sbb_link.'?nach='.urlencode($offer->public_transport_stop).'" target="_blank" class="sbb">'.$this->api->lang->get('offer_timetable_sbb').'</a>', 'block public_transport_stop'));
		}
		$template_data['OFFER_EVENT_PRICE'] = trim($this->_show_text($this->api->lang->get('offer_price'), $offer->price, 'block price'));

		// compile template data
		return $this->_compile_output($template_data);

	}


	/**
	 * Get product detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_product($offer) {

		// load template data
		$template_data['OFFER_ADDITIONAL_INFO'] = $this->_prepare_additional_infos($offer);
		$template_data['OFFER_DATES'] = $this->_get_offer_dates($offer);
		$template_data['OFFER_PRODUCT_OPENING_HOURS'] = trim($this->_show_text($this->api->lang->get('offer_opening_hours'), $offer->opening_hours, 'block opening_hours'));
		if (!empty($offer->public_transport_stop) && (strlen($offer->public_transport_stop) >= $this->config['min_chars_sbb_link'])) {
			$template_data['OFFER_PRODUCT_PUBLIC_TRANSPORT'] = trim($this->_show_text($this->api->lang->get('offer_public_transport_stop'), $offer->public_transport_stop.' <a href="'.$this->sbb_link.'?nach='.urlencode($offer->public_transport_stop).'" target="_blank" class="sbb">'.$this->api->lang->get('offer_timetable_sbb').'</a>', 'block public_transport_stop'));
		}
		$template_data['OFFER_PRODUCT_INFRASTRUCTURE'] = trim($this->_show_text($this->api->lang->get('offer_infrastructure'), $this->_get_detail_infrastructure($offer), 'block infrastructure'));
		$template_data['OFFER_PRODUCT_PRICE'] = trim($this->_show_text($this->api->lang->get('offer_price'), $offer->price, 'block price'));

		// compile template data
		return $this->_compile_output($template_data);

	}


	/**
	 * Get booking detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_booking($offer) {

		// load template data
		$template_data['OFFER_ADDITIONAL_INFO'] = $this->_prepare_additional_infos($offer);
		$template_data['OFFER_DATES'] = $this->_get_offer_dates($offer);
		$template_data['OFFER_BOOKING_GROUPS'] = $this->_get_detail_groups($offer);
		$template_data['OFFER_BOOKING_BENEFITS'] = trim($this->_show_text($this->api->lang->get('offer_benefits'), $offer->benefits, 'block benefits'));
		$template_data['OFFER_BOOKING_REQUIREMENTS'] = trim($this->_show_text($this->api->lang->get('offer_requirements'), $offer->requirements, 'block requirements'));
		$template_data['OFFER_BOOKING_ACCOMMODATIONS'] = trim($this->_show_text($this->api->lang->get('offer_accommodation'), $this->_get_accommodations($offer), 'block accommodations'));
		if (!empty($offer->public_transport_stop) && (strlen($offer->public_transport_stop) >= $this->config['min_chars_sbb_link'])) {
			$template_data['OFFER_BOOKING_TRANSPORT'] = trim($this->_show_text($this->api->lang->get('offer_public_transport_stop'), $offer->public_transport_stop.' <a href="'.$this->sbb_link.'?nach='.urlencode($offer->public_transport_stop).'" target="_blank" class="sbb">'.$this->api->lang->get('offer_timetable_sbb').'</a>', 'block public_transport_stop'));
		}
		$template_data['OFFER_BOOKING_PRICE'] = trim($this->_show_text($this->api->lang->get('offer_price'), $offer->price, 'block price'));

		// compile template data
		return $this->_compile_output($template_data);

	}


	/**
	 * Get activity detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_activity($offer) {

		// load template data
		$template_data['OFFER_ADDITIONAL_INFO'] = $this->_prepare_additional_infos($offer);
		$template_data['OFFER_DATES'] = $this->_get_offer_dates($offer);
		$template_data['OFFER_ACTIVITY_ROUTE'] = trim($this->_show_text($this->api->lang->get('offer_route_info'), $this->_get_route_details($offer), 'block route_info rwd-info-block'));
		$template_data['OFFER_ACTIVITY_ARRIVAL'] = trim($this->_show_text($this->api->lang->get('offer_arrival'), $this->_get_route_start_stop($offer), 'block arrival rwd-info-block'));
		$template_data['OFFER_ACTIVITY_SIGNALIZATION'] = trim($this->_show_text($this->api->lang->get('offer_signalization'), $offer->signalization, 'block signalization'));
		$template_data['OFFER_ACTIVITY_SAFETY_INSTRUCTIONS'] = trim($this->_show_text($this->api->lang->get('offer_safety_instructions'), $offer->safety_instructions, 'block safety_instructions'));
		$template_data['OFFER_ACTIVITY_MATERIAL_RENT'] = trim($this->_show_text($this->api->lang->get('offer_material_rent'), $offer->material_rent, 'block material_rent'));
		$template_data['OFFER_ACTIVITY_INFRASTRUCTURE'] = trim($this->_show_text($this->api->lang->get('offer_infrastructure'), $this->_get_detail_infrastructure($offer), 'block infrastructure'));
		$template_data['OFFER_ACTIVITY_PRICE'] = trim($this->_show_text($this->api->lang->get('offer_price'), $offer->price, 'block price'));
		$template_data['OFFER_ACTIVITY_CATERING'] = trim($this->_show_text($this->api->lang->get('offer_catering_informations'), $offer->catering_informations, 'block catering_informations'));

		// compile template data
		return $this->_compile_output($template_data);

	}


	/**
	 * Get project detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_project($offer) {

		// load template data
		$template_data['OFFER_ADDITIONAL_INFO'] = $this->_prepare_additional_infos($offer);
		$template_data['OFFER_PROJECT_DURATION'] = $this->_prepare_project_duration($offer);
		$template_data['OFFER_PROJECT_STATUS'] = trim($this->_show_text($this->api->lang->get('offer_project_status'), $this->config['project_status_'.$this->api->lang_id][$offer->project_status], 'block project_status'));

		// compile template data
		return $this->_compile_output($template_data);

	}


	/**
	 * Get research detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_research($offer) {

		// load template data
		$template_data['OFFER_ADDITIONAL_INFO'] = $this->_prepare_additional_infos($offer);
		$template_data['OFFER_DATES'] = $this->_get_offer_dates($offer);

		// compile template data
		return $this->_compile_output($template_data);

	}



	/**
	 * get overview map with POI elements
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_map_poi($offer) {

		// merge offer with poi offer
		$offers = $this->api->show_offer_poi_list($offer->poi);

		// call overview and return content
		if (!empty($offers)) {
			array_push($offers, $offer);
			return $this->map($offers, TRUE, $offer->offer_id);
		}
	}



	/**
	 * Get detail map
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_map($offer) {
		if (!empty($offer)) {

			$return = '<div class="offer_map_container" style="'.(($offer->root_category != CATEGORY_ACTIVITY) ? 'max-width: 600px;' : '').'">';

			// loadSwissMap()
			$add_markers_function = 'var swissmap;';
			$add_markers_function .= 'function loadSwissMap() {';
			$add_markers_function .= '	swissmap = new SwissMap("#mapContainer", function() {';
			$add_markers_function .= '		var that = this;';

			// custom map Layers
			$map_layers = $this->api->model->get_custom_layers();

			// add custom map layers
			if (!empty($map_layers) && is_array($map_layers)) {
				// Set quantity of custom layers
				$add_markers_function .= 'this.setCustomLayerQuantity('. (isset($map_layers) ? count($map_layers) : 0) .');';
				foreach ($map_layers as $layer) {
					$popup = $this->_build_popup($layer);
					$add_markers_function .= 'this.addCustomMapLayer("'.$layer->url.'", { id: "'.$layer->map_layer_id.'", position: '. (($layer->layer_position) ? $layer->layer_position : 0). ', visible: '. (($layer->visible_by_default) ? $layer->visible_by_default : 'false'). $popup .' });';
				}
			}

			$paramname = $this->config['url_param_prefix'].'offer';

			$all_categories = $this->api->model->get_all_categories();

			$offer_category = NULL;
			$offer_category_group = NULL;
			$current_level = 0;
			if (isset($offer->categories) && !empty($offer->categories)) {
				foreach ($offer->categories as $category) {
					$path = $this->api->model->get_category_path($category->parent_id);

					if (count($path) > $current_level) {
						$offer_category_group = $all_categories[reset($path)];
						$offer_category = $category;
						$current_level = count($path);
					}
				}
			}

			$add_markers_function .= '		var marker;';
			$add_markers_function .= '		this.createOfferLayerGroup('.$offer_category_group->sort.', \''.addslashes($offer_category_group->body).'\', \''.$offer_category_group->marker.'\');';
			$add_markers_function .= '		this.createOfferLayer('.$offer_category->sort.', \''.addslashes($offer_category->body).'\', \''.$offer_category->marker.'\', '.$offer_category_group->sort.');';

			if ($offer->latitude > 0 && $offer->longitude > 0) {
				$position = convertLatLonToCH1903($offer->latitude, $offer->longitude);

				if (isset($offer->route) && !empty($offer->route)) {
					$route = array();
					foreach ($offer->route as $waypoint) {
						$point = convertLatLonToCH1903($waypoint->latitude, $waypoint->longitude);
						$route[] = '['.$point['y'].', '.$point['x'].']';
					}
					$path = '['.implode(',', $route).']';
				}

				$add_markers_function .= '		this.addMarkerForLayer('.$offer_category->sort.', function() { return { point: new esri.geometry.Point('.$position['y'].', '.$position['x'].', that.spatialReference),'.((isset($offer->route) && !empty($offer->route)) ? ' route: new esri.geometry.Polyline({ paths: ['.$path.'], spatialReference: that.spatialReference }),' : '').' symbol: \''.$offer_category->marker.'\' } });';
			}

			$config = array(
				'defaultBaseMap' => 'pixelkarte',
				'cookieName' => 'swissmap_detail_'.md5($this->script_url),
				'cookieOptions' => array('path' => $this->script_url),
				'offerLayerVisibility' => TRUE,
				'disableClustering' => TRUE,
				'fitOfferExtent' => TRUE,
				'lang' => $this->api->lang_id,
				'hash' => $this->config['api_hash'],
				'base_url' => $this->config['base_url'],
				'type' => 'api',
				'printUrl' => $this->config['base_url'].$this->api->lang_id.'/export/iframe/print/'.$this->config['api_hash'].'/'.$offer->offer_id.'?logo=true'
			);

			$config_ui = array(
				'canvasWidth' => 78,
				'sidebarVisible' => FALSE,
				'noPrint' => TRUE
			);

			if (isset($_SESSION[$this->api->session_name]['selectedPark']) && !empty($_SESSION[$this->api->session_name]['selectedPark'])) {
				$config['selectedPark'] = $_SESSION[$this->api->session_name]['selectedPark'];
			}

			if (isset($offer->route) && !empty($offer->route)) {
				$config_ui['showElevationProfile'] = TRUE;
			}

			$add_markers_function .= '	}, '.json_encode($config).', '.json_encode($config_ui).');';
			$add_markers_function .= '}';

			return $this->_get_detail_map_view($return, $add_markers_function);
		}
	}


	/**
	 * Get subscription detail
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_detail_subscription($offer) {

		$return = '
			<div class="detail_text">
				<p>
					'.(($offer->subscription_mandatory == 2) ? $this->api->lang->get('offer_subscription_info_recommended') : $this->api->lang->get('offer_subscription_info_mandatory')).'
				</p>
		';

		// subscription details
		if (!empty($offer->subscription_details)) {
			$return .= '
				<p>
					'.auto_text_format($offer->subscription_details).'
				</p>
			';
		}

		// subscription contact
		if (!empty($offer->subscription_contact)) {
			$return .= '
				<h2>'.$this->api->lang->get('offer_subscription_contact').'</h2>
				<p>
					'.auto_text_format($offer->subscription_contact).'
				</p>
			';
		}

		// subscription link
		if (!empty($offer->subscription_link)) {
			$return .= '
				<div class="text_right">
					<a class="sign_in button" target="_blank" href="'.$offer->subscription_link.'">'.$this->api->lang->get('offer_subscription_subscribe_now').'</a>
				</div>
			';
		}

		// subscribe now button
		if ($offer->online_subscription_enabled == 1) {
			$return .= '
				<div class="text_right">
					<a class="sign_in button" target="_blank" href="'.$this->config['base_url'].'subscription/subscriber/'.$offer->offer_id.'">'.$this->api->lang->get('offer_subscription_subscribe_now').'</a>
				</div>
			';
		}

		$return .= '</div>';

		return $return;
	}


	/**
	 * Get infrastructure details
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return string
	 */
	protected function _get_detail_infrastructure($offer) {

		// other infrastructure
		$other_infrastructure = '';
		if (!empty($offer->other_infrastructure)) {
			$other_infrastructure = '<p>'.auto_text_format($offer->other_infrastructure).'</p>';
		}

		// infrastructure
		$infrastructure = array();
		if (!empty($offer->number_of_rooms)) {
			$infrastructure[] = sprintf($this->api->lang->get('offer_rooms'), $offer->number_of_rooms);
		}
		if (!empty($offer->has_conference_room)) {
			$infrastructure[] = $this->api->lang->get('offer_conference_room');
		}
		if (!empty($offer->has_playground)) {
			$infrastructure[] = $this->api->lang->get('offer_playground');
		}
		if (!empty($offer->has_picnic_place)) {
			$infrastructure[] = $this->api->lang->get('offer_picnic_place');
		}
		if (!empty($offer->has_fireplace)) {
			$infrastructure[] = $this->api->lang->get('offer_fireplace');
		}
		if (!empty($offer->has_washrooms)) {
			$infrastructure[] = $this->api->lang->get('offer_washroom');
		}
		$infrastructure = (count($infrastructure) > 0) ? '<ul><li>'.implode('</li><li>', $infrastructure).'</li></ul>' : '';

		// return details
		return $other_infrastructure.$infrastructure;

	}


	/**
	 * Get accommodations
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return string
	 */
	protected function _get_accommodations($offer) {
		$accommodations = '';

		if (isset($offer->accommodations) && !empty($offer->accommodations)) {
			foreach ($offer->accommodations as $accommodation) {
				if (!empty($accommodation['is_park_partner'])) {
					$accommodations .= '<div class="partner"><i>'.$this->api->lang->get('offer_park_partner').'</i></div>';
				}
				$accommodations .= '<p>'.auto_text_format($accommodation['contact']).'</p>';
			}
		}

		return $accommodations;
	}


	/**
	 * Get route details
	 *
	 * @access protected
	 * @return void
	 */
	protected function _get_route_details($offer) {
		$route_details = '';

		if (!empty($offer)) {
			if (!empty($offer->route_length) && ($offer->route_length > 0)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_route_length').'</dt><dd>'.((intval($offer->route_length) > 0) ? $offer->route_length : '').' '.$this->api->lang->get('offer_route_length_km').'</dd>';
			}
			if (!empty($offer->untarred_route_length) && ($offer->untarred_route_length > 0)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_untarred_route_length').'</dt><dd>'.((intval($offer->untarred_route_length) > 0) ? $offer->untarred_route_length : '').' '.$this->api->lang->get('offer_route_length_km').'</dd>';
			}
			if (!empty($offer->altitude_differential) && ($offer->altitude_differential > 0)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_altitude_differential').'</dt><dd>'.$offer->altitude_differential.' '.$this->api->lang->get('offer_altitude_meter').'</dd>';
			}
			if (!empty($offer->altitude_ascent) && ($offer->altitude_ascent > 0)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_altitude_ascent').'</dt><dd>'.$offer->altitude_ascent.' '.$this->api->lang->get('offer_altitude_meter').'</dd>';
			}
			if (!empty($offer->altitude_descent) && ($offer->altitude_descent > 0)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_altitude_descent').'</dt><dd>'.$offer->altitude_descent.' '.$this->api->lang->get('offer_altitude_meter').'</dd>';
			}
			if (!empty($offer->time_required)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_time_required').'</dt><dd>'.$offer->time_required.'</dd>';
			}
			if (!empty($offer->level_technics)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_level_technics').'</dt><dd>'.$this->api->model->levels[$offer->level_technics].'</dd>';
			}
			if (!empty($offer->level_condition)) {
				$route_details .= '<dt>'.$this->api->lang->get('offer_level_condition').'</dt><dd>'.$this->api->model->levels[$offer->level_condition].'</dd>';
			}
			if (!empty($route_details)) {
				$route_details = '<dl>'.$route_details.'</dl>';
			}
		}

		return $route_details;
	}


	/**
	 * Show offer start and stop place
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return void
	 */
	protected function _get_route_start_stop($offer) {
		$start_stop_place = '';

		if (!empty($offer)) {

			if (!empty($offer->start_place_info) || !empty($offer->goal_place_info)) {
				$start_stop_place .= '<dl>';
			}

			// start
			if (!empty($offer->start_place_info)) {
				$start_stop_place .= '<dt>'.$this->api->lang->get('offer_start_place').'</dt><dd>'.$offer->start_place_info;
				if (!empty($offer->start_place_altitude)) {
					$start_stop_place .= ' ('.$this->api->lang->get('offer_altitude').': '.$offer->start_place_altitude.' '.$this->api->lang->get('offer_altitude_meter').')';
				}
				$start_stop_place .= '</dd>';
				if (!empty($offer->public_transport_start) && (strlen($offer->public_transport_start) >= $this->config['min_chars_sbb_link'])) {
					$start_stop_place .= '<dt>'.$this->api->lang->get('offer_public_transport_stop').'</dt><dd>'.$offer->public_transport_start.' <a href="'.$this->sbb_link.'?nach='.urlencode($offer->public_transport_start).'" target="_blank" class="sbb">'.$this->api->lang->get('offer_timetable_sbb').'</a></dd>';
				}
			}

			// stop / goal
			if (!empty($offer->goal_place_info)) {
				$start_stop_place .= '<div class="content-margin-cf"></div><dt>'.$this->api->lang->get('offer_goal_place').'</dt><dd>'.$offer->goal_place_info;
				if (!empty($offer->goal_place_altitude)) {
					$start_stop_place .= ' ('.$this->api->lang->get('offer_altitude').': '.$offer->goal_place_altitude.' '.$this->api->lang->get('offer_altitude_meter').')';
				}
				$start_stop_place .= '</dd>';
				if (!empty($offer->public_transport_stop) && (strlen($offer->public_transport_stop) >= $this->config['min_chars_sbb_link'])) {
					$start_stop_place .= '<dt>'.$this->api->lang->get('offer_public_transport_stop').'</dt><dd>'.$offer->public_transport_stop.' <a href="'.$this->sbb_link.'?nach='.urlencode($offer->public_transport_stop).'" target="_blank" class="sbb">'.$this->api->lang->get('offer_timetable_sbb').'</a></dd>';
				}
			}

			if (!empty($offer->start_place_info) || !empty($offer->goal_place_info)) {
				$start_stop_place .= '</dl>';
			}

		}

		return $start_stop_place;
	}


	/**
	 * Get group details
	 *
	 * @access protected
	 * @param mixed $offer
	 * @return string
	 */
	protected function _get_detail_groups($offer) {

		// group subscriber
		$group_subscriber = '';
		if (!empty($offer->min_group_subscriber) || !empty($offer->max_group_subscriber)) {

			// min/max subscribers
			if (!empty($offer->min_group_subscriber)) {
				$group_subscriber .= $this->api->lang->get('offer_min_subscriber').' '.$offer->min_group_subscriber.'<br>';
			}
			if (!empty($offer->max_group_subscriber)) {
				$group_subscriber .= $this->api->lang->get('offer_max_subscriber').' '.$offer->max_group_subscriber;
			}

			// prepare view
			$group_subscriber = $this->_show_text($this->api->lang->get('offer_number_of_people_groups'), $group_subscriber, 'block number_of_people_groups');

		}

		// individual subscriber
		$individual_subscriber = '';
		if (!empty($offer->min_individual_subscriber) || !empty($offer->max_individual_subscriber)) {

			// min/max subscribers
			if (!empty($offer->min_individual_subscriber)) {
				$individual_subscriber .= $this->api->lang->get('offer_min_subscriber').' '.$offer->min_individual_subscriber.'<br>';
			}
			if (!empty($offer->max_individual_subscriber)) {
				$individual_subscriber .= $this->api->lang->get('offer_max_subscriber').' '.$offer->max_individual_subscriber;
			}

			// prepare view
			$individual_subscriber = $this->_show_text($this->api->lang->get('offer_number_of_people_individual'), $individual_subscriber, 'block number_of_people_individual');
		}

		return $group_subscriber.$individual_subscriber;

	}


	/**
	 * Returns HTML required for displaying the SwissMap
	 *
	 * @access protected
	 * @return string
	 */
	protected function _get_swissmap_html() {
		$output  = '<div id="mapContainer"></div>';
		return $output;
	}


	/**
	 * Prepare additional informations
	 *
	 * @param object $offer
	 * @access protected
	 * @return string
	 */
	protected function _prepare_additional_infos($offer) {
		$additional_info = array();

		// prepare options
		if (!empty($offer->barrier_free)) {
			$additional_info[] = $this->api->lang->get('offer_barrier_free');
		}
		if (!empty($offer->learning_opportunity)) {
			$additional_info[] = $this->api->lang->get('offer_learning_opportunity');
		}
		if (!empty($offer->child_friendly)) {
			$additional_info[] = $this->api->lang->get('offer_child_friendly');
		}
		if (!empty($offer->park_day)) {
			$additional_info[] = $this->api->lang->get('offer_park_day');
		}
		if (!empty($offer->enjoy_week)) {
			$additional_info[] = $this->api->lang->get('offer_enjoy_week');
		}

		// prepare output
		if (empty($print_mode)) {
			$additional_info = (count($additional_info) > 0) ? '<ul class="margin_top"><li>'.implode("</li><li>", $additional_info)."</li></ul>" : "";
		}
		elseif (!empty($additional_info)) {
			$additional_info = '<p>- '.implode('<br>- ', $additional_info).'</p>';
		}
		else {
			$additional_info = '';
		}

		// return string
		if (!empty($offer->additional_informations) || !empty($additional_info)) {
			return $this->_show_text('', '<p>'.auto_text_format($offer->additional_informations).'</p>'.$additional_info, 'block additional_informations');
		}

		return FALSE;
	}


	/**
	 * Prepare project duration
	 *
	 * @param object $offer
	 * @access protected
	 * @return string
	 */
	protected function _prepare_project_duration($offer) {

		// prepare duration
		$duration = '';
		if (isset($offer->duration_from) && ($offer->duration_from > 0)) {
			if ($offer->duration_from != $offer->duration_to) {
				$duration .= $this->api->lang->get('offer_from').' ';
			}
			$duration .= '<strong>'.$offer->duration_from.'</strong>';
			if ($offer->duration_from != $offer->duration_to) {
				$duration .= ' '.$this->api->lang->get('offer_to').' <strong>'.$offer->duration_to.'</strong>';
			}
		}

		// return string
		if (!empty($duration)) {
			return $this->_show_text($this->api->lang->get('offer_project_duration'), $duration, 'block project_duration');
		}

		return FALSE;
	}


	/**
	 * Get string
	 *
	 * @access protected
	 * @param mixed $string
	 * @param string $suffix (default: "")
	 * @param string $prefix (default: "")
	 * @return void
	 */
	protected function _get_string($string, $suffix = "", $prefix = "") {
		if (!empty($string)) {
			return $prefix.$string.$suffix;
		}

		return "";
	}


	/**
	 * Truncate string
	 *
	 * @access protected
	 * @param mixed $string
	 * @param mixed $length
	 * @return void
	 */
	protected function _truncate_string($string, $length) {
		if (mb_strlen($string) > $length) {
			return mb_substr($string, 0, $length)."...";
		}

		return $string;
	}


	/**
	 * Prepare detail block
	 *
	 * @access protected
	 * @param mixed $title
	 * @param mixed $content
	 * @param string $class (default: "")
	 * @return void
	 */
	protected function _show_text($title, $content, $class = "") {

		$return = "";

		// check html tags
		$has_html = FALSE;
		if ($content != strip_tags($content)) {
			$has_html = TRUE;
		}

		// output
		if (!empty($content)) {
			$return .= '
				<div class="'.$class.'">
					<div class="description">
						'.(!empty($title) ? '<h2>'.$title.'</h2>' : '').
						(($has_html == TRUE) ? $content : auto_text_format($content)).'
					</div>
				</div>
			';
		}

		return $return;
	}


	/**
	 * Build popup of custom layer
	 *
	 * @access protected
	 * @param mixed $layer
	 * @return void
	 */
	protected function _build_popup($layer) {

		$popup = ', popup: { ';

		// set title
		$popup .= isset($layer->popup_title) ? ('title: "'. $layer->popup_title .'", ') : NULL;

		// set logo with size
		if (isset($layer->popup_logo)) {
			$popup .= 'logo: "'. $this->config['base_url'].$layer->popup_logo .'", ';
			$popup .= (isset($layer->popup_logo_width) && ($layer->popup_logo_width > 0)) ? ('logo_width: "'. $layer->popup_logo_width .'",  ') : 'width : "auto",';
			$popup .= (isset($layer->popup_logo_height) && ($layer->popup_logo_height > 0)) ? ('logo_height: "'. $layer->popup_logo_height .'",  ') : 'height :"auto",';
		}

		// show new lines
		if (isset($layer->popup_content)) {
			foreach ($layer->popup_content as $key => $popup_content) {
				$layer->popup_content[$key] = nl2br($popup_content);
			}
		}

		// set content
		$popup .= isset($layer->popup_content) ? ('content: '. json_encode($layer->popup_content) .' ') : '';
		$popup .= ' }';

		return $popup;

	}


	/**
	 * Compile template output
	 *
	 * @access protected
	 * @param mixed $template_data
	 * @return void
	 */
	protected function _compile_output($template_data) {
		$output = '';

		if (!empty($template_data)) {

			// iterate template placeholders
			foreach ($template_data as $key => $value) {

				// set template tag
				$this->detail_template_tags[$key] = $value;

				// set output
				$output .= $value;

			}

			// return output
			if (!empty($output)) {
				return $output;
			}

		}

		return FALSE;
	}



}