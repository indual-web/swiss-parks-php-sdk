<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| Main API class
|
*/


class ParksAPI {


	/**
	 * API info
	 */
	public $api;


	/**
	 * API hash
	 */
	public $hash;


	/**
	 * Park ID
	 */
	public $park_id;


	/**
	 * Configuration
	 */
	public $config;


	/**
	 * Language
	 */
	public $lang_id;
	public $lang;


	/**
	 * Model object
	 */
	public $model;


	/**
	 * Database object
	 */
	public $db;


	/**
	 * Logger object
	 */
	public $logger;


	/**
	 * Template
	 */
	public $template = array();


	/**
	 * View object
	 */
	public $view;


	/**
	 * Map options
	 */
	public $map_options;


	/**
	 * View mode
	 * TRUE: Returns the API output as string
	 * FALSE: Echoes the output directly
	 */
	public $return_output;


	/**
	 * Filter object and data
	 */
	public $filter = FALSE;
	public $filter_data = array();


	/**
	 * Pagination
	 */
	public $page;
	public $total;


	/**
	 * Session
	 */
	public $session_name;


	/**
	 * Favorites
	 */
	public $favorites_cookie_name = '';
	public $favorites = array();



	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @param  string
	 * @return void
	 */
	function __construct($language = NULL, $hash = NULL) {

		// get config
		$this->config = $this->_get_config();

		// check config
		if (!empty($this->config)) {

			// get park id
			$this->park_id = !empty($this->config['park_id']) ? $this->config['park_id'] : NULL;

			// set absolute path
			$dirname = dirname(__FILE__);
			$this->config['absolute_path'] = substr($dirname, 0, strrpos($dirname, '/'));

			// set data hash
			$this->hash = !empty($hash) ? $hash : $this->config['api_hash'];
			$this->return_output = isset($this->config['return_output']) ? $this->config['return_output'] : FALSE;

			// instance of ParksLanguage
			$this->lang = new ParksLanguage($language, $this);
			$this->lang_id = $this->lang->lang_id;

			// instance of ParksLog
			$this->logger = new ParksLog($this);

			// instance of ParksMySQL
			$this->db = new ParksMySQL($this->config['db_hostname'], $this->config['db_username'], $this->config['db_password'], $this->config['db_database']);

			// instance of ParksModel
			$this->model = new ParksModel($this);

			// load system config
			$this->_load_system_config();

			// instance of ParksView
			if (class_exists($this->config['class_view'])) {
				$this->view = new $this->config['class_view']($this);
			}
			else {
				echo 'The custom view file does not exist.';
				exit();
			}

			// init setup
			$this->_setup();

			// init session
			if ($this->config['use_sessions']) {
				$this->session_name = $this->config['session_name'].'_'.md5($this->view->script_url);

				// init favorites
				$this->favorites_cookie_name = $this->config['session_name'].'_favorites';
				if (isset($_SESSION[$this->favorites_cookie_name]) && is_array($_SESSION[$this->favorites_cookie_name]) && !empty($_SESSION[$this->favorites_cookie_name])) {
					$this->favorites = $_SESSION[$this->favorites_cookie_name];
				}
				elseif (isset($_COOKIE[$this->favorites_cookie_name]) && ($_COOKIE[$this->favorites_cookie_name] != '')) {
					$this->favorites = unserialize($_COOKIE[$this->favorites_cookie_name]);
					$_SESSION[$this->favorites_cookie_name] = $this->favorites;
				}
			}

			// init filter
			$paramname = $this->config['form_prefix'].'reset';
			if (isset($_GET[$paramname])) {
				$this->_reset_filter();
			}
			else {
				$this->_init_filter();
			}

			// load template
			$this->load_template();

		}
	}


	/**
	 * Updates database from XML export
	 *
	 * @access public
	 * @return void
	 */
	public function update($force = FALSE) {

		$xml = $this->config['xml_export_offer_url'].$this->hash;
		$xml_map_layer = $this->config['xml_export_map_layer_url'].$this->hash;
		$xml_active_offers = $this->config['xml_export_active_offers'].$this->hash;

		// Import data from XML into database
		$importer = new ParksImport($this);
		$importer->import($xml, $force);
		$importer->import_map_layers($xml_map_layer);
		$importer->clean_up_offers($xml_active_offers);

	}


	/**
	 * Migrate database updates
	 *
	 * @access public
	 * @return void
	 */
	public function migrate() {

		// Migrate database to newer versions
		$migration = new ParksMigration($this);
		$migration->start();

	}


	/**
	 * Load template
	 *
	 * @access public
	 * @return void
	 */
	public function load_template() {

		// load detail template
		if (file_exists(__DIR__.'/../template/'.$this->config['template_folder'].'/detail.tpl')) {
			$this->template['detail'] = file_get_contents(__DIR__.'/../template/'.$this->config['template_folder'].'/detail.tpl');
			$this->template['detail'] = preg_replace("/<!--(.*?)-->/s", "", $this->template['detail']);
		}

		// load filter template
		if (file_exists(__DIR__.'/../template/'.$this->config['template_folder'].'/filter.tpl')) {
			$this->template['filter'] = file_get_contents(__DIR__.'/../template/'.$this->config['template_folder'].'/filter.tpl');
			$this->template['filter'] = preg_replace("/<!--(.*?)-->/s", "", $this->template['filter']);
		}

	}


	/**
	 * Compile template
	 *
	 * @access public
	 * @param mixed $section
	 * @param array $template_data (default: array())
	 * @param array $conditions (default: array())
	 * @return void
	 */
	public function compile_template($section, $template_data = array(), $conditions = array()) {
		if (!empty($section)) {

			// load section
			$return = $this->template[$section];

			// compile template main category conditions
			foreach ($this->config['template_conditions'] as $condition_tag) {
				preg_match_all("/\[".$condition_tag."\@start\](.*?)\[".$condition_tag."\@stop\]/s", $return, $condition_found);
				if (!empty($condition_found[0])) {
					foreach ($condition_found[0] as $condition_found) {
						if (array_key_exists($condition_tag, $conditions) && !empty($conditions[$condition_tag])) {
							$remove_condition = $condition_found;
							$remove_condition = str_replace("[".$condition_tag."@start]", '', $remove_condition);
							$remove_condition = str_replace("[".$condition_tag."@stop]", '', $remove_condition);
							$return = str_replace($condition_found, $remove_condition, $return);
						}
						else {
							$return = str_replace($condition_found, '', $return);
						}
					}
				}
			}

			// compile tags
			foreach ($this->config['template_tags'] as $tag) {
				preg_match_all("/\[ISSET\(".$tag."\)\@start\](.*?)\[ISSET\(".$tag."\)@stop\]/s", $return, $condition_found);
				if (!empty($condition_found[0])) {
					foreach ($condition_found[0] as $condition_found) {
						if (array_key_exists($tag, $template_data) && !empty($template_data[$tag])) {
							$remove_condition = $condition_found;
							$remove_condition = str_replace("[ISSET(".$tag.")@start]", '', $remove_condition);
							$remove_condition = str_replace("[ISSET(".$tag.")@stop]", '', $remove_condition);
							$return = str_replace($condition_found, $remove_condition, $return);
						}
						else {
							$return = str_replace($condition_found, '', $return);
						}
					}
				}
			}

			// compile language labels
			preg_match_all("/__LANG\[(.+)\]__/i", $return, $lang_vars);
			if (!empty($lang_vars[1])) {
				foreach ($lang_vars[1] as $lang_label) {
					$lang_content = $this->lang->get($lang_label);
					if ($lang_content == $lang_label) {
						$lang_content = '';
					}
					$return = str_replace('__LANG['.$lang_label.']__', $lang_content, $return);
				}
			}

			// compile template tags
			if (!empty($this->config['template_tags'])) {
				foreach ($this->config['template_tags'] as $tag) {
					$tag_content = '';
					if (array_key_exists($tag, $template_data) && !empty($template_data[$tag])) {
						$tag_content = $template_data[$tag];
					}
					$return = str_replace('__'.$tag.'__', $tag_content, $return);
				}
			}

			return $return;
		}

		return FALSE;
	}


	/**
	 * Displays filter for offers
	 *
	 * @access public
	 * @return void
	 */
	public function show_offers_filter($categories = array(), $filter = array(), $park_id = NULL) {

		// set park id
		if (empty($park_id)) {
			$park_id = $this->park_id;
		}

		if (!$this->is_offer_detail() || $this->config['always_show_filter'] == TRUE) {

			// get all offers and count activities and projects
			$event_count = 0;
			$activities_count = 0;
			$projects_count = 0;
			$offers_count = $this->_get_offers($park_id, $categories, NULL, NULL, $filter, TRUE, TRUE, TRUE);
			if (!empty($offers_count)) {
				$event_count = $offers_count->event_count;
				$activities_count = $offers_count->activity_count;
				$projects_count = $offers_count->project_count;
			}

			// get all categories where at least one offer exists
			$offer_categories = $this->_get_offers($park_id, $categories, NULL, NULL, $filter, TRUE, TRUE, FALSE, FALSE, TRUE);
			if (mysqli_num_rows($offer_categories) > 0) {
				$categories = array();
				foreach ($offer_categories as $offer_category) {
					foreach ($offer_category as $single_category) {
						if ($single_category > 0) {
							$categories[$single_category] = $single_category;
						}
					}
				}
			}

			// flat categories
			$flat_categories = $categories;

			// categories has to be an array
			$categories = is_array($categories) ? $categories : array($categories);

			// check, if categories are not empty
			$first = reset($categories);
			if (count($categories) == 0 || (count($categories) == 1 && empty($first))) {
				$categories = FALSE;
			}

			// prepare categories for select field
			$categories = $this->_prepare_categories($categories, $filter);
			$categories = $this->_format_categories_for_select($categories);

			// check if event filter (date-from, date-to) should be displayed
			$show_event_filter = FALSE;
			if ($event_count > 0) {
				$show_event_filter = TRUE;
			}

			// check if route filter should be displayed (has enough routes, and is activated)
			$show_route_filter = FALSE;
			if (($this->config['show_route_filter'] == TRUE) && ($activities_count > 0)) {
				$show_route_filter = TRUE;
			}

			// check if project filter should be displayed (has enough projects, and is activated)
			$show_project_filter = FALSE;
			if ($projects_count > 0) {
				$show_project_filter = TRUE;
			}

			// prepare parks/users for select
			$users = array();
			if (empty($this->park_id)) {
				$users = $this->model->get_all_users($flat_categories, $filter);
			}

			// load view
			$params = array(
				'categories' => $categories,
				'selected' => $this->filter_data,
				'filter' => $this->filter,
				'users' => $users,
				'show_event_filter' => $show_event_filter,
				'show_route_filter' => $show_route_filter,
				'show_target_group_filter' => $this->config['show_target_group_filter'],
				'show_project_filter' => $show_project_filter
			);

			return $this->view->filter($params);

		}
	}


	/**
	 * Displays list of offers (optionally filtered)
	 *
	 * @access public
	 * @param array $categories (default: array())
	 * @param array $filter (default: array())
	 * @param int $park_id (default: NULL)
	 * @return string
	 */
	public function show_offers_list($categories = array(), $filter = array(), $park_id = NULL) {

		// set park id
		if (empty($park_id)) {
			$park_id = $this->park_id;
		}

		if ($this->is_offer_detail() == FALSE) {
			$this->page = 1;
			$paramname = $this->config['url_param_prefix'].'page';
			if (isset($_GET[$paramname]) && $_GET[$paramname] >= 1) {
				$this->page = $_GET[$paramname];
			}

			// get offers and total
			$offers = $this->_get_offers($park_id, $categories, $this->page, $this->config['offers_per_page'], $filter, FALSE, TRUE);
			$this->total = ceil($offers['total'] / $this->config['offers_per_page']);
			if ($this->total > $this->config['offers_per_page']) {
				$offset = ($this->page-1) * $this->config['offers_per_page'];
			}

			// show offers list
			return $this->view->list($offers);

		}

	}



	/**
	 * Displays map of offers (optionally filtered)
	 *
	 * @access public
	 * @param array $categories (default: array())
	 * @param array $filter (default: array())
	 * @param mixed $park_id (default: NULL)
	 * @return string
	 */
	public function show_offers_map($categories = array(), $filter = array(), $park_id = NULL) {

		// set park id
		if (empty($park_id)) {
			$park_id = $this->park_id;
		}

		if (!$this->is_offer_detail()) {
			$return = $this->_load_maps_api();

			// set park
			$this->_set_selected_park($park_id);

			// get offers and total
			$offers = $this->_get_offers($park_id, $categories, NULL, NULL, $filter, FALSE, FALSE, FALSE, TRUE);
			$return .= $this->view->map($offers['data']);
			return $return;
		}
	}


	/**
	 * Displays list of poi (get by id)
	 *
	 * @access public
	 * @param integer
	 * @return void
	 */
	public function show_offer_poi_list($poi = NULL) {
		$offers = array();

		if (is_array($poi) && !empty($poi)) {
			foreach ($poi as $offer_id) {
				$poi_offer = $this->model->get_offer($offer_id);
				if (!empty($poi_offer)) {
					array_push($offers, $poi_offer);
				}
			}
		}

		return $offers;
	}


	/**
	 * Show offers total
	 *
	 * @access public
	 * @return void
	 */
	public function show_total() {
		if ($this->total > 0) {
			echo $this->total.' '.(($this->total == 1) ? $this->lang->get('offer') : $this->lang->get('offers'));
		}
	}


	/**
	 * Displays pagination
	 *
	 * @access public
	 * @return void
	 */
	public function show_offers_pagination() {
		if (!$this->is_offer_detail()) {
			return $this->view->pagination($this->page, $this->total);
		}
	}


	/**
	 * Display detail of offer
	 *
	 * @access public
	 * @return void
	 */
	public function show_offer_detail() {

		if ($this->is_offer_detail()) {
			$return = $this->_load_maps_api();

			$paramname = $this->config['url_param_prefix'].'offer';
			$offer_id = intval($_GET[$paramname]);
			$offer = $this->model->get_offer($offer_id);

			$this->_set_selected_park($offer->park_id);
			$return .= $this->view->detail($offer);
			return $return;
		}
	}


	/**
	 * Display all users favorites
	 *
	 * @access public
	 * @return void
	 */
	public function show_favorites() {

		// offer detail
		if ($this->is_offer_detail()) {
			$this->show_offer_detail();
		}

		// offer list
		else {

			// get all saved favorites
			$favorites = array();
			if (is_array($this->favorites) && !empty($this->favorites)) {
				foreach ($this->favorites as $offer_id) {
					$offer = $this->model->get_offer($offer_id);
					if (!empty($offer)) {
						array_push($favorites, $offer);
					}
				}

				// prepare offers
				$offers = array(
					'data' => $favorites,
					'total' => count($favorites),
				);
			}

			// show favorites list
			if (isset($offers['total']) && ($offers['total'] > 0)) {
				$this->view->list($offers, FALSE,  FALSE,  NULL, '<a href="'.$this->config['favorites_script_path'].'/favorite.php?action=clean" id="clean_favorites" class="reset_link">'.$this->lang->get('favorites_remove_all').'</a>');
			}

			// no favorites available
			else {
				echo '<p class="no_favorites">'.$this->lang->get('favorites_empty').'</p>';
			}

		}

	}


	/**
	 * Toggle favorite state
	 * Add or remove favorite from list
	 *
	 * @access public
	 * @param mixed $offer_id
	 * @return void
	 */
	public function toggle_favorite($offer_id) {
		if (($offer_id > 0) && ($this->config['use_sessions'] == TRUE)) {

			// remove offer from favorites
			if (in_array($offer_id, $this->favorites)) {
				unset($this->favorites[$offer_id]);
				$return = FALSE;
			}

			// add new favorite
			else {
				$this->favorites[$offer_id] = $offer_id;
				$return = TRUE;
			}

			// save session
			$_SESSION[$this->favorites_cookie_name] = $this->favorites;

			// save cookie
			setcookie($this->favorites_cookie_name, serialize($this->favorites), time()+(60*60*24*30), '/');

			return $return;
		}

		return FALSE;
	}


	/**
	 * Empty favorites
	 *
	 * @access public
	 * @param mixed $offer_id
	 * @return void
	 */
	public function clean_favorites() {
		// save session
		$_SESSION[$this->favorites_cookie_name] = array();

		// save cookie
		setcookie($this->favorites_cookie_name, '', time(), '/');
	}


	/**
	 * Returns if detail page should be displayed
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_offer_detail() {
		$paramname = $this->config['url_param_prefix'].'offer';

		if (isset($_GET[$paramname])) {
			$offer_id = intval($_GET[$paramname]);
			return $this->model->offer_exists($offer_id);
		}

		return FALSE;
	}


	/**
	 * Returns if filter is active
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_filter_activated() {
		return $this->filter;
	}


	/**
	 * Returns filter data
	 *
	 * @access public
	 * @return boolean
	 */
	public function get_filter_data() {
		return $this->filter_data;
	}


	/**
	 * Get list of offers
	 *
	 * @access public
	 * @param mixed $park_id (default: NULL)
	 * @param array $categories (default: array())
	 * @param mixed $page (default: NULL)
	 * @param mixed $limit (default: NULL)
	 * @param array $filter (default: array())
	 * @param mixed $ignore_filter (default: FALSE)
	 * @param mixed $return_minimal (default: FALSE)
	 * @param mixed $only_count_categories (default: FALSE)
	 * @param mixed $map_mode (default: FALSE)
	 * @return void
	 */
	public function get_offers_list($park_id = NULL, $categories = array(), $page = NULL, $limit = NULL, $filter = array(), $ignore_filter = FALSE, $return_minimal = FALSE, $only_count_categories = FALSE, $map_mode = FALSE) {
		return $this->_get_offers($park_id, $categories, $page, $limit, $filter, $ignore_filter, $return_minimal, $only_count_categories, $map_mode);
	}


	/**
	 * Get offer details
	 *
	 * @access public
	 * @param mixed $offer_id
	 * @return void
	 */
	public function get_offer_detail($offer_id) {
		return $this->model->get_offer($offer_id);
	}


	/**
	 * Get list of categories
	 *
	 * @access public
	 * @return mixed
	 */
	public function get_categories_list() {
		return $this->model->get_all_categories();
	}


	/**
	 * Get list of categories preformatted for select inputs
	 *
	 * @access public
	 * @return mixed
	 */
	public function get_categories_list_for_select() {
		$categories = $this->model->get_category_tree();
		return $categories;
	}


	/**
	 * Setup process
	 *
	 * @access private
	 * @return void
	 */
	private function _setup() {
		$this->_security_checks();

		$q_api = $this->db->get('api');

		if ($q_api) {
			if (mysqli_num_rows($q_api) > 0) {
				$this->api = mysqli_fetch_object($q_api);
			}
			else {
				$this->api->initialized = false;
				$this->api->version = API_VERSION;

				$this->db->insert('api', (array)$this->api);
			}

			if (version_compare(API_VERSION, $this->api->version)) {
				$logger = new ParksLog($this);
				$logger->info('The current API version is out of date. Please update database.');
			}

			if (!$this->api->initialized) {

				//Initalize API
				$xml = $this->config['xml_export_offer_url'].$this->hash;
				$xml_map_layer =  $this->config['xml_export_map_layer_url'].$this->hash;

				// Import data from XML into database
				$importer = new ParksImport($this);
				$importer->import($xml);
				$importer->import_map_layers($xml_map_layers);

				$this->api->initialized = true;
				$this->db->update('api', array('initialized' => 1));
			}
		}
		else {
			die("API could not be initialized.");
		}
	}


	/**
	 * Set current selected park
	 *
	 * @access public
	 * @param integer $park_id
	 * @return void
	 */
	public function _set_selected_park($park_id = NULL) {

		// init park id
		if (empty($park_id)) {
			$park_id = $this->park_id;
		}

		if ($this->config['use_sessions'] == TRUE) {
			if (!empty($park_id) && ($park_id > 0)) {
				$_SESSION[$this->session_name]['selectedPark'] = $this->config['parks'][$park_id];
			}
			else {
				unset($_SESSION[$this->session_name]['selectedPark']);
			}
		}

	}


	/**
	 * Validate hash
	 *
	 * @access public
	 * @return void
	 */
	public function _validate_hash() {
		$validate = @file_get_contents($this->config['xml_export_url'].'validate/'.$this->hash);

		if ($validate == "Valid") {
			return TRUE;
		}
		else if (!empty($this->hash) && strlen($this->hash) >= 32) {
			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Init filter
	 *
	 * @access public
	 * @return void
	 */
	public function _init_filter() {

		$paramname = $this->config['form_prefix'].'filter';
		$post_data = isset($_POST[$paramname]) ? $_POST[$paramname] : NULL;

		$fields = array('categories', 'date_from', 'date_to', 'search', 'park_id', 'time_required', 'level_technics', 'level_condition', 'route_length_min', 'route_length_max', 'project_status', 'target_groups');

		foreach ($fields as $field) {

			if (!empty($post_data)) {
				$this->filter = TRUE;
				$this->filter_data[$field] = isset($post_data[$field]) ? $post_data[$field] : NULL;
			}
			elseif ($this->config['use_sessions'] && (isset($_SESSION[$this->session_name]['filter'][$field]) && !empty($_SESSION[$this->session_name]['filter'][$field]))) {
				$this->filter = TRUE;
				$this->filter_data[$field] = $_SESSION[$this->session_name]['filter'][$field];
			}
		}

		// set filter in session
		if ($this->config['use_sessions']) {
			$_SESSION[$this->session_name]['filter'] = $this->filter_data;
		}

		// reload, if post data was sent
		if (!empty($post_data)) {
			header('Location: '.$this->view->script_url);
			exit;
		}

	}


	/**
	 * Reset filter
	 *
	 * @access public
	 * @return void
	 */
	public function _reset_filter() {

		$this->filter_data = array();
		if ($this->config['use_sessions']) {
			unset($_SESSION[$this->session_name]['filter']);
		}

	}


	/**
	 * Get offers
	 *
	 * @access public
	 * @param mixed $categories
	 * @return void
	 */
	public function get_offers($park_id = NULL, $categories = array()) {

		// set park id
		if (empty($park_id)) {
			$park_id = $this->park_id;
		}

		return $this->_get_offers($park_id, $categories);
	}


	/**
	 * Get offers
	 *
	 * @access public
	 * @param array $categories (default: array())
	 * @param mixed $page (default: NULL)
	 * @param array $additional_filter (default: array())
	 * @param mixed $ignore_filter (default: FALSE)
	 * @return void
	 */
	public function _get_offers($park_id = NULL, $categories = array(), $page = NULL, $limit = NULL, $additional_filter = array(), $ignore_filter = FALSE, $return_minimal = FALSE, $only_count_categories = FALSE, $map_mode = FALSE, $return_only_categories = FALSE) {

		// set park id
		if (empty($park_id)) {
			$park_id = $this->park_id;
		}

		// init filter
		$filter = array();
		if ($ignore_filter == FALSE) {
			foreach ($this->filter_data as $field => $value) {
				if (!empty($value)) {
					$fieldname = substr($field, strlen($this->config['form_prefix']), strlen($field));
					$filter[$fieldname] = $value;
				}
			}
		}

		// overwrite filter fields
		if (!empty($categories) && !isset($filter['categories'])) {
			$filter['categories'] = $categories;
		}

		// offer settings
		if (!empty($additional_filter['offer_settings'])) {
			$filter['offer_settings'] = $additional_filter['offer_settings'];
		}

		// target groups
		if (!empty($additional_filter['target_groups'])) {
			$filter['target_groups'] = $additional_filter['target_groups'];
		}

		// search words
		if (!empty($additional_filter['search'])) {
			$filter['search'] = $additional_filter['search'];
		}

		// order_by
		if (!empty($additional_filter['order_by'])) {
			$filter['order_by'] = $additional_filter['order_by'];
		}

		// textOfferSearch
		if (!empty($additional_filter['textOfferSearch'])) {
			$filter['search'] .= $additional_filter['textOfferSearch'];
		}

		// offers_barrier_free
		if (!empty($additional_filter['offers_barrier_free'])) {
			$filter['barrier_free'] = $additional_filter['offers_barrier_free'];
		}

		// offers_learning_opportunity
		if (!empty($additional_filter['offers_learning_opportunity'])) {
			$filter['learning_opportunity'] = $additional_filter['offers_learning_opportunity'];
		}

		// offers_child_friendly
		if (!empty($additional_filter['offers_child_friendly'])) {
			$filter['child_friendly'] = $additional_filter['offers_child_friendly'];
		}

		// offers_park_day
		if (!empty($additional_filter['offers_park_day'])) {
			$filter['park_day'] = $additional_filter['offers_park_day'];
		}

		// offers_enjoy_week
		if (!empty($additional_filter['offers_enjoy_week'])) {
			$filter['enjoy_week'] = $additional_filter['offers_enjoy_week'];
		}

		// offer_filter_hints
		if (isset($additional_filter['offers_filter_hints'])) {
			$filter['is_hint'] = $additional_filter['offers_filter_hints'];
		}

		// keywords
		if (isset($additional_filter['keywords'])) {
			$filter['keywords'] = $additional_filter['keywords'];
		}

		// contact_is_park_partner
		if (isset($additional_filter['contact_is_park_partner'])) {
			$filter['contact_is_park_partner'] = $additional_filter['contact_is_park_partner'];
		}

		// offers
		if (isset($additional_filter['offers'])) {
			$offer_filter = array();
			foreach ($this->filter_data as $field => $value) {
				if (!empty($value)) {
					$fieldname = substr($field, strlen($this->config['form_prefix']), strlen($field));
					$offer_filter[$fieldname] = $value;
				}
			}
			$filter['offers'] = $offer_filter['offers'];
		}

		// park id
		if (!empty($this->park_id)) {
			$filter['park_id'] = $this->park_id;
		}

		// get offset and limit
		$offset = 0;
		if (!empty($page) && is_numeric($page)) {
			$offset = ($page - 1) * $this->config['offers_per_page'];
		}

		return $this->model->filter_offers($filter, $limit, $offset, $return_minimal, $only_count_categories, $map_mode, $return_only_categories);
	}


	/**
	 * Load map api
	 *
	 * @access public
	 * @return void
	 */
	public function _load_maps_api() {
		$output = '
			<script type="text/javascript">var dojoConfig = { locale: "'.$this->lang_id.'", parseOnLoad: true, useDeferredInstrumentation: false };</script>
			<link rel="stylesheet" type="text/css" media="screen,projection" href="https://js.arcgis.com/3.22/esri/css/esri.css" />
			<link rel="stylesheet" type="text/css" href="'.$this->config['base_url'].'swissmap/css-min/swissmap.css" />
			<script type="text/javascript" src="https://js.arcgis.com/3.22/"></script>
			<script type="text/javascript" src="'.$this->config['base_url'].'swissmap/js-min/swissmap.js"></script>
			<script type="text/javascript" src="'.$this->config['base_url'].'swissmap/js-min/maps.arcgis.js"></script>
		';
		// show output
		if ($this->return_output === TRUE) {
			return $output;
		}
		else {
			echo $output;
		}
	}


	/**
	 * Format categories for selcect-field
	 *
	 * @access public
	 * @param mixed $categories
	 * @param mixed $category_links
	 * @param mixed $index (default: 0)
	 * @param int $level (default: 0)
	 * @return void
	 */
	public function _format_categories_for_select($categories, $index = 0, $level = 0) {
		$return = array();

		// get main category on top
		$main_category = array();
		if (isset($categories[0]) && is_array($categories[0])) {
			$main_category = array_keys($categories[0]);
			$main_category = reset($main_category);
		}

		// special cases
		if (($level == 0) && ($index == 0) && ($main_category == CATEGORY_PRODUCT) && isset($categories[CATEGORY_GASTRONOMY_AND_ACCOMMODATION]) && (count($categories[0]) == 1)) {
			$index = CATEGORY_GASTRONOMY_AND_ACCOMMODATION;
		}

		if (isset($categories[$index]) && !empty($categories[$index])) {
			foreach ($categories[$index] as $id => $category) {
				if (
						(($level != 0) || in_array($id, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT)))
						&&
						(($level != 1) || !in_array($index, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT)))
						&&
						(($level != 2) || !in_array($index, array(CATEGORY_GASTRONOMY_AND_ACCOMMODATION)))
				) {
					$return[$id] = $category;
				}

				if (isset($categories[$id])) {
					$childs = $this->_format_categories_for_select($categories, $id, $level+1);
					if (!empty($childs)) {
						if (
							(($level == 0) && !in_array($id, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT)))
							||
							(($level == 1) && in_array($index, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT)))
							||
							(($level == 2) && in_array($index, array(CATEGORY_GASTRONOMY_AND_ACCOMMODATION)))
						) {
							$return[$category] = $childs;
						}
						else {
							$return += $childs;
						}
					}
				}
			}
		}

		return $return;
	}


	/**
	 * Prepare categories
	 *
	 * @access public
	 * @param mixed $categories (default: FALSE)
	 * @param mixed $flatten (default: FALSE)
	 * @param array $filter (default: array())
	 * @return void
	 */
	public function _prepare_categories($categories = FALSE, $filter = array()) {
		$return = array();
		$parents = array();

		// get all categories
		$all_categories = $this->model->get_all_categories($filter);

		// get all parents
		if (is_array($categories) && !empty($categories)) {
			foreach ($categories as $category_id) {
				if (($category_id > 0) && isset($all_categories[$category_id]) && !empty($all_categories[$category_id])) {
					$parents = array_merge($parents, $all_categories[$category_id]->parents);
				}
			}
		}

		// return structured categories
		if (is_array($all_categories) && !empty($all_categories)) {
			foreach ($all_categories as $category_id => $category) {
				// set parent id
				$parent_id = $category->parent_id ? $category->parent_id : 0;

				// add category
				if (($categories == FALSE) || (in_array($category_id, $categories) || in_array($category_id, $parents))) {
					$return[$parent_id][$category_id] = $category->body;
				}
			}
		}

		// return flat (non structured) categories
		else {
			$return = $categories;
		}

		return $return;
	}


	/**
	 * Security checks
	 *
	 * @access public
	 * @return void
	 */
	public function _security_checks() {
		// add slashes (only if magic_quotes_gpc is disabled in php.ini)
		if (!get_magic_quotes_gpc()) {
			array_walk_recursive($_GET, array($this, '_add_slashes'));
		}

		if (is_array($_GET)) {
			foreach($_GET as $key => $value) {
				// sql injection protection
				$tmp = str_replace(array("*", "'", '"', ";", "="), "", $value);
				// cross site scripting protection
				$tmp = str_replace(array("<", ">"), array("&lt;", "&gt;"), $tmp);
				$_GET[$key] = $tmp;
			}
		}
	}


	/**
	 * Add slashes
	 *
	 * @access public
	 * @param mixed &$item
	 * @param mixed $key
	 * @return void
	 */
	public function _add_slashes(&$item, $key) {
		$item = (!is_array($item) ? addslashes($item) : $item);
	}



	/**
	 * Get API configuration
	 *
	 * @access public
	 * @return void
	 */
	public function _get_config() {

		// load config file
		if (file_exists($config_path = realpath(dirname(__FILE__)).'/../config.php')) {
			require($config_path);
		}
		else {
			echo 'The configuration file does not exist.';
			exit();
		}

		// check config data
		if (!isset($config) || !is_array($config)) {
			echo 'Your config file does not appear to be formatted correctly.';
			exit();
		}

		return $config;

	}


	/**
	 * Load system config and merge with user config
	 *
	 * @access private
	 * @return void
	 */
	private function _load_system_config() {

		// base url
		$this->config['base_url'] = "https://angebote.paerke.ch/";

		// xml import urls
		$this->config['xml_export_url'] = $this->config['base_url']."export/";
		$this->config['xml_export_offer_url'] = $this->config['base_url']."export/xml/";
		$this->config['xml_export_map_layer_url'] = $this->config['base_url']."export/xml/map_layers/";
		$this->config['xml_export_active_offers'] = $this->config['base_url']."export/xml/active_offers/";

		// sbb link
		$this->config['min_chars_sbb_link'] = 3;

		// project status
		$this->config['project_status_de'] = array(
			1 => 'Geplant',
			2 => 'Laufend',
			3 => 'Abgeschlossen',
		);
		$this->config['project_status_fr'] = array(
			1 => 'Planifié',
			2 => 'Actuel',
			3 => 'Terminé',
		);
		$this->config['project_status_it'] = array(
			1 => 'Pianificato,',
			2 => 'In corso',
			3 => 'Concluso',
		);
		$this->config['project_status_en'] = array(
			1 => 'Planned',
			2 => 'Ongoing',
			3 => 'Finished',
		);

		// parks
		$this->config['parks'] = array(
			2  => 'lpb',
			3  => 'snp',
			4  => 'jpa',
			5  => 'prc',
			6  => 'die',
			8  => 'frg',
			9  => 'bvm',
			10 => 'ela',
			11 => 'ube',
			12 => 'npt',
			13 => 'gpe',
			14 => 'wpz',
			15 => 'npb',
			16 => 'prd',
			17 => 'adu',
			18 => 'pnl',
			19 => 'pjv',
			20 => 'npf',
			27 => 'npn',
			28 => 'nps',
			33 => 'sar',
		);

		// route times
		$this->config['route_times'] = array(
			$this->lang->get('offer_time_required_2h'),
			$this->lang->get('offer_time_required_2_4h'),
			$this->lang->get('offer_time_required_4_6h'),
			$this->lang->get('offer_time_required_6h')
		);

		// route levels
		$this->config['route_levels'] = array(
			1 => $this->lang->get('offer_easy'),
			2 => $this->lang->get('offer_average'),
			3 => $this->lang->get('offer_difficult')
		);

		// hidden categories on overview and detail page
		$this->config['hidden_categories'] = array(
			CATEGORY_GASTRONOMY_AND_ACCOMMODATION,
			CATEGORY_REGIONAL_PRODUCT,
			CATEGORY_GASTRONOMY,
			CATEGORY_ACCOMMODATION,
			CATEGORY_SIGHT,
			CATEGORY_SUMMER_ACTIVITIES,
			CATEGORY_WINTER_ACTIVITIES,
			CATEGORY_INFORMATION,
			CATEGORY_INFRASTRUCTURE,
		);

		// template tags
		$this->config['template_tags'] = array(
			'OFFER_TITLE',
			'OFFER_SHORT_INFO',
			'OFFER_CATEGORIES',
			'OFFER_IMAGES',
			'OFFER_DESCRIPTION',
			'OFFER_ADDITIONAL_INFO',
			'OFFER_DATES',
			'OFFER_DOCUMENTS',
			'OFFER_EVENT_DETAIL',
			'OFFER_PRODUCT_DETAIL',
			'OFFER_BOOKING_DETAIL',
			'OFFER_ACTIVITY_DETAIL',
			'OFFER_RESEARCH_DETAIL',
			'OFFER_LINKS',
			'OFFER_TARGET_GROUPS',
			'OFFER_SUPPLIERS',
		 	'OFFER_INSTITUTION',
		 	'OFFER_CONTACT',
		 	'OFFER_POI_LIST',
		 	'OFFER_EVENT_LOCATION',
		 	'OFFER_EVENT_LOCATION_DETAILS',
		 	'OFFER_EVENT_TRANSPORT',
		 	'OFFER_EVENT_DATE_DETAILS',
		 	'OFFER_EVENT_PRICE',
		 	'OFFER_PRODUCT_OPENING_HOURS',
		 	'OFFER_PRODUCT_PUBLIC_TRANSPORT',
		 	'OFFER_PRODUCT_PRICE',
		 	'OFFER_PRODUCT_INFRASTRUCTURE',
		 	'OFFER_BOOKING_GROUPS',
		 	'OFFER_BOOKING_TRANSPORT',
		 	'OFFER_BOOKING_BENEFITS',
		 	'OFFER_BOOKING_REQUIREMENTS',
		 	'OFFER_BOOKING_PRICE',
		 	'OFFER_BOOKING_ACCOMMODATIONS',
		 	'OFFER_ACTIVITY_ROUTE',
		 	'OFFER_ACTIVITY_ARRIVAL',
		 	'OFFER_ACTIVITY_PRICE',
		 	'OFFER_ACTIVITY_CATERING',
		 	'OFFER_ACTIVITY_MATERIAL_RENT',
		 	'OFFER_ACTIVITY_SAFETY_INSTRUCTIONS',
		 	'OFFER_ACTIVITY_SIGNALIZATION',
		 	'OFFER_ACTIVITY_DATES',
		 	'OFFER_ACTIVITY_INFRASTRUCTURE',
		 	'OFFER_PROJECT_DURATION',
		 	'OFFER_PROJECT_STATUS',
		 	'OFFER_SUBSCRIPTION',
		 	'OFFER_PROJECT_DETAIL',
		 	'OFFER_MAP',
		 	'OFFER_PRINT_LINK',
		 	'OFFER_BACK_LINK',
		 	'FILTER_TEXT_SEARCH',
		 	'FILTER_CATEGORIES',
		 	'FILTER_DATES',
		 	'FILTER_TARGET_GROUPS',
		 	'FILTER_PARKS',
		 	'FILTER_PROJECT',
		 	'FILTER_ROUTE_LENGTH',
		 	'FILTER_ROUTE_TIME',
		 	'FILTER_ROUTE_CONDITION',
		 	'FILTER_SHOW_LINK',
		 	'FILTER_FORM_START',
		 	'FILTER_FORM_STOP',
		 	'FILTER_RESET_BUTTON',
		 	'FILTER_SUBMIT_BUTTON'
		 );

		 // template conditions
		 $this->config['template_conditions'] = array(
		 	'OFFER_EVENT',
		 	'OFFER_PRODUCT',
		 	'OFFER_BOOKING',
		 	'OFFER_ACTIVITY',
		 	'OFFER_PROJECT',
		 	'OFFER_RESEARCH'
		 );

	}


}