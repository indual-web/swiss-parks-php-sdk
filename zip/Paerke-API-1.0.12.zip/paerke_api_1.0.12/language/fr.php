<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| French language file
|
*/

$lang = array();


$lang['general_from_2'] = "Par";
$lang['general_to'] = "jusqu'&agrave;";
$lang['general_all'] = "Tout";
$lang['general_none'] = "Aucune";


/**
 * Offer language strings
 */
$lang['offer_filter'] = 'Filtre';
$lang['offer_date_from'] = 'Date de début';
$lang['offer_date_to'] = 'Date de fin';
$lang['offer_search'] = 'Recherche';
$lang['offer_reset'] = 'Supprimer';
$lang['offer_list'] = 'Liste des offres';
$lang['offer_not_found'] = 'Aucune offre n\'a &eacute;t&eacute; trouv&eacute;e.';
$lang['offer_map'] = 'Carte';
$lang['offer_description'] = 'Description';
$lang['offer_detail'] = 'D&eacute;tails';
$lang['offer_poi'] = 'Points sur l&lsquo;itin&eacute;raire';

$lang['offer_category'] = "Cat&eacute;gorie";
$lang['offer_maincategory'] = "Cat&eacute;gorie principale";
$lang['offer_subcategory'] = "Sous-cat&eacute;gorie";
$lang['offer_subcategories'] = "Sous-cat&eacute;gories";
$lang['offer_select_category'] = "Toutes les offres";
$lang['offer_selected_category'] = '%s categories choisie';
$lang['offer_select_park'] = "S&eacute;lectionner un parc";
$lang['offer_select_language'] = 'S&eacute;lectionner une langue';
$lang['offer_default_data'] = "Donn&eacute;es d'ensemble";
$lang['offer_details'] = "D&eacute;tails";
$lang['offer_files'] = "Donn&eacute;es";
$lang['offer_addresses'] = "Adresses";
$lang['offer_attributes'] = "Propri&eacute;t&eacute;s";
$lang['offer_target_group'] = "Groupes cibles";
$lang['offer_telephone'] = "T&eacute;l&eacute;phone";
$lang['offer_barrier_free'] = "Accessibilit&eacute;";
$lang['offer_learning_opportunity'] = "Offre de formation";
$lang['offer_child_friendly'] = "Adapt&eacute; aux enfants";
$lang['offer_park_day'] = "Journ&eacute;e des parcs";
$lang['offer_enjoy_week'] = "Semaine de la jouissance";
$lang['offer_public_transport_stop'] = "Trajet TP (arr&ecirc;t)";
$lang['offer_contact'] = "Informations sur les contacts";
$lang['offer_upload_image'] = "Uploader une image";
$lang['offer_links'] = "Liens utiles";
$lang['offer_upload_pdf'] = "Uploader en PDF";
$lang['offer_available_for'] = "Offre libre pour";
$lang['offer_paerke_ch'] = "paerke.ch";
$lang['offer_own_park'] = "Propre parc";
$lang['offer_switzerland_tourism'] = "Suisse Tourisme";
$lang['offer_valid'] = "Validit&eacute; des donn&eacute;es entr&eacute;es";
$lang['offer_valid_from'] = "Valide depuis";
$lang['offer_valid_to'] = "Valide jusqu'au";
$lang['offer_signs'] = "Signe";
$lang['offer_images'] = "Images";
$lang['offer_documents'] = "Documents (PDF, Excel, Word, etc.)";
$lang['offer_documents_public'] = 'Documents';
$lang['offer_main_image'] = "Image principale";
$lang['offer_image'] = "Image en";
$lang['offer_delete_success'] = "L'offre a &eacute;t&eacute; supprim&eacute;e correctement";
$lang['offer_delete_error'] = "Erreur pendant la suppression de l'offre";
$lang['offer_category_update_success'] = "La cat&eacute;gorie a &eacute;t&eacute; actualis&eacute;e avec succ&egrave;s";
$lang['offer_delete_image_confirm'] = "Etes-vous s&ucirc;r de vouloir enlever cette image ? L'image sera d&eacute;finitivement supprim&eacute;e.";
$lang['offer_document'] = "Document en";
$lang['offer_contact_change'] = "Change de contact";
$lang['offer_document_title'] = "Nom du document";
$lang['offer_delete_document_confirm'] = "Etes-vous s&ucirc;r de vouloir supprimer ce document? Le document sera d&eacute;finitivement supprim&eacute;";
$lang['offer_link_url'] = "URL";
$lang['offer_link_title'] = "D&eacute;signation";
$lang['offer_link_add'] = "Ajouter un lien";
$lang['offer_link_remove_confirm'] = "Etes-vous s&ucirc;r de vouloir supprimer ce lien?";
$lang['offer_park'] = "Parc/Organisation";
$lang['offer_additional_info'] = "Informations suppl&eacute;mentaires";
$lang['offer_valid_infinite'] = "Validit&eacute; ind&eacute;termin&eacute;e";
$lang['offer_parks_all'] = "Tous les parcs";
$lang['offer_categories_all'] = "Toutes les cat&eacute;gories";
$lang['offer_categories'] = "Cat&eacute;gories";
$lang['offer_status'] = "Statut";
$lang['offer_status_inactive'] = "Inactif";
$lang['offer_status_active'] = "Actif";
$lang['offer_coordinates'] = "Coordonn&eacute;es";
$lang['offer_images_help'] = "Vous pouvez t&eacute;l&eacute;charger ici des images en format JPG, GIF ou PNG. Chaque image doit avoir une r&eacute;solution minimale de 200x100 Pixel. Pri&egrave;re de veiller au droits d'auteur de l'image originale.";
$lang['offer_maps_help'] = "Pour choisir un point sur la carte, vous pouvez reporter celui-ci avec la souris ou double-cliquer sur le lieu souhait&eacute; sur la carte. Vous pouvez aussi faire une recherche d'un lieu.";
$lang['offer_activity_maps_help'] = "Sie k&ouml;nnen die Route beliebig anpassen, indem Sie die Wegpunkte (grau) mit der Maus ziehen. Mit den weissen, kleineren Markierungen k&ouml;nnen Sie durch Ziehen neue Wegpunkte hinzuf&uuml;gen. Bestehende Wegpunkte k&ouml;nnen &uuml;ber ein Rechtsklick entfernt werden.";
$lang['offer_will_not_be_published_on_myswitzerland'] = "Ne peut pas &ecirc;tre publi&eacute; par Suisse Tourisme";
$lang['offer_all_season'] = "Tout au long de l'ann&eacute;e";
$lang['offer_maps_search'] = "Recherche";
$lang['offer_maps_search_go'] = "Trouver";
$lang['offer_maps_choose'] = "Choisir une carte";
$lang['offer_languages'] = 'Langues';
$lang['offer_filter'] = 'Filtre des offres';
$lang['offer_no_results'] = 'Il n\'y avait pas d\'offres trouv&eacute;s correspondant &agrave; vos crit&egrave;res de recherche.';


/*
| language related fields
*/
$lang['offer_title_description'] = "Titre &amp; Description";
$lang['offer_title'] = "Titre";
$lang['offer_description'] = "Description";
$lang['offer_short_description'] = "Description courte";
$lang['offer_medium_description'] = "Description moyenne";
$lang['offer_long_description'] = "Decription longue";
$lang['offer_price'] = "Info sur les prix";
$lang['offer_date_details'] = "D&eacute;tails sur le rendez-vous";


/*
| Default mask fields
*/
$lang['offer_parkname'] = "Nom du parc";
$lang['offer_park_event'] = "Organisation du parc";
$lang['offer_park_partner'] = "Entreprise partenaire du parc";
$lang['offer_park_partner_event'] = "Organisation du partenaire du parc";
$lang['offer_park_partner_booking'] = 'Parkpartnerbetrieb';
$lang['offer_kind_of'] = "Type d'organisation";
$lang['offer_institution'] = "Institution/lieu";
$lang['offer_street'] = "Rue";
$lang['offer_place'] = "Lieu";
$lang['offer_location'] = "Situation";
$lang['offer_date'] = "Date";
$lang['offer_dates'] = "Dates";
$lang['offer_from'] = "De";
$lang['offer_to'] = "&agrave;";
$lang['offer_at'] = "Vers";
$lang['offer_oclock'] = "Heure";


/*
| Insert mask 1
*/
$lang['offer_title_event'] = "Organisation des donn&eacute;es";
$lang['offer_add_date'] = "Ajouter un nouveau rendez-vous";
$lang['offer_event_location'] = "Lieu d'organisation";
$lang['offer_event_organiser'] = "Organisateur";
$lang['offer_subscription'] = "Inscription";
$lang['offer_subscription_mandatory'] = "Inscription n&eacute;cessaire";
$lang['offer_subscription_contact'] = "Inscription par";
$lang['offer_subscription_link'] = "Lien pour l'inscription";
$lang['offer_subscription_recommended'] = 'Recommend&eacute;';
$lang['offer_subscription_details'] = "Informations d\'inscription supplémentaires";
$lang['offer_local'] = "Local";
$lang['offer_regional'] = "R&eacute;gional";
$lang['offer_national'] = "National";
$lang['offer_international'] = "International";
$lang['offer_misc'] = "Autre";
$lang['offer_delete_date_confirm'] = "Etes-vous s&ucirc;r de vouloir effacer ces donn&eacute;es ?";
$lang['offer_location_details'] = "Situation détaillée";



/*
| Insert mask 2
*/
$lang['offer_product_offerer'] = "Fournisseur/Installation";
$lang['offer_opening_hours'] = "heures d'ouverture";
$lang['offer_supplier'] = "Fournisseur";
$lang['offer_availability'] = "Produit disponible de/&agrave;";
$lang['offer_available_from'] = "Disponible de";
$lang['offer_available_to'] = "Disponible jusqu'&agrave;";
$lang['offer_supplier_add'] = "Ajouter un fournisseur";
$lang['offer_contact_remove_confirm'] = "Etes-vous s&ucirc;r de vouloir effacer cette attribution de contact ?";
$lang['offer_infrastructure'] = "Infrastructure";
$lang['offer_number_of_rooms'] = "Nombre de chambres";
$lang['offer_rooms'] = '%s chambres';
$lang['offer_conference_room'] = "Salle de s&eacute;minaire";
$lang['offer_playground'] = "Place de jeu";
$lang['offer_picnic_place'] = "Place de pique-nique";
$lang['offer_fireplace'] = "Foyer";
$lang['offer_washroom'] = "WC";
$lang['offer_other_infrastructure'] = "Autres infrastructure";


/*
| Insert mask 3
*/
$lang['offer_organizer'] = "Organisateur";
$lang['offer_execution_times'] = "Donn&eacute;es/p&eacute;riode de mise en oeuvre";
$lang['offer_accommodation'] = "Possibilit&eacute;s de nuit&eacute;es";
$lang['offer_accommodation_add'] = "Ajouter une possibilit&eacute; de nuit&eacute;e";
$lang['offer_number_of_people_groups'] = "Nombre de personnes par offre de groupe";
$lang['offer_number_of_people_individual'] = "Nombre de personnes pour des forfaits individuels";
$lang['offer_min_subscriber'] = "Nombre de participants min.";
$lang['offer_max_subscriber'] = "Nombre de participants max.";
$lang['offer_benefits'] = "Prestations";
$lang['offer_requirements'] = "Conditions";


/*
| Insert mask 4 (Activity)
*/
$lang['offer_safety_instructions'] = "Prescriptions de s&eacute;curit&eacute;";
$lang['offer_signalization'] = "Signalisation";
$lang['offer_material_rent'] = "Location de mat&eacute;riel";
$lang['offer_catering_informations'] = "Possibilit&eacute;s de restauration";
$lang['offer_saison'] = "Saison";
$lang['offer_start_place'] = "Lieu de d&eacute;part";
$lang['offer_goal_place'] = "Lieu d'arriv&eacute;e";
$lang['offer_altitude'] = "Altitude";
$lang['offer_route_info'] = "Informations sur le parcours";
$lang['offer_route_length'] = "Longueur du parcours";
$lang['offer_untarred_route_length'] = 'Total de route pas goudronnée';
$lang['offer_altitude_differential'] = "D&eacute;nivel&eacute;";
$lang['offer_altitude_ascent'] = "D&eacute;nivel&eacute; positif";
$lang['offer_altitude_descent'] = "D&eacute;nivel&eacute; n&eacute;gatif";
$lang['offer_altitude_meter'] = "m";
$lang['offer_route_length_km'] = "km";
$lang['offer_time_required'] = "Estimation de temps";
$lang['offer_level_technics'] = "Degr&eacute; de difficult&eacute; - technique";
$lang['offer_level_condition'] = "Degr&eacute; de difficult&eacute; - endurance";
$lang['offer_time_required_2h'] = "&lt;2h";
$lang['offer_time_required_2_4h'] = "2-4h";
$lang['offer_time_required_4h'] = "&gt;4h";
$lang['offer_easy'] = "Facile";
$lang['offer_average'] = "Moyen";
$lang['offer_difficult'] = "Difficile";
$lang['offer_route'] = "Parcours";
$lang['offer_activity_location'] = 'Lieu / Lieu de d&eacute;part';


$lang['pagination_next'] = 'Plus &rsaquo;';
$lang['pagination_prev'] = '&lsaquo; En retour';
$lang['pagination_first'] = '&laquo; Premi&egrave;re page';
$lang['pagination_last'] = 'Derni&egrave;re page &raquo;';
$lang['back_to_overview'] = 'Retour au sommaire';
$lang['back_to_route'] = 'Retour &agrave; la route';


/*
| Swissmap
*/
$lang['swissmap_basemap'] = 'Fond de carte';
$lang['swissmap_swissimage'] = 'Photo aérienne';
$lang['swissmap_pixelkarte'] = 'Cartes nationales';
$lang['swissmap_hybrid'] = 'Hybrid';

$lang['swissmap_zoom_in'] = 'Agrandir';
$lang['swissmap_zoom_out'] = 'R&eacute;tr&eacute;cir';
$lang['swissmap_select_all_parks'] = 'Tous les parcs';
$lang['swissmap_home'] = 'Home';
$lang['swissmap_back'] = 'Retour';
$lang['swissmap_next'] = 'Suivant';
$lang['swissmap_print'] = 'Imprimer';
$lang['swissmap_help'] = 'Aide';
$lang['swissmap_show_sidebar'] = 'Afficher la barre lat&eacute;rale';
$lang['swissmap_hide_sidebar'] = 'Masquer la barre lat&eacute;rale';
$lang['swissmap_show_legend'] = 'Afficher la l&eacute;gende';
$lang['swissmap_hide_legend'] = 'Masquer la l&eacute;gende';
$lang['swissmap_show_overview'] = 'Afficher la carte synoptique';
$lang['swissmap_hide_overview'] = 'Masquer la carte synoptique';
$lang['swissmap_close'] = 'Fermer';
$lang['swissmap_baseinfo'] = 'Informations de base';
$lang['swissmap_coordinates'] = 'Coordonn&eacute;es nationales suisses';
$lang['swissmap_tools'] = 'Outils';
$lang['swissmap_tools_none'] = "Pas d'outil";
$lang['swissmap_tools_point'] = "Point";
$lang['swissmap_tools_distance'] = "Distance";
$lang['swissmap_tools_area'] = "Area";
$lang['swissmap_tools_result'] = "Résultat de la mesure";
$lang['swissmap_tools_choose_tool'] = "Choisissez un outil pour mesurer.";
$lang['swissmap_search'] = 'Recherche lieu, canton, ...';
$lang['swissmap_home_title'] = 'Home';
$lang['swissmap_back_title'] = 'Retour';
$lang['swissmap_next_title'] = 'Suivant';
$lang['swissmap_tools_title'] = "Des outils de mesure";
$lang['swissmap_print_title'] = 'Imprimer';
$lang['swissmap_help_title'] = 'Aide';
$lang['swissmap_offers'] = 'Offres';
$lang['swissmap_all_offers'] = 'Toutes les offres';
$lang['swissmap_source_swisstopo'] = 'Source: swisstopo';
$lang['swissmap_loading'] = 'Loading...';
$lang['swissmap_cancel'] = 'Annuler';