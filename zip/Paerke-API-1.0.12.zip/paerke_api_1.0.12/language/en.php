<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| German language file
|
*/

$lang = array();


$lang['general_from_2'] = "From";
$lang['general_to'] = "to";
$lang['general_all'] = "All";
$lang['general_none'] = "None";


/**
 * Offer language strings
 */
$lang['offer_filter'] = 'Offer-filter';
$lang['offer_category'] = 'Category';
$lang['offer_select_category'] = 'All Categories';
$lang['offer_date_from'] = 'Date from';
$lang['offer_date_to'] = 'Date to';
$lang['offer_search'] = 'Search';
$lang['offer_reset'] = 'Reset';
$lang['offer_list'] = 'List of offers';
$lang['offer_not_found'] = 'No offers found.';
$lang['offer_map'] = 'Map';
$lang['offer_description'] = 'Description';
$lang['offer_detail'] = 'Details';
$lang['offer_poi'] = 'Waypoints';

$lang['offer_category'] = 'Category';
$lang['offer_maincategory'] = 'Maincategory';
$lang['offer_subcategory'] = 'Subcategory';
$lang['offer_subcategories'] = 'Subcategories';
$lang['offer_select_category'] = 'All offers';
$lang['offer_selected_category'] = '%s categories selected';
$lang['offer_select_park'] = 'Select park';
$lang['offer_select_language'] = 'Select language';
$lang['offer_default_data'] = 'General data';
$lang['offer_details'] = 'Details';
$lang['offer_files'] = 'Files';
$lang['offer_addresses'] = 'Addresses';
$lang['offer_attributes'] = 'Attributes';
$lang['offer_target_group'] = 'Target groups';
$lang['offer_telephone'] = 'Telephone';
$lang['offer_barrier_free'] = 'full accessible';
$lang['offer_learning_opportunity'] = 'Educational opportunity';
$lang['offer_child_friendly'] = 'child-friendly';
$lang['offer_park_day'] = "Day of parks";
$lang['offer_enjoy_week'] = "Week of enjoyment";
$lang['offer_public_transport_stop'] = 'Arrival with public transport (stop/station)';
$lang['offer_contact'] = 'Contact';
$lang['offer_upload_image'] = 'Picture upload';
$lang['offer_links'] = 'Continuative links';
$lang['offer_upload_pdf'] = 'Upload PDF';
$lang['offer_available_for'] = 'Offer released for';
$lang['offer_paerke_ch'] = 'paerke.ch';
$lang['offer_own_park'] = 'Own Park';
$lang['offer_switzerland_tourism'] = 'Switzerland Tourism';
$lang['offer_valid'] = 'Validity of the entry';
$lang['offer_valid_from'] = 'Valid from';
$lang['offer_valid_to'] = 'Valid to';
$lang['offer_signs'] = 'Characters';
$lang['offer_images'] = 'Pictures';
$lang['offer_documents'] = 'Documents (PDF, Excel, Word, etc.)';
$lang['offer_documents_public'] = 'Documents';
$lang['offer_main_image'] = 'Main picture';
$lang['offer_image'] = 'Picture';
$lang['offer_delete_success'] = 'The offer was successfully deleted.';
$lang['offer_delete_error'] = 'Error while deleting the offer.';
$lang['offer_category_update_success'] = 'The category was successfully updated.';
$lang['offer_delete_image_confirm'] = 'Are you sure you want to delete this picture? The picture will be irrevocably deleted.';
$lang['offer_document'] = 'Document';
$lang['offer_contact_change'] = 'Change contact';
$lang['offer_document_title'] = 'Name of the Document';
$lang['offer_delete_document_confirm'] = 'Are you sure you want to delete this document? The document will be irrevocably deleted.';
$lang['offer_link_url'] = 'URL';
$lang['offer_link_title'] = 'Title';
$lang['offer_link_add'] = 'Add link';
$lang['offer_link_remove_confirm'] = 'Are you sure you want to delete this link?';
$lang['offer_park'] = 'Park/Organisation';
$lang['offer_additional_info'] = 'Additional information';
$lang['offer_valid_infinite'] = 'Infinite validity';
$lang['offer_parks_all'] = 'All Parks';
$lang['offer_categories_all'] = 'All Categories';
$lang['offer_categories'] = 'Categories';
$lang['offer_status'] = 'Status';
$lang['offer_status_inactive'] = 'Inactiv';
$lang['offer_status_active'] = 'Activ';
$lang['offer_not_found'] = 'No offer found with this ID.';
$lang['offer_coordinates'] = 'Coordinates';
$lang['offer_images_help'] = 'Here you can upload pictures with the format JPG, GIF or PNG. The minimum-size of a picture is 200x100 Pixel. Please observe the copyright of the original picture.';
$lang['offer_maps_help'] = 'For choosing a point on the map you can move the marking with the mouse or double click at the desired place on the map. Alternatively you can search for a place with the search.';
$lang['offer_activity_maps_help'] = 'You can adapt the route arbitrary by moving the way-points (grey) with the mouse. You can add new way-points by moving the white small markers. You can delete existing way-points by right-clicking.';
$lang['offer_will_not_be_published_on_myswitzerland'] = 'Offer will not be published by Switzerland Tourism.';
$lang['offer_all_season'] = 'All season';
$lang['offer_maps_search'] = 'Search';
$lang['offer_maps_search_go'] = 'Find';
$lang['offer_maps_choose'] = 'Choose map';
$lang['offer_languages'] = 'Languages';
$lang['offer_filter'] = 'Offer-filter';
$lang['offer_no_results'] = 'No offers found with this search-criteria.';
$lang['offer_subscription_help'] = 'For this offer you have to subscribe.';
$lang['offer_subscription_details'] = "Additional subscription information";


/*
| language related fields
*/
$lang['offer_title_description'] = 'Title and description';
$lang['offer_title'] = 'Title';
$lang['offer_description'] = 'Description';
$lang['offer_short_description'] = 'Description - short';
$lang['offer_medium_description'] = 'Description - medium';
$lang['offer_long_description'] = 'Description - long';
$lang['offer_price'] = 'Price-information';
$lang['offer_date_details'] = 'Date-details';


/*
| Default mask fields
*/
$lang['offer_parkname'] = 'Name of the Park';
$lang['offer_park_event'] = 'Park event';
$lang['offer_park_partner'] = 'Business is partner of the park';
$lang['offer_park_partner_event'] = 'Parkpartnerevent';
$lang['offer_park_partner_booking'] = 'Parkpartnerbusiness';
$lang['offer_kind_of'] = 'Kind of event';
$lang['offer_institution'] = 'Institution/Locality';
$lang['offer_street'] = 'Street';
$lang['offer_place'] = 'City';
$lang['offer_location'] = 'Location';
$lang['offer_date'] = 'Date';
$lang['offer_dates'] = 'Dates';
$lang['offer_from'] = 'from';
$lang['offer_to'] = 'To';
$lang['offer_at'] = 'At';
$lang['offer_oclock'] = 'Time';


/*
| Insert mask 1
*/
$lang['offer_title_event'] = 'Event-Data';
$lang['offer_add_date'] = 'Add further date';
$lang['offer_event_location'] = 'Location of the event';
$lang['offer_event_organiser'] = 'Host/Organizer';
$lang['offer_subscription'] = 'Registration';
$lang['offer_subscription_mandatory'] = 'Registration required';
$lang['offer_subscription_contact'] = 'Registration contact';
$lang['offer_subscription_link'] = 'Link to the registration';
$lang['offer_subscription_recommended'] = 'Recommended';
$lang['offer_local'] = 'Local';
$lang['offer_regional'] = 'Regional';
$lang['offer_national'] = 'National';
$lang['offer_international'] = 'International';
$lang['offer_misc'] = 'Various';
$lang['offer_delete_date_confirm'] = 'Are you sure you want to delete this date?';
$lang['offer_location_details'] = "Location details";



/*
| Insert mask 2
*/
$lang['offer_product_offerer'] = 'Provider / Institution';
$lang['offer_opening_hours'] = 'Openinghours';
$lang['offer_supplier'] = 'Offerer';
$lang['offer_availability'] = 'Product available from / to';
$lang['offer_available_from'] = 'Avaliable from';
$lang['offer_available_to'] = 'Availbale to';
$lang['offer_supplier_add'] = 'Add offerer';
$lang['offer_contact_remove_confirm'] = 'Are you sure you want to delete this contact-allocation?';
$lang['offer_infrastructure'] = 'Infrastructure';
$lang['offer_number_of_rooms'] = 'Number of rooms';
$lang['offer_rooms'] = '%s Rooms';
$lang['offer_conference_room'] = 'Seminarroom';
$lang['offer_playground'] = 'Playground';
$lang['offer_picnic_place'] = 'Picnicplace';
$lang['offer_fireplace'] = 'Fireplace';
$lang['offer_washroom'] = 'Toilet';
$lang['offer_other_infrastructure'] = 'Further infrastructure';


/*
| Insert mask 3
*/
$lang['offer_organizer'] = 'Organizer';
$lang['offer_execution_times'] = 'Date/Period';
$lang['offer_accommodation'] = 'Accomodation-possibilities';
$lang['offer_accommodation_add'] = 'Add accomodation-possibility';
$lang['offer_number_of_people_groups'] = 'Number of persons for group-offers';
$lang['offer_number_of_people_individual'] = 'Number of persons for individual-packages';
$lang['offer_min_subscriber'] = 'Number of participants min.';
$lang['offer_max_subscriber'] = 'Number of participants max.';
$lang['offer_benefits'] = 'Benefits';
$lang['offer_requirements'] = 'Requirements';


/*
| Insert mask 4 (Activity)
*/
$lang['offer_safety_instructions'] = 'Safety advices';
$lang['offer_signalization'] = "Signalization";
$lang['offer_material_rent'] = 'Equipment rent';
$lang['offer_catering_informations'] = 'Possibilities for catering';
$lang['offer_saison'] = 'Season';
$lang['offer_start_place'] = 'Starting point';
$lang['offer_goal_place'] = 'Destination';
$lang['offer_altitude'] = 'Altitude';
$lang['offer_route_info'] = 'Route-information';
$lang['offer_route_length'] = 'Length';
$lang['offer_untarred_route_length'] = 'Amount untarred route';
$lang['offer_altitude_differential'] = 'Vertical heigth';
$lang['offer_altitude_ascent'] = 'Altitude difference ascent';
$lang['offer_altitude_descent'] = 'Altitude difference descent';
$lang['offer_altitude_meter'] = 'm';
$lang['offer_route_length_km'] = 'km';
$lang['offer_time_required'] = 'Time required';
$lang['offer_level_technics'] = 'Level technique';
$lang['offer_level_condition'] = 'Level condition';
$lang['offer_time_required_2h'] = '<2h';
$lang['offer_time_required_2_4h'] = '2-4h';
$lang['offer_time_required_4h'] = '>4h';
$lang['offer_easy'] = 'Easy';
$lang['offer_average'] = 'Middle';
$lang['offer_difficult'] = 'Hard';
$lang['offer_route'] = 'Route';
$lang['offer_activity_location'] = 'Location / Starting point';
$lang['offer_route_import'] = 'Import route';
$lang['offer_route_import_help'] = 'Routes can be uploaded as KML file.';
$lang['offer_route_import_file'] = 'KML file';


/*
| Pagination
*/
$lang['pagination_next'] = 'Continue &rsaquo;';
$lang['pagination_prev'] = '&lsaquo; Back';
$lang['back_to_overview'] = '&laquo; Back to overview';
$lang['back_to_route'] = '&laquo; Back to route';


/*
| Swissmap
*/
$lang['swissmap_basemap'] = 'Base Map';
$lang['swissmap_swissimage'] = 'Aerial Imagery';
$lang['swissmap_pixelkarte'] = 'National maps';
$lang['swissmap_hybrid'] = 'Hybrid';

$lang['swissmap_zoom_in'] = 'Zoom in';
$lang['swissmap_zoom_out'] = 'Zoom out';
$lang['swissmap_select_all_parks'] = 'All Parks';
$lang['swissmap_home'] = 'Home';
$lang['swissmap_back'] = 'Back';
$lang['swissmap_next'] = 'Forward';
$lang['swissmap_print'] = 'Print';
$lang['swissmap_help'] = 'Help';
$lang['swissmap_show_sidebar'] = 'Show Sidebar';
$lang['swissmap_hide_sidebar'] = 'Hide Sidebar';
$lang['swissmap_show_legend'] = 'Show Legend';
$lang['swissmap_hide_legend'] = 'Hide Legend';
$lang['swissmap_show_overview'] = 'Show Overview Map';
$lang['swissmap_hide_overview'] = 'Hide Overview Map';
$lang['swissmap_close'] = 'Close';
$lang['swissmap_baseinfo'] = 'Base Information';
$lang['swissmap_coordinates'] = 'National Coordinates';
$lang['swissmap_tools'] = 'Tools';
$lang['swissmap_tools_none'] = "No tool";
$lang['swissmap_tools_point'] = "Point";
$lang['swissmap_tools_distance'] = "Distance";
$lang['swissmap_tools_area'] = "Area";
$lang['swissmap_tools_result'] = "Measurement result";
$lang['swissmap_tools_choose_tool'] = "Choose a tool for measuring.";
$lang['swissmap_search'] = 'Search for place, canton, ...';
$lang['swissmap_home_title'] = 'Home';
$lang['swissmap_back_title'] = 'Back';
$lang['swissmap_next_title'] = 'Forward';
$lang['swissmap_tools_title'] = "Tools for measuring";
$lang['swissmap_print_title'] = 'Print';
$lang['swissmap_help_title'] = 'Help';
$lang['swissmap_offers'] = 'Offers';
$lang['swissmap_all_offers'] = 'All offers';
$lang['swissmap_source_swisstopo'] = 'Source: swisstopo';
$lang['swissmap_loading'] = 'Loading...';
$lang['swissmap_cancel'] = 'Cancel';