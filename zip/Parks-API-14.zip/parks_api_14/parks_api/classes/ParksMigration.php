<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| DB migrations
|
*/


class ParksMigration {


	/**
	 * API
	 */
	public $api;


	/**
	 * Migration version from
	 */
	private $version_from;


	/**
	 * Migration version to
	 */
	private $version_to;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param mixed $api
	 * @return void
	 */
	function __construct($api) {

		// api instance
		$this->api = $api;

	}


	/**
	 * Start migration
	 *
	 * @access public
	 * @return void
	 */
	public function start() {

		// version from
		$query_api = mysqli_fetch_assoc($this->api->db->get('api'));
		$this->version_from = intval($query_api['version']);

		// version to
		$this->version_to = API_VERSION;

		// migrate all versions
		for ($version = ($this->version_from+1) ; $version <= $this->version_to ; $version++) {
			$this->migrate_to($version);
		}

	}


	/**
	 * Migrate to specified version
	 *
	 * @access public
	 * @return void
	 */
	public function migrate_to($version_to) {
		if ($version_to > 0) {
			$this->api->logger->info('Starting migration from version '.$this->version_from.' to version '.$version_to.'...');
			switch($version_to) {
				default:
					break;

				/*
				|--------------------------------------------------------------------------
				| Migrate version 1 to version 2
				|--------------------------------------------------------------------------
				|
				*/
				case 2:
					$this->api->db->query("ALTER TABLE offer_route ADD PRIMARY KEY (offer_id);");
					$this->api->db->query("CREATE TABLE `project` (
										  `offer_id` bigint(20) NOT NULL DEFAULT '0',
										  `duration_from` int(11) DEFAULT NULL,
										  `duration_to` int(11) DEFAULT NULL,
										  `status` tinyint(1) DEFAULT NULL,
										  `poi` text,
										  PRIMARY KEY (`offer_id`),
										  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offer` (`offer_id`) ON DELETE CASCADE
										  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
					");

					// create new main category
					$this->api->db->insert('category', array('category_id' => CATEGORY_PROJECT, 'parent_id' => 0, 'marker' => '454545', 'sort' => 5000));
					$this->api->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'de', 'body' => 'Projekt'));
					$this->api->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'fr', 'body' => 'Projet'));
					$this->api->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'it', 'body' => 'Progetto'));
					$this->api->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'en', 'body' => 'Project'));

					// create sub categories
					$this->api->db->insert('category', array('category_id' => 1001, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ffcc00', 'sort' => 5010));
					$this->api->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'de', 'body' => 'Natur / Landschaft'));
					$this->api->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'fr', 'body' => 'Nature / paysage'));
					$this->api->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'it', 'body' => 'Natura / Paesaggio'));
					$this->api->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'en', 'body' => 'Nature / Landscape'));

					$this->api->db->insert('category', array('category_id' => 1002, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'cccccc', 'sort' => 5020));
					$this->api->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'de', 'body' => 'Biodiversität'));
					$this->api->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'fr', 'body' => 'Biodiversité'));
					$this->api->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'it', 'body' => 'Biodiversità'));
					$this->api->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'en', 'body' => 'Biodiversity'));

					$this->api->db->insert('category', array('category_id' => 1003, 'parent_id' => CATEGORY_PROJECT, 'marker' => '0066ff', 'sort' => 5030));
					$this->api->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'de', 'body' => 'Landwirtschaft'));
					$this->api->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'fr', 'body' => 'Agriculture'));
					$this->api->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'it', 'body' => 'Agricoltura'));
					$this->api->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'en', 'body' => 'Agriculture'));

					$this->api->db->insert('category', array('category_id' => 1004, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff99cc', 'sort' => 5040));
					$this->api->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'de', 'body' => 'Forstwirtschaft'));
					$this->api->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'fr', 'body' => 'Sylviculture'));
					$this->api->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'it', 'body' => 'Economia forestale'));
					$this->api->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'en', 'body' => 'Forestry'));

					$this->api->db->insert('category', array('category_id' => 1005, 'parent_id' => CATEGORY_PROJECT, 'marker' => '93dbff', 'sort' => 5050));
					$this->api->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'de', 'body' => 'Energie'));
					$this->api->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'fr', 'body' => 'Énergie'));
					$this->api->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'it', 'body' => 'Energia'));
					$this->api->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'en', 'body' => 'Energy'));

					$this->api->db->insert('category', array('category_id' => 1006, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff7b21', 'sort' => 5060));
					$this->api->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'de', 'body' => 'Raumplanung'));
					$this->api->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'fr', 'body' => 'Aménagement du territoire'));
					$this->api->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'it', 'body' => 'Pianificazione territoriale'));
					$this->api->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'en', 'body' => 'Spatial planning'));

					$this->api->db->insert('category', array('category_id' => 1007, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'd8d8d8', 'sort' => 5070));
					$this->api->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'de', 'body' => 'Tourismus'));
					$this->api->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'fr', 'body' => 'Tourisme'));
					$this->api->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'it', 'body' => 'Turismo'));
					$this->api->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'en', 'body' => 'Tourism'));

					$this->api->db->insert('category', array('category_id' => 1008, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ffff00', 'sort' => 5080));
					$this->api->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'de', 'body' => 'Mobilität'));
					$this->api->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'fr', 'body' => 'Mobilité'));
					$this->api->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'it', 'body' => 'Mobilità'));
					$this->api->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'en', 'body' => 'Mobility'));

					$this->api->db->insert('category', array('category_id' => 1009, 'parent_id' => CATEGORY_PROJECT, 'marker' => '00501f', 'sort' => 5090));
					$this->api->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'de', 'body' => 'Besucherlenkung'));
					$this->api->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'fr', 'body' => 'Gestion des visiteurs'));
					$this->api->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'it', 'body' => 'Visite guidate'));
					$this->api->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'en', 'body' => 'Visitor management'));

					$this->api->db->insert('category', array('category_id' => 1010, 'parent_id' => CATEGORY_PROJECT, 'marker' => '974807', 'sort' => 5100));
					$this->api->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'de', 'body' => 'Zugänglichkeit'));
					$this->api->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'fr', 'body' => 'Accessibilité '));
					$this->api->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'it', 'body' => 'Accessibilità'));
					$this->api->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'en', 'body' => 'Accessibility'));

					$this->api->db->insert('category', array('category_id' => 1011, 'parent_id' => CATEGORY_PROJECT, 'marker' => '7dd53b', 'sort' => 5110));
					$this->api->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'de', 'body' => 'Bildung'));
					$this->api->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'fr', 'body' => 'Education'));
					$this->api->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'it', 'body' => 'Formazione'));
					$this->api->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'en', 'body' => 'Education'));

					$this->api->db->insert('category', array('category_id' => 1012, 'parent_id' => CATEGORY_PROJECT, 'marker' => '699fd6', 'sort' => 5120));
					$this->api->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'de', 'body' => 'Kultur'));
					$this->api->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'fr', 'body' => 'Culture'));
					$this->api->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'it', 'body' => 'Cultura'));
					$this->api->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'en', 'body' => 'Culture'));

					$this->api->db->insert('category', array('category_id' => 1013, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'c79602', 'sort' => 5130));
					$this->api->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'de', 'body' => 'Regionale Produkte'));
					$this->api->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'fr', 'body' => 'Produits régionaux'));
					$this->api->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'it', 'body' => 'Prodotti regionali'));
					$this->api->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'en', 'body' => 'Regional products'));

					$this->api->db->insert('category', array('category_id' => 1014, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff00ff', 'sort' => 5140));
					$this->api->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'de', 'body' => 'Gesundheit / Wellness'));
					$this->api->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'fr', 'body' => 'Santé / bien-être'));
					$this->api->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'it', 'body' => 'Benessere / wellness'));
					$this->api->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'en', 'body' => 'Health / wellness'));

					$this->api->db->insert('category', array('category_id' => 1015, 'parent_id' => CATEGORY_PROJECT, 'marker' => '9b7bb4', 'sort' => 5150));
					$this->api->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'de', 'body' => 'Nachhaltigkeit'));
					$this->api->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'fr', 'body' => 'Durabilité'));
					$this->api->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'it', 'body' => 'Sostenibilità'));
					$this->api->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'en', 'body' => 'Sustainability'));

					$this->api->db->insert('category', array('category_id' => 1016, 'parent_id' => CATEGORY_PROJECT, 'marker' => '376091', 'sort' => 5160));
					$this->api->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'de', 'body' => 'Dienstleistungen'));
					$this->api->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'fr', 'body' => 'Services'));
					$this->api->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'it', 'body' => 'Servizi'));
					$this->api->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'en', 'body' => 'Services'));

					$this->api->db->insert('category', array('category_id' => 1017, 'parent_id' => CATEGORY_PROJECT, 'marker' => '7030a0', 'sort' => 5170));
					$this->api->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'de', 'body' => 'Transnationale Projekte'));
					$this->api->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'fr', 'body' => 'Projets transfrontaliers'));
					$this->api->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'it', 'body' => 'Progetti transnazionali'));
					$this->api->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'en', 'body' => 'Transnational projects'));

					// move research category
					$this->api->db->query("UPDATE `category` SET `category`.`sort` = 6000 WHERE `category_id` = 5000 LIMIT 1;");
					$this->api->db->query("UPDATE `category` SET `category`.`sort` = 6010 WHERE `category_id` = 5001 LIMIT 1;");
					$this->api->db->query("UPDATE `category` SET `category`.`sort` = 6020 WHERE `category_id` = 5002 LIMIT 1;");

					break;


				/*
				|--------------------------------------------------------------------------
				| Migrate version 4 to version 5
				|--------------------------------------------------------------------------
				|
				*/
				case 5:
					$this->api->db->query("ALTER TABLE `offer` ADD COLUMN `is_hint` TINYINT(1) AFTER `park`;");
					break;

				/*
				|--------------------------------------------------------------------------
				| Migrate version 5 to version 6
				|--------------------------------------------------------------------------
				|
				*/
				case 6:

					// create new keywords field for offers
					$this->api->db->query("ALTER TABLE `offer` ADD COLUMN `keywords` VARCHAR(150) AFTER `longitude`;");

					// create category: event -> presentation
					$this->api->db->insert('category', array('category_id' => 122, 'parent_id' => 1, 'marker' => 'ffcc00', 'sort' => 1025));
					$this->api->db->insert('category_i18n', array('category_id' => 122, 'language' => 'de', 'body' => 'Vortrag'));
					$this->api->db->insert('category_i18n', array('category_id' => 122, 'language' => 'fr', 'body' => 'Présentation'));
					$this->api->db->insert('category_i18n', array('category_id' => 122, 'language' => 'it', 'body' => 'Presentatzione'));
					$this->api->db->insert('category_i18n', array('category_id' => 122, 'language' => 'en', 'body' => 'Presentation'));

					// create category: product -> producer
					$this->api->db->insert('category', array('category_id' => 123, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2312));
					$this->api->db->insert('category_i18n', array('category_id' => 123, 'language' => 'de', 'body' => 'Produzent'));
					$this->api->db->insert('category_i18n', array('category_id' => 123, 'language' => 'fr', 'body' => 'Producteur'));
					$this->api->db->insert('category_i18n', array('category_id' => 123, 'language' => 'it', 'body' => 'Produttore'));
					$this->api->db->insert('category_i18n', array('category_id' => 123, 'language' => 'en', 'body' => 'Producer'));

					// create category: product -> shop for regional products
					$this->api->db->insert('category', array('category_id' => 124, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2314));
					$this->api->db->insert('category_i18n', array('category_id' => 124, 'language' => 'de', 'body' => 'Verkauf Regionalprodukte'));
					$this->api->db->insert('category_i18n', array('category_id' => 124, 'language' => 'fr', 'body' => 'Vente du produits regionaux'));
					$this->api->db->insert('category_i18n', array('category_id' => 124, 'language' => 'it', 'body' => 'Vendita di prodotti regionali'));
					$this->api->db->insert('category_i18n', array('category_id' => 124, 'language' => 'en', 'body' => 'Shop for regional products'));

					// create category: product -> gifts
					$this->api->db->insert('category', array('category_id' => 125, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2316));
					$this->api->db->insert('category_i18n', array('category_id' => 125, 'language' => 'de', 'body' => 'Geschenke'));
					$this->api->db->insert('category_i18n', array('category_id' => 125, 'language' => 'fr', 'body' => 'Cadeaux'));
					$this->api->db->insert('category_i18n', array('category_id' => 125, 'language' => 'it', 'body' => 'Regali'));
					$this->api->db->insert('category_i18n', array('category_id' => 125, 'language' => 'en', 'body' => 'Gifts'));

					// update category: product -> further
					$this->api->db->update('category_i18n', array('body' => 'Weitere Produkte'), array('category_id' => 27, 'language' => 'de'));

					// update category: gastronomy/accommodation -> restaurant
					$this->api->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'de'));
					$this->api->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'fr'));
					$this->api->db->update('category_i18n', array('body' => 'Ristorante'), array('category_id' => 28, 'language' => 'it'));
					$this->api->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'en'));

					// create category: gastronomy/accommodation -> cafe
					$this->api->db->insert('category', array('category_id' => 126, 'parent_id' => 20, 'marker' => 'ff7b21', 'sort' => 2415));
					$this->api->db->insert('category_i18n', array('category_id' => 126, 'language' => 'de', 'body' => 'Cafe'));
					$this->api->db->insert('category_i18n', array('category_id' => 126, 'language' => 'fr', 'body' => 'Café'));
					$this->api->db->insert('category_i18n', array('category_id' => 126, 'language' => 'it', 'body' => 'Caffè'));
					$this->api->db->insert('category_i18n', array('category_id' => 126, 'language' => 'en', 'body' => 'Cafe'));

					// check all cafe offers coming from restaurant
					$q_category_link = $this->api->db->get('category_link', array('category_id' => 28));
					if (mysqli_num_rows($q_category_link) > 0) {
						while ($row = mysqli_fetch_object($q_category_link)) {
							$this->api->db->insert('category_link', array('offer_id' => $row->offer_id, 'category_id' => 126));
						}
					}

					// create category: infrastructure -> swimming pool/lake
					$this->api->db->insert('category', array('category_id' => 127, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2631));
					$this->api->db->insert('category_i18n', array('category_id' => 127, 'language' => 'de', 'body' => 'Schwimmbad/Badesee'));
					$this->api->db->insert('category_i18n', array('category_id' => 127, 'language' => 'fr', 'body' => 'Piscine/Lac de baignade'));
					$this->api->db->insert('category_i18n', array('category_id' => 127, 'language' => 'it', 'body' => 'Piscina/Lago balneabile'));
					$this->api->db->insert('category_i18n', array('category_id' => 127, 'language' => 'en', 'body' => 'Swimming pool/Swimming lake'));

					// update category sort: infrastructure -> watersports
					$this->api->db->update('category', array('sort' => 2633), array('category_id' => 119));

					// create category: infrastructure -> funicular
					$this->api->db->insert('category', array('category_id' => 128, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2632));
					$this->api->db->insert('category_i18n', array('category_id' => 128, 'language' => 'de', 'body' => 'Seilbahn'));
					$this->api->db->insert('category_i18n', array('category_id' => 128, 'language' => 'fr', 'body' => 'Funiculaire'));
					$this->api->db->insert('category_i18n', array('category_id' => 128, 'language' => 'it', 'body' => 'Funicolare'));
					$this->api->db->insert('category_i18n', array('category_id' => 128, 'language' => 'en', 'body' => 'Funicular'));

					// create category: infrastructure -> climbing
					$this->api->db->insert('category', array('category_id' => 129, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2638));
					$this->api->db->insert('category_i18n', array('category_id' => 129, 'language' => 'de', 'body' => 'Klettern'));
					$this->api->db->insert('category_i18n', array('category_id' => 129, 'language' => 'fr', 'body' => 'Escalade'));
					$this->api->db->insert('category_i18n', array('category_id' => 129, 'language' => 'it', 'body' => 'Arrampicata'));
					$this->api->db->insert('category_i18n', array('category_id' => 129, 'language' => 'en', 'body' => 'Climbing'));

					// create category: infrastructure -> skating rink
					$this->api->db->insert('category', array('category_id' => 130, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2643));
					$this->api->db->insert('category_i18n', array('category_id' => 130, 'language' => 'de', 'body' => 'Eisbahn'));
					$this->api->db->insert('category_i18n', array('category_id' => 130, 'language' => 'fr', 'body' => 'Patinoire'));
					$this->api->db->insert('category_i18n', array('category_id' => 130, 'language' => 'it', 'body' => 'Pista di ghiaccio'));
					$this->api->db->insert('category_i18n', array('category_id' => 130, 'language' => 'en', 'body' => 'Skating rink'));

					// create category: infrastructure -> cross-country skiing
					$this->api->db->insert('category', array('category_id' => 131, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2647));
					$this->api->db->insert('category_i18n', array('category_id' => 131, 'language' => 'de', 'body' => 'Langlauf'));
					$this->api->db->insert('category_i18n', array('category_id' => 131, 'language' => 'fr', 'body' => 'Ski de fond'));
					$this->api->db->insert('category_i18n', array('category_id' => 131, 'language' => 'it', 'body' => 'Sci di fondo'));
					$this->api->db->insert('category_i18n', array('category_id' => 131, 'language' => 'en', 'body' => 'Cross-country skiing'));

					break;

				/*
				|--------------------------------------------------------------------------
				| Migrate version 6 to version 7
				|--------------------------------------------------------------------------
				|
				*/
				case 7:
					// remove available_from/to
					$this->api->db->query("ALTER TABLE `product` DROP COLUMN `available_from`;");
					$this->api->db->query("ALTER TABLE `product` DROP COLUMN `available_to`;");

					// update category: veranstaltungen
					$this->api->db->update('category', array('marker' => '362782'), array('category_id' => 1));
					// update sub-categories: veranstaltungen
					$this->api->db->update('category', array('marker' => '362782'), array('parent_id' => 1));

					// update category: informationen
					$this->api->db->update('category', array('marker' => '79BCDA'), array('category_id' => 79));
					// update sub-categories: informationen
					$this->api->db->update('category', array('marker' => '79BCDA'), array('parent_id' => 79));

					// update category: sehensw
					$this->api->db->update('category', array('marker' => '00625C'), array('category_id' => 22));
					// update sub-categories: sehensw
					$this->api->db->update('category', array('marker' => '00625C'), array('parent_id' => 22));

					// update category: reg prod
					$this->api->db->update('category', array('marker' => '8CCAAD'), array('category_id' => 19));
					// update sub-categories: reg prod
					$this->api->db->update('category', array('marker' => '8CCAAD'), array('parent_id' => 19));

					// update category: verpflegung
					$this->api->db->update('category', array('marker' => 'F3975F'), array('category_id' => 20));
					// update sub-categories: verpflegung
					$this->api->db->update('category', array('marker' => 'F3975F'), array('parent_id' => 20));

					// update category: beherbergung
					$this->api->db->update('category', array('marker' => 'C62945'), array('category_id' => 21));
					// update sub-categories: beherbergung
					$this->api->db->update('category', array('marker' => 'C62945'), array('parent_id' => 21));

					// update category: infra
					$this->api->db->update('category', array('marker' => 'D18391'), array('category_id' => 100));
					// update sub-categories: infra
					$this->api->db->update('category', array('marker' => 'D18391'), array('parent_id' => 100));

					// update category: pauschaulang
					$this->api->db->update('category', array('marker' => 'FCE237'), array('category_id' => 3));
					// update sub-categories: pauschalang
					$this->api->db->update('category', array('marker' => 'FCE237'), array('parent_id' => 3));

					// update category: sommerakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 50));
					// update sub-categories: sommerakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 50));

					// update category: winterakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 51));
					// update sub-categories: winterakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 51));

					// update category: forschung
					$this->api->db->update('category', array('marker' => '3A5BA6'), array('category_id' => 5000));
					// update sub-categories: forschung
					$this->api->db->update('category', array('marker' => '3A5BA6'), array('parent_id' => 5000));

					// update category: themenweg
					$this->api->db->update('category', array('marker' => '92D255'), array('category_id' => 63));
					// update sub-categories: themenweg
					$this->api->db->update('category', array('marker' => '92D255'), array('parent_id' => 63));

					// update category: wanderung
					$this->api->db->update('category', array('marker' => '4BA234'), array('category_id' => 64));
					// update sub-categories: wanderung
					$this->api->db->update('category', array('marker' => '4BA234'), array('parent_id' => 64));

					// update category: veloroute
					$this->api->db->update('category', array('marker' => '449BD5'), array('category_id' => 65));
					// update sub-categories: veloroute
					$this->api->db->update('category', array('marker' => '449BD5'), array('parent_id' => 65));

					// update category: e-bike routen
					$this->api->db->update('category', array('marker' => '2677C0'), array('category_id' => 78));
					// update sub-categories: e-bike routen
					$this->api->db->update('category', array('marker' => '2677C0'), array('parent_id' => 78));

					// update category: Mountainbiketour
					$this->api->db->update('category', array('marker' => 'FACA4D'), array('category_id' => 66));
					// update sub-categories: Mountainbiketour
					$this->api->db->update('category', array('marker' => 'FACA4D'), array('parent_id' => 66));

					// update category: reittouren
					$this->api->db->update('category', array('marker' => 'C09732'), array('category_id' => 82));
					// update sub-categories: reittouren
					$this->api->db->update('category', array('marker' => 'C09732'), array('parent_id' => 82));

					// update category: weitere routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 68));
					// update sub-categories: weitere routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 68));

					// update category: schneeschuhtour
					$this->api->db->update('category', array('marker' => 'BE2F7E'), array('category_id' => 69));
					// update sub-categories: schneeschuhtour
					$this->api->db->update('category', array('marker' => 'BE2F7E'), array('parent_id' => 69));

					// update category: Winterwanderung
					$this->api->db->update('category', array('marker' => 'EC7AAD'), array('category_id' => 70));
					// update sub-categories: Winterwanderung
					$this->api->db->update('category', array('marker' => 'EC7AAD'), array('parent_id' => 70));

					// update category: Langlaufstrecke
					$this->api->db->update('category', array('marker' => '60C1E9'), array('category_id' => 73));
					// update sub-categories: Langlaufstrecke
					$this->api->db->update('category', array('marker' => '60C1E9'), array('parent_id' => 73));

					// update category: Schlittelweg
					$this->api->db->update('category', array('marker' => '9E7967'), array('category_id' => 74));
					// update sub-categories: Schlittelweg
					$this->api->db->update('category', array('marker' => '9E7967'), array('parent_id' => 74));

					// update category: Weitere Routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 75));
					// update sub-categories: Weitere Routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 75));

					break;


				/*
				|--------------------------------------------------------------------------
				| Migrate version 7 to version 8
				| «Pärke entdecken» step
				|--------------------------------------------------------------------------
				|
				*/
				case 8:
					// update category: summer activities
					$this->api->db->update('category_i18n', array('body' => "Sommerrouten"), array('category_id' => 50, 'language' => 'de'));
					$this->api->db->update('category_i18n', array('body' => "Itin&eacute;raires d'&eacute;t&eacute;"), array('category_id' => 50, 'language' => 'fr'));
					$this->api->db->update('category_i18n', array('body' => "Itinerari estivi"), array('category_id' => 50, 'language' => 'it'));
					$this->api->db->update('category_i18n', array('body' => "Summer routes"), array('category_id' => 50, 'language' => 'en'));

					// update category: winter activities
					$this->api->db->update('category_i18n', array('body' => "Winterrouten"), array('category_id' => 51, 'language' => 'de'));
					$this->api->db->update('category_i18n', array('body' => "Itin&eacute;raires d'hiver"), array('category_id' => 51, 'language' => 'fr'));
					$this->api->db->update('category_i18n', array('body' => "Itinerari invernali"), array('category_id' => 51, 'language' => 'it'));
					$this->api->db->update('category_i18n', array('body' => "Winter routes"), array('category_id' => 51, 'language' => 'en'));

					// update category: veranstaltungen
					$this->api->db->update('category', array('marker' => '362782'), array('category_id' => 1));
					// update sub-categories: veranstaltungen
					$this->api->db->update('category', array('marker' => '362782'), array('parent_id' => 1));

					// update category: informationen
					$this->api->db->update('category', array('marker' => '79BCDA'), array('category_id' => 79));
					// update sub-categories: informationen
					$this->api->db->update('category', array('marker' => '79BCDA'), array('parent_id' => 79));

					// update category: sehensw
					$this->api->db->update('category', array('marker' => '00625C'), array('category_id' => 22));
					// update sub-categories: sehensw
					$this->api->db->update('category', array('marker' => '00625C'), array('parent_id' => 22));

					// update category: reg prod
					$this->api->db->update('category', array('marker' => '8CCAAD'), array('category_id' => 19));
					// update sub-categories: reg prod
					$this->api->db->update('category', array('marker' => '8CCAAD'), array('parent_id' => 19));

					// update category: verpflegung
					$this->api->db->update('category', array('marker' => 'F3975F'), array('category_id' => 20));
					// update sub-categories: verpflegung
					$this->api->db->update('category', array('marker' => 'F3975F'), array('parent_id' => 20));

					// update category: beherbergung
					$this->api->db->update('category', array('marker' => 'C62945'), array('category_id' => 21));
					// update sub-categories: beherbergung
					$this->api->db->update('category', array('marker' => 'C62945'), array('parent_id' => 21));

					// update category: infra
					$this->api->db->update('category', array('marker' => 'D18391'), array('category_id' => 100));
					// update sub-categories: infra
					$this->api->db->update('category', array('marker' => 'D18391'), array('parent_id' => 100));

					// update category: pauschaulang
					$this->api->db->update('category', array('marker' => 'FCE237'), array('category_id' => 3));
					// update sub-categories: pauschalang
					$this->api->db->update('category', array('marker' => 'FCE237'), array('parent_id' => 3));

					// update category: sommerakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 50));
					// update sub-categories: sommerakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 50));

					// update category: winterakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 51));
					// update sub-categories: winterakti
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 51));

					// update category: forschung
					$this->api->db->update('category', array('marker' => '3A5BA6'), array('category_id' => 5000));
					// update sub-categories: forschung
					$this->api->db->update('category', array('marker' => '3A5BA6'), array('parent_id' => 5000));

					// update category: themenweg
					$this->api->db->update('category', array('marker' => '92D255'), array('category_id' => 63));
					// update sub-categories: themenweg
					$this->api->db->update('category', array('marker' => '92D255'), array('parent_id' => 63));

					// update category: wanderung
					$this->api->db->update('category', array('marker' => '4BA234'), array('category_id' => 64));
					// update sub-categories: wanderung
					$this->api->db->update('category', array('marker' => '4BA234'), array('parent_id' => 64));

					// update category: veloroute
					$this->api->db->update('category', array('marker' => '449BD5'), array('category_id' => 65));
					// update sub-categories: veloroute
					$this->api->db->update('category', array('marker' => '449BD5'), array('parent_id' => 65));

					// update category: e-bike routen
					$this->api->db->update('category', array('marker' => '2677C0'), array('category_id' => 78));
					// update sub-categories: e-bike routen
					$this->api->db->update('category', array('marker' => '2677C0'), array('parent_id' => 78));

					// update category: Mountainbiketour
					$this->api->db->update('category', array('marker' => 'FACA4D'), array('category_id' => 66));
					// update sub-categories: Mountainbiketour
					$this->api->db->update('category', array('marker' => 'FACA4D'), array('parent_id' => 66));

					// update category: reittouren
					$this->api->db->update('category', array('marker' => 'C09732'), array('category_id' => 82));
					// update sub-categories: reittouren
					$this->api->db->update('category', array('marker' => 'C09732'), array('parent_id' => 82));

					// update category: weitere routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 68));
					// update sub-categories: weitere routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 68));

					// update category: schneeschuhtour
					$this->api->db->update('category', array('marker' => 'BE2F7E'), array('category_id' => 69));
					// update sub-categories: schneeschuhtour
					$this->api->db->update('category', array('marker' => 'BE2F7E'), array('parent_id' => 69));

					// update category: Winterwanderung
					$this->api->db->update('category', array('marker' => 'EC7AAD'), array('category_id' => 70));
					// update sub-categories: Winterwanderung
					$this->api->db->update('category', array('marker' => 'EC7AAD'), array('parent_id' => 70));

					// update category: Langlaufstrecke
					$this->api->db->update('category', array('marker' => '60C1E9'), array('category_id' => 73));
					// update sub-categories: Langlaufstrecke
					$this->api->db->update('category', array('marker' => '60C1E9'), array('parent_id' => 73));

					// update category: Schlittelweg
					$this->api->db->update('category', array('marker' => '9E7967'), array('category_id' => 74));
					// update sub-categories: Schlittelweg
					$this->api->db->update('category', array('marker' => '9E7967'), array('parent_id' => 74));

					// update category: Weitere Routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('category_id' => 75));
					// update sub-categories: Weitere Routen
					$this->api->db->update('category', array('marker' => 'C6C6C6'), array('parent_id' => 75));

					// update category: summer activities
					$this->api->db->update('category_i18n', array('body' => "Sommerrouten"), array('category_id' => 50, 'language' => 'de'));
					$this->api->db->update('category_i18n', array('body' => "Itin&eacute;raires d'&eacute;t&eacute;"), array('category_id' => 50, 'language' => 'fr'));
					$this->api->db->update('category_i18n', array('body' => "Itinerari estivi"), array('category_id' => 50, 'language' => 'it'));
					$this->api->db->update('category_i18n', array('body' => "Summer routes"), array('category_id' => 50, 'language' => 'en'));

					// update category: winter activities
					$this->api->db->update('category_i18n', array('body' => "Winterrouten"), array('category_id' => 51, 'language' => 'de'));
					$this->api->db->update('category_i18n', array('body' => "Itin&eacute;raires d'hiver"), array('category_id' => 51, 'language' => 'fr'));
					$this->api->db->update('category_i18n', array('body' => "Itinerari invernali"), array('category_id' => 51, 'language' => 'it'));
					$this->api->db->update('category_i18n', array('body' => "Winter routes"), array('category_id' => 51, 'language' => 'en'));

					// update target groups
					$this->api->db->query("ALTER TABLE `target_group` ADD COLUMN `sort` int(11) DEFAULT NULL;");
					$this->api->db->update('target_group', array('sort' => 0), array('target_group_id' => 1));
					$this->api->db->update('target_group', array('sort' => 35), array('target_group_id' => 2));
					$this->api->db->update('target_group', array('sort' => 37), array('target_group_id' => 3));
					$this->api->db->update('target_group', array('sort' => 10), array('target_group_id' => 4));
					$this->api->db->update('target_group', array('sort' => 20), array('target_group_id' => 5));
					$this->api->db->update('target_group', array('sort' => 30), array('target_group_id' => 6));
					$this->api->db->update('target_group', array('sort' => 50), array('target_group_id' => 7));
					$this->api->db->update('target_group', array('sort' => 60), array('target_group_id' => 8));
					$this->api->db->update('target_group', array('sort' => 70), array('target_group_id' => 9));
					$this->api->db->update('target_group', array('sort' => 80), array('target_group_id' => 10));
					$this->api->db->update('target_group', array('sort' => 38), array('target_group_id' => 11));

					// update accommodation
					$this->api->db->query("ALTER TABLE `accommodation` ADD COLUMN `is_park_partner` TINYINT DEFAULT 0;");

					// add primary key to offer_date table
					$this->api->db->query("DROP TABLE IF EXISTS `offer_date`;");
					$this->api->db->query("
						CREATE TABLE `offer_date` (
						  `offer_date_id` BIGINT NOT NULL AUTO_INCREMENT,
						  `offer_id` BIGINT DEFAULT NULL,
						  `date_from` DATETIME DEFAULT NULL,
						  `date_to` DATETIME DEFAULT NULL,
						  PRIMARY KEY (`offer_date_id`),
						  KEY `offer_id_idxfk_6` (`offer_id`),
						  CONSTRAINT `offer_date_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offer` (`offer_id`) ON DELETE CASCADE
						) ENGINE=InnoDB DEFAULT CHARSET=utf8;
					");

					break;

					/*
					|--------------------------------------------------------------------------
					| Migrate version 8 to version 9
					| Accessibilities from Pro Infirmis
					|--------------------------------------------------------------------------
					|
					*/
					case 9:
						$this->api->db->query("
							CREATE TABLE `accessibility_pictogram`
							(
							`accessibility_pictogram_id` BIGINT NOT NULL,
							`pictogram_source` VARCHAR(1000),
							`name_de` VARCHAR(500),
							`name_en` VARCHAR(500),
							`name_fr` VARBINARY(500),
							`name_it` VARCHAR(500),
							`detail_link` VARCHAR(500),
							PRIMARY KEY (`accessibility_pictogram_id`)
							) ENGINE=InnoDB CHARACTER SET=utf8;
						");
						$this->api->db->query("
							CREATE TABLE `accessibility`
							(
							`offer_id` BIGINT,
							`accessibility_pictogram_id` BIGINT NOT NULL,
							`poi_detail_link` VARCHAR(500),
							PRIMARY KEY (`offer_id`, `accessibility_pictogram_id`)
							) ENGINE=InnoDB CHARACTER SET=utf8;
						");
						$this->api->db->query("
							ALTER TABLE `accessibility` ADD FOREIGN KEY offer_id_idxfk_34 (`offer_id`) REFERENCES `offer` (`offer_id`) ON DELETE CASCADE;
						");
	
						// reset target group foreign keys
						$this->api->db->query("
							ALTER TABLE `target_group_link` DROP FOREIGN KEY `target_group_link_ibfk_2`;
						");
						$this->api->db->query("
							ALTER TABLE `target_group_i18n` DROP FOREIGN KEY `target_group_i18n_ibfk_1`;
						");
	
						// create new institution_location field
						$this->api->db->query("
							ALTER TABLE `offer` ADD COLUMN `institution_location` VARCHAR(500) NULL AFTER `institution`;
						");
	
						// sync target groups
						$this->api->import->sync_target_groups();
	
						// migrate/relink target group: Schulklassen Primarstufe
						$q_tg_link = $this->api->db->get('target_group_link', array('target_group_id' => 7));
						if (mysqli_num_rows($q_tg_link) > 0) {
							while ($row = mysqli_fetch_object($q_tg_link)) {
								$this->api->db->insert('target_group_link', array('offer_id' => $row->offer_id, 'target_group_id' => 12));
							}
						}
	
						// rename category: bookable offer (only german)
						$this->api->db->query("
							UPDATE `category_i18n` SET `body` = 'Buchbares Angebot' WHERE `category_id` = 3 AND `language` = 'de' LIMIT 1
						");
						break;

					/*
					|--------------------------------------------------------------------------
					| Migrate to version 12
					| Activities: Routes, time required in minutes
					|--------------------------------------------------------------------------
					|
					*/
					case 12:
						$this->api->db->query("
							ALTER TABLE `activity` ADD COLUMN `time_required_minutes` INTEGER AFTER `time_required`;
						");
						break;

					/*
					|--------------------------------------------------------------------------
					| Migrate to version 13
					| Activities and product season months
					|--------------------------------------------------------------------------
					|
					*/
					case 13:
						$this->api->db->query("
							ALTER TABLE `activity` ADD COLUMN `season_months` VARCHAR(50) NULL;
						");
						$this->api->db->query("
							ALTER TABLE `product` ADD COLUMN `season_months` VARCHAR(50) NULL;
						");
						$this->api->db->query("
							ALTER TABLE `offer` DROP COLUMN `park_day`;
						");
						$this->api->db->query("
							ALTER TABLE `offer` DROP COLUMN `enjoy_week`;
						");
						break;

					/*
					|--------------------------------------------------------------------------
					| Migrate to version 14
					| Booking season months
					|--------------------------------------------------------------------------
					|
					*/
					case 14:
						$this->api->db->query("
							ALTER TABLE `booking` ADD COLUMN `season_months` VARCHAR(50) NULL;
						");
						break;


			}

			// update db version
			$this->api->db->query("UPDATE `api` SET `version` = ".$version_to." LIMIT 1;");
			
			// show message
			$message = 'Migration to version '.$version_to.' successfully finished.';
			echo $message;

			// log message
			$this->api->logger->info($message);
		}
		else {

			// show message
			$message = 'No valid version number set.';
			echo $message;

			// log error
			$this->api->logger->error($message);

		}
	}


}