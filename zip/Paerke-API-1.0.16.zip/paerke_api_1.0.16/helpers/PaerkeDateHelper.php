<?php

function show_date($date) {
	$return = '';
	
	// date from
	$return .= '<strong>'.$date['date_from']['date'].'</strong> ';
	if (!empty($date['date_from']['hour']) && ($date['date_from']['hour'] != '00')) {
		$return .= $date['date_from']['hour'].":".$date['date_from']['minute'];
	}

	// date to
	if (!empty($date['date_to']) && !empty($date['date_to']['date']) && ($date['date_from'] != $date['date_to'])) {
		$return .= ' - ';
		if ($date['date_from']['date'] != $date['date_to']['date']) {
			$return .= '<strong>'.$date['date_to']['date'].'</strong> ';
		}
		if (!empty($date['date_to']['hour']) && ($date['date_to']['hour'] != '00')) {
			$return .= $date['date_to']['hour'].":".$date['date_to']['minute'];
		}
	}
	
	return $return;
}

function mysql2form($mysql_date) {
	$return = array();
	
	$return['date'] = substr($mysql_date, 0, 10);
	$return['hour'] = substr($mysql_date, 11, 2);
	$return['minute'] = substr($mysql_date, 14, 2);
	
	return $return;
}

function mysql2date($mysql_date, $time = false, $ts = false) {	
	$date = substr($mysql_date, 0, 10);
	$date_time = '';
	if ($time != false) {
		$date_time = ' '.substr($mysql_date, 11);
	}
	
	$date_explode = explode("-", $date);
	
	if (count($date_explode) < 3 || (intval($date_explode[0]) == 0) && (intval($date_explode[1]) == 0) && (intval($date_explode[2]) == 0)) {
		return '';
	}
	
	$date_explode_ts = mktime(0, 0, 0, $date_explode[1], $date_explode[2], $date_explode[0]);
	if ($ts == true) {
		return $date_explode_ts;
	}
	return date('d.m.Y', $date_explode_ts).$date_time;
}