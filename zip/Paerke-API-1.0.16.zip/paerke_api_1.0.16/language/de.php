<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| German language file
|
*/

$lang = array();


$lang['general_from_2'] = "Ab";
$lang['general_to'] = "bis";
$lang['general_all'] = "Alle";
$lang['general_none'] = "Keine";


/**
 * Offer language strings
 */
$lang['offer_filter'] = 'Angebotsfilter';
$lang['offer_category'] = 'Kategorie';
$lang['offer_select_category'] = 'Alle Kategorien';
$lang['offer_date_from'] = 'Datum von';
$lang['offer_date_to'] = 'Datum bis';
$lang['offer_search'] = 'Suche';
$lang['offer_reset'] = 'L&ouml;schen';
$lang['offer_list'] = 'Angebotsliste';
$lang['offer_not_found'] = 'Keine Angebote gefunden.';
$lang['offer_map'] = 'Karte';
$lang['offer_description'] = 'Beschreibung';
$lang['offer_detail'] = 'Details';
$lang['offer_poi'] = 'Wegpunkte';


$lang['offer_category'] = 'Kategorie';
$lang['offer_maincategory'] = 'Hauptkategorie';
$lang['offer_subcategory'] = 'Unterkategorie';
$lang['offer_subcategories'] = 'Unterkategorien';
$lang['offer_select_category'] = 'Alle Angebote';
$lang['offer_selected_category'] = '%s Kategorien ausgew&auml;hlt';
$lang['offer_select_park'] = 'Park ausw&auml;hlen';
$lang['offer_select_language'] = 'Sprache ausw&auml;hlen';
$lang['offer_default_data'] = 'Allgemeine Daten';
$lang['offer_details'] = 'Details';
$lang['offer_files'] = 'Dateien';
$lang['offer_addresses'] = 'Adressen';
$lang['offer_attributes'] = 'Eigenschaften';
$lang['offer_target_group'] = 'Zielgruppen';
$lang['offer_telephone'] = 'Telefon';
$lang['offer_barrier_free'] = 'Barrierefrei';
$lang['offer_learning_opportunity'] = 'Bildungsangebot';
$lang['offer_child_friendly'] = 'Kinderfreundlich';
$lang['offer_park_day'] = "Tag der P&auml;rke";
$lang['offer_enjoy_week'] = "Genusswoche";
$lang['offer_public_transport_stop'] = 'Anreise &Ouml;V (Haltestelle)';
$lang['offer_contact'] = 'Kontaktinformationen';
$lang['offer_upload_image'] = 'Upload Bild';
$lang['offer_links'] = 'Weiterf&uuml;hrende Links';
$lang['offer_upload_pdf'] = 'Upload PDF';
$lang['offer_available_for'] = 'Angebot freigegeben f&uuml;r';
$lang['offer_paerke_ch'] = 'paerke.ch';
$lang['offer_own_park'] = 'Eigener Park';
$lang['offer_switzerland_tourism'] = 'Schweiz Tourismus';
$lang['offer_valid'] = 'G&uuml;ltigkeit des Eintrags';
$lang['offer_valid_from'] = 'G&uuml;ltig von';
$lang['offer_valid_to'] = 'G&uuml;ltig bis';
$lang['offer_signs'] = 'Zeichen';
$lang['offer_images'] = 'Bilder';
$lang['offer_documents'] = 'Dokumente (PDF, Excel, Word, usw.)';
$lang['offer_documents_public'] = 'Dokumente';
$lang['offer_main_image'] = 'Hauptbild';
$lang['offer_image'] = 'Bild %s';
$lang['offer_delete_success'] = 'Das Angebot wurde erfolgreich gel&ouml;scht';
$lang['offer_delete_error'] = 'Fehler beim L&ouml;schen des Angebots';
$lang['offer_category_update_success'] = 'Die Kategorie wurde erfolgreich aktualisiert.';
$lang['offer_delete_image_confirm'] = 'Sind Sie sicher, dass Sie dieses Bild entfernen wollen? Das Bild wird unwiderruflich gel&ouml;scht.';
$lang['offer_document'] = 'Dokument %s';
$lang['offer_contact_change'] = 'Kontakt &auml;ndern';
$lang['offer_document_title'] = 'Name des Dokuments';
$lang['offer_delete_document_confirm'] = 'Sind Sie sicher, dass Sie dieses Dokument entfernen wollen? Das Dokument wird unwiderruflich gel&ouml;scht';
$lang['offer_link_url'] = 'URL';
$lang['offer_link_title'] = 'Bezeichnung';
$lang['offer_link_add'] = 'Link hinzuf&uuml;gen';
$lang['offer_link_remove_confirm'] = 'Sind Sie sicher, dass Sie diesen Link entfernen wollen?';
$lang['offer_park'] = 'Park/Organisation';
$lang['offer_additional_info'] = 'Zusatzinformationen';
$lang['offer_valid_infinite'] = 'Unbegrenzt g&uuml;ltig';
$lang['offer_parks_all'] = 'Alle P&auml;rke';
$lang['offer_categories_all'] = 'Alle Kategorien';
$lang['offer_categories'] = 'Kategorien';
$lang['offer_status'] = 'Status';
$lang['offer_status_inactive'] = 'Inaktiv';
$lang['offer_status_active'] = 'Aktiv';
$lang['offer_coordinates'] = 'Koordinaten';
$lang['offer_images_help'] = 'Hier k&ouml;nnen Sie Bilder im JPG, GIF oder PNG-Format hochladen. Ein Bild muss mindestens eine Gr&ouml;sse von 200x100 Pixel haben. Bitte beachten Sie die Urheberrechte der Originalbilder.';
$lang['offer_maps_help'] = 'Um einen Punkt auf der Karte auszuw&auml;hlen k&ouml;nnen Sie die Markierung mit der Maus verschieben oder doppelt auf den gew&uuml;nschten Ort in der Karte klicken. Alternativ k&ouml;nnen Sie auch nach einem Ort suchen.';
$lang['offer_activity_maps_help'] = 'Sie k&ouml;nnen die Route beliebig anpassen, indem Sie die Wegpunkte (grau) mit der Maus ziehen. Mit den weissen, kleineren Markierungen k&ouml;nnen Sie durch Ziehen neue Wegpunkte hinzuf&uuml;gen. Bestehende Wegpunkte k&ouml;nnen &uuml;ber ein Rechtsklick entfernt werden.';
$lang['offer_will_not_be_published_on_myswitzerland'] = 'Kann nicht bei Schweiz Tourismus ver&ouml;ffentlicht werden';
$lang['offer_all_season'] = 'Ganzj&auml;hrig';
$lang['offer_maps_search'] = 'Suche';
$lang['offer_maps_search_go'] = 'Finden';
$lang['offer_maps_choose'] = 'Karte ausw&auml;hlen';
$lang['offer_languages'] = 'Sprachen';
$lang['offer_filter'] = 'Angebotsfilter';
$lang['offer_no_results'] = 'Es wurden keine Angebote zu Ihren Suchkriterien gefunden.';
$lang['offer_subscription_help'] = 'F&uuml;r dieses Angebot ist eine Anmeldung erforderlich.';


/*
| language related fields
*/
$lang['offer_title_description'] = 'Titel &amp; Beschreibung';
$lang['offer_title'] = 'Titel';
$lang['offer_description'] = 'Beschreibung';
$lang['offer_short_description'] = 'Kurzbeschreibung';
$lang['offer_medium_description'] = 'Beschreibung Mittel';
$lang['offer_long_description'] = 'Beschreibung Lang';
$lang['offer_price'] = 'Preis-Infos';
$lang['offer_date_details'] = 'Termindetails';


/*
| Default mask fields
*/
$lang['offer_parkname'] = 'Name des Parks';
$lang['offer_park_event'] = 'Parkveranstaltung';
$lang['offer_park_partner'] = 'Partnerbetrieb des Parks';
$lang['offer_park_partner_event'] = 'Parkpartnerveranstaltung';
$lang['offer_park_partner_booking'] = 'Parkpartnerbetrieb';
$lang['offer_kind_of'] = 'Art der Veranstaltung';
$lang['offer_institution'] = 'Institution/Lokalit&auml;t';
$lang['offer_street'] = 'Strasse';
$lang['offer_place'] = 'Ort';
$lang['offer_location'] = 'Lage';
$lang['offer_date'] = 'Termin';
$lang['offer_dates'] = 'Termine';
$lang['offer_from'] = 'von';
$lang['offer_to'] = 'bis';
$lang['offer_at'] = 'um';
$lang['offer_oclock'] = 'Uhr';


/*
| Insert mask 1
*/
$lang['offer_title_event'] = 'Veranstaltungsdaten';
$lang['offer_add_date'] = 'Weiteren Termin hinzuf&uuml;gen';
$lang['offer_event_location'] = 'Veranstaltungsort';
$lang['offer_event_organiser'] = 'Veranstalter';
$lang['offer_subscription'] = 'Anmeldung';
$lang['offer_subscription_mandatory'] = 'Anmeldung erforderlich';
$lang['offer_subscription_contact'] = 'Anmeldung bei';
$lang['offer_subscription_link'] = 'Anmeldungslink';
$lang['offer_subscription_recommended'] = 'Empfohlen';
$lang['offer_subscription_details'] = "Weitere Informationen zur Anmeldung";
$lang['offer_local'] = 'Lokal';
$lang['offer_regional'] = 'Regional';
$lang['offer_national'] = 'National';
$lang['offer_international'] = 'International';
$lang['offer_misc'] = 'Verschiedenes';
$lang['offer_delete_date_confirm'] = 'Sind Sie sicher, dass Sie dieses Datum entfernen wollen?';
$lang['offer_location_details'] = "Ortsdetails";
$lang['offer_subscription_subscribe_now'] = 'Jetzt online anmelden';



/*
| Insert mask 2
*/
$lang['offer_product_offerer'] = 'Anbieter/Einrichtung';
$lang['offer_opening_hours'] = '&Ouml;ffnungszeiten';
$lang['offer_supplier'] = 'Anbieter';
$lang['offer_availability'] = 'Produkt erh&auml;ltlich von/bis';
$lang['offer_available_from'] = 'Erh&auml;ltlich von';
$lang['offer_available_to'] = 'Erh&auml;ltlich bis';
$lang['offer_supplier_add'] = 'Anbieter hinzuf&uuml;gen';
$lang['offer_contact_remove_confirm'] = 'Sind Sie sicher, dass Sie diese Kontakt-Zuweisung entfernen wollen?';
$lang['offer_infrastructure'] = 'Infrastruktur';
$lang['offer_number_of_rooms'] = 'Anzahl Zimmer';
$lang['offer_rooms'] = '%s Zimmer';
$lang['offer_conference_room'] = 'Seminarraum';
$lang['offer_playground'] = 'Spielplatz';
$lang['offer_picnic_place'] = 'Picknickplatz';
$lang['offer_fireplace'] = 'Feuerstelle';
$lang['offer_washroom'] = 'WC';
$lang['offer_other_infrastructure'] = 'Sonstige Infrastruktur';


/*
| Insert mask 3
*/
$lang['offer_organizer'] = 'Organisator';
$lang['offer_execution_times'] = 'Durchf&uuml;hrungsdaten/-zeitraum';
$lang['offer_accommodation'] = '&Uuml;bernachtungsm&ouml;glichkeiten';
$lang['offer_accommodation_add'] = '&Uuml;bernachtungsm&ouml;glichkeit hinzuf&uuml;gen';
$lang['offer_number_of_people_groups'] = 'Personenanzahl bei Gruppenangeboten';
$lang['offer_number_of_people_individual'] = 'Personenanzahl f&uuml;r Individualpauschalen';
$lang['offer_min_subscriber'] = 'Teilnehmerzahl min.';
$lang['offer_max_subscriber'] = 'Teilnehmerzahl max.';
$lang['offer_benefits'] = 'Leistungen';
$lang['offer_requirements'] = 'Anforderungen';


/*
| Insert mask 4 (Activity)
*/
$lang['offer_safety_instructions'] = 'Sicherheitshinweise';
$lang['offer_signalization'] = "Signalisation";
$lang['offer_material_rent'] = 'Materialmiete';
$lang['offer_catering_informations'] = 'Verpflegungsm&ouml;glichkeiten';
$lang['offer_saison'] = 'Saison';
$lang['offer_start_place'] = 'Startort';
$lang['offer_goal_place'] = 'Zielort';
$lang['offer_altitude'] = 'H&ouml;he';
$lang['offer_route_info'] = 'Routeninformationen';
$lang['offer_route_length'] = 'Routenl&auml;nge';
$lang['offer_untarred_route_length'] = 'Anteil ungeteerte Wegstrecke';
$lang['offer_altitude_differential'] = 'H&ouml;hendifferenz';
$lang['offer_altitude_ascent'] = 'H&ouml;henmeter Aufstieg';
$lang['offer_altitude_descent'] = 'H&ouml;henmeter Abstieg';
$lang['offer_altitude_meter'] = 'm';
$lang['offer_route_length_km'] = 'km';
$lang['offer_time_required'] = 'Zeitbedarf';
$lang['offer_level_technics'] = 'Schwierigkeitsgrad Technik';
$lang['offer_level_condition'] = 'Schwierigkeitsgrad Kondition';
$lang['offer_time_required_2h'] = '<2h';
$lang['offer_time_required_2_4h'] = '2-4h';
$lang['offer_time_required_4h'] = '>4h';
$lang['offer_easy'] = 'Leicht';
$lang['offer_average'] = 'Mittel';
$lang['offer_difficult'] = 'Schwer';
$lang['offer_route'] = 'Route';
$lang['offer_activity_location'] = 'Lage / Startort';


/*
| Pagination
*/
$lang['pagination_prev'] = '&laquo; Zur&uuml;ck';
$lang['pagination_next'] = 'Weiter &raquo;';
$lang['back_to_overview'] = '&laquo; Zur&uuml;ck zur &Uuml;bersicht';
$lang['back_to_route'] = '&laquo; Zur&uuml;ck zur Route';


/*
| Swissmap
*/
$lang['swissmap_basemap'] = 'Hintergrundkarte';
$lang['swissmap_swissimage'] = 'Luftbild';
$lang['swissmap_pixelkarte'] = 'Landeskarten';
$lang['swissmap_hybrid'] = 'Hybrid';

$lang['swissmap_zoom_in'] = 'Vergr&ouml;ssern';
$lang['swissmap_zoom_out'] = 'Verkleinern';
$lang['swissmap_select_all_parks'] = 'Alle P&auml;rke';
$lang['swissmap_home'] = 'Home';
$lang['swissmap_back'] = 'Zur&uuml;ck';
$lang['swissmap_next'] = 'Vorw&auml;rts';
$lang['swissmap_print'] = 'Drucken';
$lang['swissmap_help'] = 'Hilfe';
$lang['swissmap_show_sidebar'] = 'Seitenleiste einblenden';
$lang['swissmap_hide_sidebar'] = 'Seitenleiste ausblenden';
$lang['swissmap_show_legend'] = 'Legende einblenden';
$lang['swissmap_hide_legend'] = 'Legende ausblenden';
$lang['swissmap_show_overview'] = '&Uuml;bersichtskarte einblenden';
$lang['swissmap_hide_overview'] = '&Uuml;bersichtskarte ausblenden';
$lang['swissmap_close'] = 'Schliessen';
$lang['swissmap_baseinfo'] = 'Basis-Informationen';
$lang['swissmap_coordinates'] = 'Landeskoordinaten';
$lang['swissmap_tools'] = 'Werkzeuge';
$lang['swissmap_tools_none'] = "Kein Werkzeug";
$lang['swissmap_tools_point'] = "Punkt";
$lang['swissmap_tools_distance'] = "Distanz";
$lang['swissmap_tools_area'] = "Fläche";
$lang['swissmap_tools_result'] = "Messergebnis";
$lang['swissmap_tools_choose_tool'] = "Wählen Sie ein Werkzeug aus.";
$lang['swissmap_search'] = 'Suche nach Ort, Kanton, ...';
$lang['swissmap_home_title'] = 'Ganze Karte anzeigen';
$lang['swissmap_back_title'] = 'Vorheriger Kartenausschnitt';
$lang['swissmap_next_title'] = 'N&auml;chster Kartenausschnitt';
$lang['swissmap_tools_title'] = "Werkzeuge zum Messen";
$lang['swissmap_print_title'] = 'Druckansicht';
$lang['swissmap_help_title'] = 'Hilfe aufrufen';
$lang['swissmap_offers'] = 'Angebote';
$lang['swissmap_all_offers'] = 'Alle Angebote';
$lang['swissmap_source_swisstopo'] = 'Quelle: Bundesamt für Landestopographie';
$lang['swissmap_loading'] = 'Lädt...';
$lang['swissmap_cancel'] = 'Abbrechen';