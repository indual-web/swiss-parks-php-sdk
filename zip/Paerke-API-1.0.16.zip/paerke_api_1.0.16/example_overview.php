<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API Example
| http://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| Example for displaying a list of offers using the Paerke API
|
*/

// Include API
include_once("PaerkeAPI.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />

		<title>Paerke.ch API Example</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
		<link rel="stylesheet" type="text/css" href="http://angebote.paerke.ch/css/jquery-ui-custom.css" media="all" />
		<style type="text/css">
			body {
				margin: 0;
				padding: 0;
				font: 12px/18px Helvetica, Verdana, sans-serif;
				color: #333;
			}

			#siteframe {
				margin: 20px auto;
				width: 800px;
			}
		</style>

		<link rel="stylesheet" type="text/css" media="screen,projection" href="http://www.paerke.ch/api/custom/jquery.multiselect.css" />
		<link rel="stylesheet" type="text/css" media="screen,projection" href="http://www.paerke.ch/we/css/jquery-ui-custom.css" />

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js" type="text/javascript"></script>
		<script src="http://www.paerke.ch/api/custom/jquery.multiselect.min.js" type="text/javascript"></script>
		<link type="text/css" rel="stylesheet" href="http://angebote.paerke.ch/swissmap/swissmap.css">

		<script type="text/javascript">
			$(document).ready(function() {

				// load jquery tabs
				$('#offer_listing_tabs').tabs({ cookie: { expires: 1 } });
				$('#offer_detail_tabs').tabs();

				// make buttons
				$('div.offer_filter input:submit, div.offer_filter button, div.offer_heading button').button();

				// default datepickers
				$('input.datepicker').datepicker({
					dateFormat: 'dd.mm.yy',
					firstDay: 1
				});
			});
		</script>
	</head>
	<body>

		<div id="siteframe">
		<?php
			// Initialize API with default language
			$api = new PaerkeAPI();

			// Check if detail page should be shown
			if ($api->is_offer_detail()) {
				// Show detail page for offer
				$api->show_offer_detail();
			}
			else {
			
				$park_id = $api->is_park_detail();
				
				// show only park offers
				if ($park_id) {
					$api->show_offers_map(NULL, NULL, $park_id);
				}
				else {
					//show list of offers
					$api->show_offers_map(NULL, NULL, NULL, NULL, NULL, FALSE);
				}
			}
		?>
		</div>

	</body>
</html>