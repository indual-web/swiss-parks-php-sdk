<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


// Include API
require("PaerkeAPI.php");

// Initialize API and update local database from XML export
$api = new PaerkeAPI();
$api->update(TRUE);