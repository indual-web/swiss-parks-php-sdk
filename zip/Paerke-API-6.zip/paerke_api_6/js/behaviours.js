/*
|---------------------------------------------------------------
| Netzwerk Schweizer Pärke
| API Angebotsdatenbank
| developed by indual GmbH, Brig (www.indual.ch)
|
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| API javascript
|
*/


$(function() {

	// select2
	$('select.select2').select2({
		minimumResultsForSearch: 2
	});

	// range input
	$('.range').slider({
		range: true,
		min: 0,
		max: 42,
		values: [0, 42],
		slide: function( event, ui ) {
			// set labels
			$('.range_text .minimum').text(ui.values[0]+'km');
			$('.range_text .maximum').text('+ '+ui.values[1]+'km');

			// set hidden inputs
			$('#offer_filter_route_length_min').val(ui.values[0]);
			$('#offer_filter_route_length_max').val(ui.values[1]);
		}
	});

	// datepicker
	if ($('input.datepicker').length > 0) {
		$.datepicker.setDefaults( $.datepicker.regional['de'] );
		$('input.datepicker').datepicker({
			dateFormat: 'dd.mm.yy'
		});
	}

	// mixItUp
	mixWrap = $('#mixItUp');
	mixWrap.find('> div').addClass('mixitup_element');
	mixFilter = $('ul.tags > li:first-child').attr('data-filter');
	mixWrap.mixItUp({
		selectors: {
			target: '.mixitup_element'
		},
		animation: {
			enable: false
		},
		load: {
			filter: mixFilter
		}
	});
	mixWrap.on('mixStart', function(){
		$(this).addClass('is_mixing');
		$(this).addClass('mixed');
	}).on('mixEnd', function(){
		var that = $(this);
		window.setTimeout(function(){
			that.removeClass('is_mixing');
		}, 50);
	});

	// hide boxes
	$('#mixItUp .mix:nth-child(7) ~ .mix').each(function() {
		$(this).addClass('hidden_box');
	});

	// show boxes on click
	$('#mixItUp + .show_all_boxes').click(function() {
		$(this).toggleClass('open');
		$('#mixItUp .mix:nth-child(7) ~ .mix').toggleClass('hidden_box');
		$('#mixItUp').toggleClass('all_boxes');
		if ($(this).hasClass('open') == true) {
			$(this).text('Weniger Anzeigen');
		} else {
			$(this).text('Mehr Anzeigen');
		}
	});

	// add class to small mix-boxes
	$('#mixItUp .mix').each(function() {
		if ($(this).is(':not(:first-child)')) {
			$(this).addClass('small_box');
		}
	});

	// fancybox
	$(".fancybox").fancybox({
		prevEffect: 'none',
		nextEffect: 'none',
		openEffect:	'fade' ,
		helpers: 	{
			title   : {
				type : 'inside'
			},
			buttons : {}
		}
	});

	// portlet slider
	$('.content_left .portlet .picture ~ .picture').parent().bxSlider({
		mode: 'horizontal',
		speed: 700,
		adaptiveHeight: true,
		adaptiveHeightSpeed: 700,
		responsive: true,
		preloadImages: 'all',
		pause: 6000,
		autoStart: false
	});

	// accordion
	$('.accordion_element .accordion_title').click(function(){
		var that = $(this).parent();
		var shown = false;
		if ($(this).parent().hasClass('active') == false) {
			if (!shown) {
				that.find('.accordion_content').show('blind');
				that.addClass('active');
			}
		}
		else {
			$(this).parent().removeClass('active').find('.accordion_content').hide('blind');
		}
	});

});