<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API Example
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| Example for displaying a list of offers using the Paerke API
|
*/

// Include API
include_once("PaerkeAPI.php");

// Initialize API with default language
$api = new PaerkeAPI();

?>
<!DOCTYPE html>
<html lang="de">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<title>Paerke.ch API Example</title>

		<!-- CSS -->
		<link href="css/style.css" rel="stylesheet">
		<link href="css/forms.css" rel="stylesheet">
		<link href="css/modules.css" rel="stylesheet">
		<link href="css/fontastic.css" rel="stylesheet">
		<link href="css/fancybox.css" rel="stylesheet">
		<link type="text/css" rel="stylesheet" href="<?php echo $api->config['base_url']; ?>swissmap/swissmapV2.css">

		<!-- JavaScripts -->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
		<script src="js/jquery.mixitup.js"></script>
		<script src="js/jquery.fancybox.js"></script>
		<script src="js/jquery.bxslider.min.js"></script>
		<script src="js/select2.min.js"></script>
		<script src="js/behaviours.js"></script>

	</head>
	<body>

		<div id="example">
		<?php

			// your park id
			$park_id = 0;

			// filter possibilities
			$example_filter = array(
				'keywords' => '', // filter by keywords
				'contact_is_park_partner' => 0, // 1 == show only offers from park partners
				'target_groups' => array(), // filter by target groups
				'search' => '', // filter by an explicit word
				'offers_barrier_free' => 0, // 1 = barrier free offers
				'offers_learning_opportunity' => 0, // 1 = learning opportunity offers
				'offers_child_friendly' => 0, // 1 = child friendly offers
				'offers_enjoy_week' => 0, // 1 = only enjoy week offers
				'offers_filter_hints' => 0, // 1 = show only hints (Tipps)
				'offers_park_day' => 0, // 1 = only park day offers
			);
			$categories = array(1);

			// Show offer filter
			$api->show_offers_filter($park_id, $categories, $example_filter);

			// Check if detail page should be shown
			if ($api->is_offer_detail()) {
				// Show detail page for offer
				$api->show_offer_detail();
			}
			else {
				// Show list of offers
				$api->show_offers_list($categories, $example_filter);
			}

			$api->show_offers_pagination();
		?>
		</div>

	</body>
</html>
