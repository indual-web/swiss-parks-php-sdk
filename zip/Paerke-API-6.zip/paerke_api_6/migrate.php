<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


// include API
require("PaerkeAPI.php");

// update offer data
$api = new PaerkeAPI();
$api->migrate();