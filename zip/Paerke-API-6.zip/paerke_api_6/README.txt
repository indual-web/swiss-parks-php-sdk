/*
|---------------------------------------------------------------
| PAERKE.CH API
| http://angebote.paerke.ch/
|---------------------------------------------------------------
*/


# ---
# About
# ---

This API provides functionality to import and show offers corresponding to your export configuration.
It is a PHP/MySQL API which runs on your own webserver and it is customizable to your own needs.


# ---
# First setup
# ---

1. Download current version from http://angebote.paerke.ch/, page "export"
2. Upload the folder to a public directory on your webserver
3. Create new MySQL database
4. Import database.sql
5. Setup your configuration parameters (see below for more instructions)
6. Start first import of your offers, open http://YOUR-DOMAIN/Path-To-API/cron.php
7. Create your offer pages with your content management system or PHP environment
   - example.php shows how to use the API
   - Copy /classes/PaerkeView.php and paste into /custom folder to create your own view.
     Set the configuration var $config['class_view'] to init your custom view.
8. Create and call the cronjob to update offers permanently (see cron.sh)


# ---
# Upgrade to the latest version
# ---

1. Download latest API from http://angebote.paerke.ch/
2. Replace all files except your own config.php and the PaerkeAPI.php files
3. Execute the migration automatically, open: http://YOUR-DOMAIN/Path-To-API/migrate.php
4. Check your log if migration was successfully.


# ---
# Configuration
# ---

Before you can use the API, you need to set a few configuration parameters:
1. Open /PaerkeAPI.php and set the absolute and web path
2. Open /config.php
   - Set the API Hash Key from your export configuration (http://angebote.paerke.ch/settings)
   - Set the connection parameters for your MySQL database
Never overwrite these files while upgrading.