<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API Example
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
|
| Example for displaying a list of offers using the Paerke API
|
*/

// Include API
include_once("PaerkeAPI.php");

// Initialize API with default language
$api = new PaerkeAPI();

?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<title>Paerke.ch API Example</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
		<link rel="stylesheet" type="text/css" href="<?php echo $api->config['base_url']; ?>css/jquery-ui-custom.css" media="all" />
		<style type="text/css">
			body {
				margin: 0;
				padding: 0;
				font: 12px/18px Helvetica, Verdana, sans-serif;
				color: #333;
			}

			#siteframe {
				width: auto;
			}
		</style>

		<link rel="stylesheet" type="text/css" media="screen,projection" href="<?php echo $api->config['base_url']; ?>css/jquery.multiselect.css" />
		<link rel="stylesheet" type="text/css" media="screen,projection" href="<?php echo $api->config['base_url']; ?>css/jquery-ui-custom.css" />

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js" type="text/javascript"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js" type="text/javascript"></script>
		<script src="<?php echo $api->config['base_url']; ?>js/jquery.multiselect.min.js" type="text/javascript"></script>
		<script src="<?php echo $api->config['base_url']; ?>js/jquery.ui.touch-punch.min.js" type="text/javascript"></script>
		<link type="text/css" rel="stylesheet" href="<?php echo $api->config['base_url']; ?>swissmap/swissmapV2.css">

		<script type="text/javascript">
			$(document).ready(function() {

				// load jquery tabs
				$('#offer_listing_tabs').tabs({ cookie: { expires: 1 } });
				$('#offer_detail_tabs').tabs();

				// make buttons
				$('div.offer_filter input:submit, div.offer_filter button, div.offer_heading button').button();

				// default datepickers
				$('input.datepicker').datepicker({
					dateFormat: 'dd.mm.yy',
					firstDay: 1
				});
			});
		</script>
	</head>
	<body>

		<div id="siteframe">
		<?php

			// your park id
			$park_id = 0;

			// filter possibilities
			$example_filter = array(
				'keywords' => '', // filter by keywords
				'contact_is_park_partner' => 0, // 1 == show only offers from park partners
				'target_groups' => array(), // filter by target groups
				'search' => '', // filter by an explicit word
				'offers_barrier_free' => 0, // 1 = barrier free offers
				'offers_learning_opportunity' => 0, // 1 = learning opportunity offers
				'offers_child_friendly' => 0, // 1 = child friendly offers
				'offers_enjoy_week' => 0, // 1 = only enjoy week offers
				'offers_filter_hints' => 0, // 1 = show only hints (Tipps)
				'offers_park_day' => 0, // 1 = only park day offers
			);

			// Check if detail page should be shown
			if ($api->is_offer_detail()) {
				// Show detail page for offer
				$api->show_offer_detail();
			}
			else {

				$api->show_offers_filter(NULL, NULL, $example_filter);

				// show only park offers
				if ($api->is_park_detail()) {
					$api->show_offers_map(NULL, $example_filter, $park_id);
				}
				else {
					//show list of offers
					$api->show_offers_map(NULL, $example_filter, $park_id, NULL, NULL, FALSE);
				}
			}
		?>
		</div>

	</body>
</html>
