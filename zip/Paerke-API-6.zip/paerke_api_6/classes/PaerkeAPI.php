<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * API Version
 */
define('API_VERSION', 6);



/**
 * Constants
 */
define('DEFAULT_LANGUAGE', (isset($config['default_language']) ? $config['default_language'] : 'de'));
define('CATEGORY_EVENT', 1);
define('CATEGORY_PRODUCT', 2);
define('CATEGORY_BOOKING', 3);
define('CATEGORY_ACTIVITY', 4);
define('CATEGORY_PROJECT', 1000);
define('CATEGORY_RESEARCH', 5000);

define('OFFER_STATUS_STUB', 0);
define('OFFER_STATUS_INACTIVE', 1);
define('OFFER_STATUS_ACTIVE', 2);

define('FORM_PREFIX', '');
define('PARAM_PREFIX', '');



/**
 * Main API class
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeAPI {


	/**
	 * API Hash
	 */
	private $hash;


	/**
	 * Configuration items
	 */
	public $config;


	/**
	 * Current language
	 */
	public $language = DEFAULT_LANGUAGE;


	/**
	 * API info from DB
	 */
	private $api;


	/**
	 * Offer object
	 */
	public $offer;


	/**
	 * Filter object and data
	 */
	private $filter = FALSE;
	private $filter_data = array();


	/**
	 * Language object
	 */
	public $lang;


	/**
	 * View object
	 */
	private $view;


	/**
	 * Pagination
	 */
	private $page;
	private $total;


	/**
	 * Session
	 */
	public $session_name;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string
	 * @param  string
	 * @return void
	 */
	function __construct($language = DEFAULT_LANGUAGE, $hash = NULL) {

		// Get global config
		if (!isset($config)) {
			include(ABSOLUTE_PATH.'/config.php');
		}
		if (!empty($config)) {

			// init project status
			$config['project_status_de'] = array(
					1 => 'Geplant',
					2 => 'Laufend',
					3 => 'Abgeschlossen',
			);
			$config['project_status_fr'] = array(
					1 => 'Planifié',
					2 => 'Actuel',
					3 => 'Terminé',
			);
			$config['project_status_it'] = array(
					1 => 'Pianificato,',
					2 => 'In corso',
					3 => 'Concluso',
			);
			$config['project_status_en'] = array(
					1 => 'Planned',
					2 => 'Ongoing',
					3 => 'Finished',
			);

			// init main settings
			$this->hash = $hash ? $hash : $config['api_hash'];
			$this->config = $config;
			$this->language = $language;
			$this->lang = new PaerkeLanguage($this->language);
			$this->offer = new PaerkeOffer($this);

			// set view
			if (class_exists($this->config['class_view'])) {
				$this->view = new $this->config['class_view']($this);
			}
			else {
				$this->view = new PaerkeView($this);
			}

			// init setup
			$this->_setup();

			if ($this->config['use_sessions']) {
				$this->session_name = $this->config['session_name'].'_'.md5($_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"]);
			}

			$paramname = FORM_PREFIX.'reset';
			if (isset($_GET[$paramname])) {
				$this->_reset_filter();
			}
			else {
				$this->_init_filter();
			}

		}
	}


	/**
	 * Updates database from XML export
	 *
	 * @access public
	 * @return void
	 */
	public function update($force = FALSE) {

		$xml = $this->config['xml_export_offer_url'].$this->hash;
		$xml_map_layer = $this->config['xml_export_map_layer_url'].$this->hash;
		$xml_active_offers = $this->config['xml_export_active_offers'].$this->hash;

		// Import data from XML into database
		$importer = new PaerkeImport();
		$importer->import($xml, $force);
		$importer->import_map_layers($xml_map_layer);
		$importer->clean_up_offers($xml_active_offers);

	}


	/**
	 * Migrate database updates
	 *
	 * @access public
	 * @return void
	 */
	public function migrate() {

		// Migrate database to newer versions
		$migration = new PaerkeMigration($this);

	}


	/**
	 * Displays filter for offers
	 *
	 * @access public
	 * @return void
	 */
	public function show_offers_filter($park_id = NULL, $categories = array(), $additional_infos = array()) {

		if (!$this->is_offer_detail() || $this->config['always_show_filter'] == TRUE) {

			// get all offers and count activities and projects
			$activities_count = 0;
			$projects_count = 0;
			$offers_count = $this->_get_offers($categories, NULL, NULL, $additional_infos, $park_id, FALSE, TRUE, TRUE);
			$activities_count = $offers_count->activity_count;
			$projects_count = $offers_count->project_count;

			// prepare categories for select
			if (empty($park_id)) {
				$flat_categories = $this->_prepare_categories($categories, TRUE);
			}
			$categories = is_array($categories) ? $categories : array($categories);
			$first = reset($categories);
			if (count($categories) == 0 || (count($categories) == 1 && empty($first))) {
				$categories = FALSE;
			}
			$categories = $this->_prepare_categories($categories, FALSE, $additional_infos);
			$category_links = $this->offer->get_all_category_links();
			$categories = $this->_format_categories_for_select($categories, $category_links, 0, 0, TRUE);

			// check if route filter should be displayed (has enough routes, and is activated)
			$show_route_filter = FALSE;
			if (($this->config['show_route_filter'] == TRUE) && ($activities_count > 0)) {
				$show_route_filter = TRUE;
			}

			// check if project filter should be displayed (has enough projects, and is activated)
			$show_project_filter = FALSE;
			if ($projects_count > 0) {
				$show_project_filter = TRUE;
			}

			// prepare parks/users for select
			$users = array();
			if (empty($park_id)) {
				$users = $this->offer->get_all_users($flat_categories, $additional_infos);
			}

			// load view
			$this->view->show_offers_filter(array('categories' => $categories, 'selected' => $this->filter_data, 'filter' => $this->filter, 'users' => $users, 'show_route_filter' => $show_route_filter, 'show_project_filter' => $show_project_filter));

		}
	}


	/**
	 * Displays list of offers (optionally filtered)
	 *
	 * @access public
	 * @param  integer
	 * @return void
	 */
	public function show_offers_list($categories = array(), $additional_infos = array(), $park_id = NULL) {

		if (!$this->is_offer_detail()) {
			$this->page = 1;
			$paramname = PARAM_PREFIX.'page';
			if (isset($_GET[$paramname]) && $_GET[$paramname] >= 1) {
				$this->page = $_GET[$paramname];
				if ($this->config['use_sessions']) {
					$_SESSION[$this->session_name]['page'] = $this->page;
				}
			}
			else if ($this->config['use_sessions'] && isset($_SESSION[$this->session_name]['page']) && $_SESSION[$this->session_name]['page'] >= 1) {
				$this->page = $_SESSION[$this->session_name]['page'];
			}

			// get offers and total
			$offers = $this->_get_offers($categories, $this->page, $this->config['offers_per_page'], $additional_infos, $park_id, FALSE, TRUE);
			$this->total = ceil($offers['total'] / $this->config['offers_per_page']);
			if ($this->total > $this->config['offers_per_page']) {
				$offset = ($this->page-1) * $this->config['offers_per_page'];
			}

			// show offers list
			$this->view->show_offers_list($offers);
		}

	}


	/**
	 * Displays list of poi (get by id)
	 *
	 * @access public
	 * @param integer
	 * @return void
	 */
	public function show_offer_poi_list($poi = NULL) {
		$offers = array();

		if (is_array($poi) && !empty($poi)) {
			foreach ($poi as $offer_id) {
				$poi_offer = $this->offer->get_offer($offer_id);
				if (!empty($poi_offer)) {
					array_push($offers, $poi_offer);
				}
			}
		}

		return $offers;
	}


	/**
	 * Displays pagination
	 *
	 * @access public
	 * @return void
	 */
	public function show_offers_pagination() {

		if (!$this->is_offer_detail()) {
			$this->view->show_pagination($this->page, $this->total);
		}
	}


	/**
	 * Displays map of offers (optionally filtered)
	 *
	 * @access public
	 * @param  integer
	 * @return void
	 */
	public function show_offers_map($categories = array(), $additional_infos = array(), $park_id = NULL, $show_layers_at_start = FALSE, $custom_map_layers = array()) {
		if (!$this->is_offer_detail()) {
			$this->_load_maps_api();

			// set park
			$this->_set_selected_park($park_id);

			// get offers and total
			$offers = $this->_get_offers($categories, NULL, NULL, $additional_infos, $park_id, FALSE, FALSE, FALSE, TRUE);
			$this->view->show_offers_map($offers['data'], $show_layers_at_start, $custom_map_layers);
		}
	}


	/**
	 * Display detail of offer
	 *
	 * @access public
	 * @param  integer
	 * @return void
	 */
	public function show_offer_detail() {

		if ($this->is_offer_detail()) {
			$this->_load_maps_api();

			$paramname = PARAM_PREFIX.'offer';
			$offer_id = intval($_GET[$paramname]);
			$offer = $this->offer->get_offer($offer_id);

			$this->_set_selected_park($offer->park_id);

			$this->view->show_offer_detail($offer);
		}
	}


	/**
	 * Returns if detail page should be displayed
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_offer_detail() {
		$paramname = PARAM_PREFIX.'offer';

		if (isset($_GET[$paramname])) {
			$offer_id = intval($_GET[$paramname]);
			return $this->offer->offer_exists($offer_id);
		}

		return FALSE;
	}


	/**
	 * Returns if detail page should be displayed
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_park_detail() {
		$paramname = PARAM_PREFIX.'park';

		if (isset($_GET[$paramname])) {
			$park_id = intval($_GET[$paramname]);

			$user_id = $this->config['parkperimeter_id_to_user_id'][$park_id];

			if (isset($user_id)) {
				return $user_id;
			}
		}

		return FALSE;
	}


	/**
	 * Returns if filter is active
	 *
	 * @access public
	 * @return boolean
	 */
	public function is_filter_activated() {
		return $this->filter;
	}


	/**
	 * Returns filter data
	 *
	 * @access public
	 * @return boolean
	 */
	public function get_filter_data() {
		return $this->filter_data;
	}


	/**
	 * Get list of offers
	 *
	 * @access public
	 * @param  integer
	 * @return mixed
	 */
	public function get_offers_list($categories = array(), $page = NULL, $limit = NULL, $additional_infos = array(), $park_id = NULL, $ignore_filter = FALSE, $return_minimal = FALSE, $only_count_categories = FALSE, $map_mode = FALSE) {
		return $this->_get_offers($categories, $page, $limit, $additional_infos, $park_id, $ignore_filter, $return_minimal, $only_count_categories, $map_mode);
	}


	/**
	 * Get offer details
	 *
	 * @access public
	 * @param  integer
	 * @return mixed
	 */
	public function get_offer_detail($offer_id) {
		return $this->offer->get_offer($offer_id);
	}


	/**
	 * Get list of categories
	 *
	 * @access public
	 * @return mixed
	 */
	public function get_categories_list() {
		return $this->offer->get_all_categories();
	}


	/**
	 * Get list of categories preformatted for select inputs
	 *
	 * @access public
	 * @return mixed
	 */
	public function get_categories_list_for_select() {
		// Prepare categories for select
		$categories = $this->_prepare_categories();
		$category_links = $this->offer->get_all_category_links();
		$categories = $this->_format_categories_for_select($categories, $category_links, 0);

		return $categories;
	}


	/**
	 * Setup process
	 *
	 * @access private
	 * @return void
	 */
	private function _setup() {
		$this->_security_checks();

		$db = new PaerkeMySQL($this->config['db_hostname'], $this->config['db_username'], $this->config['db_password'], $this->config['db_database']);
		$q_api = $db->get('api');

		if ($q_api) {
			if (mysqli_num_rows($q_api) > 0) {
				$this->api = mysqli_fetch_object($q_api);
			}
			else {
				$this->api->initialized = false;
				$this->api->version = API_VERSION;

				$db->insert('api', (array)$this->api);
			}

			if (version_compare(API_VERSION, $this->api->version)) {
				$logger = new PaerkeLog();
				$logger->info('The current API version is out of date. Please update database.');
			}

			if (!$this->api->initialized) {

				//Initalize API
				$xml = $this->config['xml_export_offer_url'].$this->hash;
				$xml_map_layer =  $this->config['xml_export_map_layer_url'].$this->hash;

				// Import data from XML into database
				$importer = new PaerkeImport();
				$importer->import($xml);
				$importer->import_map_layers($xml_map_layers);

				$this->api->initialized = true;
				$db->update('api', array('initialized' => 1));
			}
		}
		else {
			die("API could not be initialized.");
		}
	}


	/**
	 * Set current selected park
	 *
	 * @access private
	 * @param mixed $park_id
	 * @return void
	 */
	private function _set_selected_park($park_id) {

		if (is_numeric($park_id) && $park_id > 0 && $this->config['use_sessions']) {
			$_SESSION[$this->session_name]['selectedPark'] = $this->offer->parkAbbreviations[$park_id];
		}
		else {
			unset($_SESSION[$this->session_name]['selectedPark']);
		}

	}


	/**
	 * Validate hash
	 *
	 * @access private
	 * @return void
	 */
	private function _validate_hash() {
		$validate = @file_get_contents($this->config['xml_export_url'].'validate/'.$this->hash);

		if ($validate == "Valid") {
			return TRUE;
		}
		else if (!empty($this->hash) && strlen($this->hash) >= 32) {
			return TRUE;
		}

		return FALSE;
	}


	/**
	 * Init filter
	 *
	 * @access private
	 * @return void
	 */
	private function _init_filter() {

		$paramname = FORM_PREFIX.'filter';
		$post_data = isset($_POST[$paramname]) ? $_POST[$paramname] : NULL;

		$fields = array('categories', 'date_from', 'date_to', 'search', 'park_id', 'time_required', 'level_technics', 'level_condition', 'route_length_min', 'route_length_max', 'project_status');

		foreach ($fields as $field) {

			$this->filter_data[$field] = NULL;

			if (isset($post_data[$field])) {
				$this->filter_data[$field] = $post_data[$field];
				$this->filter = TRUE;
				if ($this->config['use_sessions']) {
					unset($_SESSION[$this->session_name]['page']);
				}
			}
			else if ($this->config['use_sessions'] && (isset($_SESSION[$this->session_name]['filter'][$field]) && !empty($_SESSION[$this->session_name]['filter'][$field]))) {
				$this->filter_data[$field] = $_SESSION[$this->session_name]['filter'][$field];
				$this->filter = TRUE;
			}
		}

		// special case: empty categories
		if (!isset($post_data['categories'])) {
			unset($this->filter_data['categories']);
		}

		if ($this->config['use_sessions']) {
			$_SESSION[$this->session_name]['filter'] = $this->filter_data;
		}
	}


	/**
	 * Reset filter
	 *
	 * @access private
	 * @return void
	 */
	private function _reset_filter() {

		$this->filter_data = array();
		if ($this->config['use_sessions']) {
			unset($_SESSION[$this->session_name]['filter']);
			unset($_SESSION[$this->session_name]['page']);
		}

	}


	/**
	 * Get offers
	 *
	 * @access public
	 * @param mixed $categories
	 * @param mixed $park_id
	 * @return void
	 */
	public function get_offers($categories, $park_id) {
		return $this->_get_offers($categories, NULL, NULL, NULL, $park_id);
	}


	/**
	 * Get offers
	 *
	 * @access private
	 * @param array $categories (default: array())
	 * @param mixed $page (default: NULL)
	 * @param array $additional_infos (default: array())
	 * @param mixed $park_id (default: NULL)
	 * @param mixed $ignore_filter (default: FALSE)
	 * @return void
	 */
	private function _get_offers($categories = array(), $page = NULL, $limit = NULL, $additional_infos = array(), $park_id = NULL, $ignore_filter = FALSE, $return_minimal = FALSE, $only_count_categories = FALSE, $map_mode = FALSE) {

		// init filter
		$filter = array();
		foreach ($this->filter_data as $field => $value) {
			if (!empty($value)) {
				$fieldname = substr($field, strlen(FORM_PREFIX), strlen($field));
				$filter[$fieldname] = $value;
			}
		}

		if ($ignore_filter) {
			$filter = array();
		}

		// overwrite filter fields
		if (!empty($categories) && !isset($filter['categories'])) {
			$filter['categories'] = $categories;
		}

		// offer settings
		if (isset($additional_infos['offer_settings']) && !empty($additional_infos['offer_settings'])) {
			$filter['offer_settings'] = $additional_infos['offer_settings'];
		}

		// target groups
		if (isset($additional_infos['target_groups']) && !empty($additional_infos['target_groups'])) {
			$filter['target_groups'] = $additional_infos['target_groups'];
		}

		// search words
		if (isset($additional_infos['search']) && !empty($additional_infos['search'])) {
			$filter['search'] = $additional_infos['search'];
		}

		// order_by
		if (isset($additional_infos['order_by']) && !empty($additional_infos['order_by'])) {
			$filter['order_by'] = $additional_infos['order_by'];
		}

		// textOfferSearch
		if (isset($additional_infos['textOfferSearch']) && !empty($additional_infos['textOfferSearch'])) {
			$filter['search'] .= $additional_infos['textOfferSearch'];
		}

		// offers_barrier_free
		if (isset($additional_infos['offers_barrier_free']) && !empty($additional_infos['offers_barrier_free'])) {
			$filter['barrier_free'] = $additional_infos['offers_barrier_free'];
		}

		// offers_learning_opportunity
		if (isset($additional_infos['offers_learning_opportunity']) && !empty($additional_infos['offers_learning_opportunity'])) {
			$filter['learning_opportunity'] = $additional_infos['offers_learning_opportunity'];
		}

		// offers_child_friendly
		if (isset($additional_infos['offers_child_friendly']) && !empty($additional_infos['offers_child_friendly'])) {
			$filter['child_friendly'] = $additional_infos['offers_child_friendly'];
		}

		// offers_park_day
		if (isset($additional_infos['offers_park_day']) && !empty($additional_infos['offers_park_day'])) {
			$filter['park_day'] = $additional_infos['offers_park_day'];
		}

		// offers_enjoy_week
		if (isset($additional_infos['offers_enjoy_week']) && !empty($additional_infos['offers_enjoy_week'])) {
			$filter['enjoy_week'] = $additional_infos['offers_enjoy_week'];
		}

		// offer_filter_hints
		if (isset($additional_infos['offers_filter_hints'])) {
			$filter['is_hint'] = $additional_infos['offers_filter_hints'];
		}

		// keywords
		if (isset($additional_infos['keywords'])) {
			$filter['keywords'] = $additional_infos['keywords'];
		}

		// contact_is_park_partner
		if (isset($additional_infos['contact_is_park_partner'])) {
			$filter['contact_is_park_partner'] = $additional_infos['contact_is_park_partner'];
		}

		// offers
		if (isset($additional_infos['offers'])) {
			$filter = array();
			foreach ($this->filter_data as $field => $value) {
				if (!empty($value)) {
					$fieldname = substr($field, strlen(FORM_PREFIX), strlen($field));
					$filter[$fieldname] = $value;
				}
			}
			$filter['offers'] = $additional_infos['offers'];
		}

		// park id
		if (!empty($park_id)) {
			$filter['park_id'] = $park_id;
		}

		// get offset and limit
		$offset = 0;
		if (!empty($page) && is_numeric($page)) {
			$offset = ($page - 1) * $this->config['offers_per_page'];
		}

		return $this->offer->get_offers($filter, $limit, $offset, $return_minimal, $only_count_categories, $map_mode);
	}


	/**
	 * Load map api
	 *
	 * @access private
	 * @return void
	 */
	private function _load_maps_api() {
		echo '<script type="text/javascript">var dojoConfig = { locale: "'.$this->language.'", parseOnLoad: true, packages: [{ name: "apl", location : "'.WEB_PATH.'/js/apl" }] };</script>'."\n";
		echo '<link rel="stylesheet" type="text/css" media="screen,projection" href="https://js.arcgis.com/3.8/js/esri/css/esri.css" />';
		echo '<script type="text/javascript" src="https://js.arcgis.com/3.8/"></script>'."\n";
		echo '<script type="text/javascript" src="'.$this->config['base_url'].'swissmap/swissmapV2.js"></script>'."\n";
		echo '<script type="text/javascript" src="'.$this->config['base_url'].'js/maps.arcgis.js"></script>'."\n";
	}


	/**
	 * Format categories for selcect-field
	 *
	 * @access private
	 * @param mixed $categories
	 * @param mixed $category_links
	 * @param mixed $index
	 * @param int $level (default: 0)
	 * @param mixed $optgroups (default: FALSE)
	 * @return void
	 */
	private function _format_categories_for_select($categories, $category_links, $index, $level = 0, $optgroups = FALSE) {
		$return = array();
		if (!empty($categories[$index])) {
			foreach($categories[$index] as $id => $category) {

				if (!empty($category_links) && in_array($id, $category_links) && !($optgroups && (($level == 0 && !in_array($id, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))) || ($level == 1 && in_array($index, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))))) ) {
					$repeat = $optgroups ? ($level-1) : $level;
					$return[$id] = $category;
				}

				if (isset($categories[$id])) {
					$childs = $this->_format_categories_for_select($categories, $category_links, $id, $level+1, $optgroups);
					if (!empty($childs)) {
						if ($optgroups && (($level == 0 && !in_array($id, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))) || ($level == 1 && in_array($index, array(CATEGORY_ACTIVITY, CATEGORY_PRODUCT))))) {
							$return[$category] = $childs;
						}
						else {
							$return += $childs;
						}
					}
				}
			}
		}

		return $return;
	}


	/**
	 * Prepare categories
	 *
	 * @access private
	 * @param mixed $categories (default: FALSE)
	 * @param mixed $flatten (default: FALSE)
	 * @param array $additional_infos (default: array())
	 * @return void
	 */
	private function _prepare_categories($categories = FALSE, $flatten = FALSE, $additional_infos = array()) {
		$return = array();
		$parents = array();

		// get all categories
		$all_categories = $this->offer->get_all_categories($additional_infos);

		// get all parents
		if (is_array($categories) && !empty($categories)) {
			foreach ($categories as $category_id) {
				if (($category_id > 0) && isset($all_categories[$category_id]) && !empty($all_categories[$category_id])) {
					$parents = array_merge($parents, $all_categories[$category_id]->parents);
				}
			}
		}

		// return structured categories
		if ($flatten == FALSE) {
			foreach ($all_categories as $category_id => $category) {
				// set parent id
				$parent_id = $category->parent_id ? $category->parent_id : 0;

				// add level down categories
				$level_down = FALSE;
				if (($categories != FALSE) && is_array($categories)) {
					foreach ($categories as $param_category_id) {
						if (in_array($param_category_id, $category->parents)) {
							$level_down = TRUE;
							break;
						}
					}
				}

				// add category
				if (($categories == FALSE) || (in_array($category_id, $categories) || in_array($category_id, $parents)) || ($level_down === TRUE)) {
					$return[$parent_id][$category_id] = $category->body;
				}
			}
		}

		// return flat (non structured) categories
		else {
			$return = $categories;
		}

		return $return;
	}


	/**
	 * Security checks
	 *
	 * @access private
	 * @return void
	 */
	private function _security_checks() {
		// add slashes (only if magic_quotes_gpc is disabled in php.ini)
		if (!get_magic_quotes_gpc()) {
			array_walk_recursive($_GET, array($this, '_add_slashes'));
		}

		if (is_array($_GET)) {
			foreach($_GET as $key => $value) {
				// sql injection protection
				$tmp = str_replace(array("*", "'", '"', ";", "="), "", $value);
				// cross site scripting protection
				$tmp = str_replace(array("<", ">"), array("&lt;", "&gt;"), $tmp);
				$_GET[$key] = $tmp;
			}
		}
	}


	/**
	 * Add slashes
	 *
	 * @access private
	 * @param mixed &$item
	 * @param mixed $key
	 * @return void
	 */
	private function _add_slashes(&$item, $key) {
		$item = (!is_array($item) ? addslashes($item) : $item);
	}


}
