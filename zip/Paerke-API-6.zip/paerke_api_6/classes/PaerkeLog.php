<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * API Logger
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeLog {

	/**
	 * Path to log directory
	 */
	private $path;

	/**
	 * Path to logfile
	 */
	private $logfile;


	/**
	 * Constructor
	 *
	 * @access public
	 * @param  string  Path to logfile (optional)
	 * @return void
	 */
	function __construct($logfile = NULL) {

		global $config;
		$path = ABSOLUTE_PATH.'/'.$config['log_directory'];

		if (!$logfile) {
			$this->logfile = $path.date("Y_m_d").".log";
		}
		else {
			$this->logfile = $logfile;
		}

	}

	/**
	 * Log error message
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	public function error($message) {
		$this->_log("ERROR", $message);
	}

	/**
	 * Log info message
	 *
	 * @access public
	 * @param  string
	 * @return void
	 */
	public function info($message) {
		$this->_log("INFO", $message);
	}

	/**
	 * Log message
	 *
	 * @access private
	 * @param  string
	 * @param  string
	 * @return void
	 */
	private function _log($level, $message) {
		$line = date("Y-m-d H:i:s")."\t".$level."\t".$message."\n";
		@file_put_contents($this->logfile, $line, FILE_APPEND);
	}

}