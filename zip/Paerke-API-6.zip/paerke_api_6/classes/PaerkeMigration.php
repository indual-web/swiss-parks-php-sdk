<?php
/*
|---------------------------------------------------------------
| PAERKE.CH API
| https://angebote.paerke.ch/api
|---------------------------------------------------------------
*/


/**
 * Migration class (database)
 *
 * @version 1.1
 * @author indual GmbH, www.indual.ch
 * @copyright 2016 by Netzwerk Schweizer Pärke
 */
class PaerkeMigration {

	/**
	 * API object
	 */
	private $api;


	/**
	 * Database object
	 */
	private $db;


	/**
	 * Configuration items
	 */
	private $config;


	/**
	 * Logger object
	 */
	private $logger;


	/**
	 * Migration details
	 */
	private $version_from;
	private $version_to;



	/**
	 * Constructor
	 *
	 * @access public
	 * @param mixed $api
	 * @return void
	 */
	function __construct($api) {

		// setup api
		$this->api = $api;
		$this->config = $this->api->config;
		$this->db = new PaerkeMySQL($this->config['db_hostname'], $this->config['db_username'], $this->config['db_password'], $this->config['db_database']);
		$this->logger = new PaerkeLog();

		// version from
		$query_api = mysqli_fetch_assoc($this->db->get('api'));
		$this->version_from = intval($query_api['version']);

		// version to
		$this->version_to = API_VERSION;

		// migrate all versions
		for ($version = ($this->version_from+1) ; $version <= $this->version_to ; $version++) {
			$this->migrate($version);
		}

	}



	/**
	 * Execute migrations
	 *
	 * @access private
	 * @return void
	 */
	private function migrate($version_to) {
		if ($version_to > 0) {
			$this->logger->info('Starting migration from version '.$this->version_from.' to version '.$version_to.'...');
			switch($version_to) {

				/*
				|--------------------------------------------------------------------------
				| Migrate version 1 to version 2
				|--------------------------------------------------------------------------
				|
				*/
				case 2:
					$this->db->query("ALTER TABLE offer_route ADD PRIMARY KEY (offer_id);");
					$this->db->query("CREATE TABLE `project` (
										  `offer_id` bigint(20) NOT NULL DEFAULT '0',
										  `duration_from` int(11) DEFAULT NULL,
										  `duration_to` int(11) DEFAULT NULL,
										  `status` tinyint(1) DEFAULT NULL,
										  `poi` text,
										  PRIMARY KEY (`offer_id`),
										  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offer` (`offer_id`) ON DELETE CASCADE
										  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
					");

					// create new main category
					$this->db->insert('category', array('category_id' => CATEGORY_PROJECT, 'parent_id' => 0, 'marker' => '454545', 'sort' => 5000));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'de', 'body' => 'Projekt'));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'fr', 'body' => 'Projet'));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'it', 'body' => 'Progetto'));
					$this->db->insert('category_i18n', array('category_id' => CATEGORY_PROJECT, 'language' => 'en', 'body' => 'Project'));

					// create sub categories
					$this->db->insert('category', array('category_id' => 1001, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ffcc00', 'sort' => 5010));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'de', 'body' => 'Natur / Landschaft'));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'fr', 'body' => 'Nature / paysage'));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'it', 'body' => 'Natura / Paesaggio'));
					$this->db->insert('category_i18n', array('category_id' => 1001, 'language' => 'en', 'body' => 'Nature / Landscape'));

					$this->db->insert('category', array('category_id' => 1002, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'cccccc', 'sort' => 5020));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'de', 'body' => 'Biodiversität'));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'fr', 'body' => 'Biodiversité'));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'it', 'body' => 'Biodiversità'));
					$this->db->insert('category_i18n', array('category_id' => 1002, 'language' => 'en', 'body' => 'Biodiversity'));

					$this->db->insert('category', array('category_id' => 1003, 'parent_id' => CATEGORY_PROJECT, 'marker' => '0066ff', 'sort' => 5030));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'de', 'body' => 'Landwirtschaft'));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'fr', 'body' => 'Agriculture'));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'it', 'body' => 'Agricoltura'));
					$this->db->insert('category_i18n', array('category_id' => 1003, 'language' => 'en', 'body' => 'Agriculture'));

					$this->db->insert('category', array('category_id' => 1004, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff99cc', 'sort' => 5040));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'de', 'body' => 'Forstwirtschaft'));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'fr', 'body' => 'Sylviculture'));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'it', 'body' => 'Economia forestale'));
					$this->db->insert('category_i18n', array('category_id' => 1004, 'language' => 'en', 'body' => 'Forestry'));

					$this->db->insert('category', array('category_id' => 1005, 'parent_id' => CATEGORY_PROJECT, 'marker' => '93dbff', 'sort' => 5050));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'de', 'body' => 'Energie'));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'fr', 'body' => 'Énergie'));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'it', 'body' => 'Energia'));
					$this->db->insert('category_i18n', array('category_id' => 1005, 'language' => 'en', 'body' => 'Energy'));

					$this->db->insert('category', array('category_id' => 1006, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff7b21', 'sort' => 5060));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'de', 'body' => 'Raumplanung'));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'fr', 'body' => 'Aménagement du territoire'));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'it', 'body' => 'Pianificazione territoriale'));
					$this->db->insert('category_i18n', array('category_id' => 1006, 'language' => 'en', 'body' => 'Spatial planning'));

					$this->db->insert('category', array('category_id' => 1007, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'd8d8d8', 'sort' => 5070));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'de', 'body' => 'Tourismus'));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'fr', 'body' => 'Tourisme'));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'it', 'body' => 'Turismo'));
					$this->db->insert('category_i18n', array('category_id' => 1007, 'language' => 'en', 'body' => 'Tourism'));

					$this->db->insert('category', array('category_id' => 1008, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ffff00', 'sort' => 5080));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'de', 'body' => 'Mobilität'));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'fr', 'body' => 'Mobilité'));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'it', 'body' => 'Mobilità'));
					$this->db->insert('category_i18n', array('category_id' => 1008, 'language' => 'en', 'body' => 'Mobility'));

					$this->db->insert('category', array('category_id' => 1009, 'parent_id' => CATEGORY_PROJECT, 'marker' => '00501f', 'sort' => 5090));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'de', 'body' => 'Besucherlenkung'));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'fr', 'body' => 'Gestion des visiteurs'));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'it', 'body' => 'Visite guidate'));
					$this->db->insert('category_i18n', array('category_id' => 1009, 'language' => 'en', 'body' => 'Visitor management'));

					$this->db->insert('category', array('category_id' => 1010, 'parent_id' => CATEGORY_PROJECT, 'marker' => '974807', 'sort' => 5100));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'de', 'body' => 'Zugänglichkeit'));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'fr', 'body' => 'Accessibilité '));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'it', 'body' => 'Accessibilità'));
					$this->db->insert('category_i18n', array('category_id' => 1010, 'language' => 'en', 'body' => 'Accessibility'));

					$this->db->insert('category', array('category_id' => 1011, 'parent_id' => CATEGORY_PROJECT, 'marker' => '7dd53b', 'sort' => 5110));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'de', 'body' => 'Bildung'));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'fr', 'body' => 'Education'));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'it', 'body' => 'Formazione'));
					$this->db->insert('category_i18n', array('category_id' => 1011, 'language' => 'en', 'body' => 'Education'));

					$this->db->insert('category', array('category_id' => 1012, 'parent_id' => CATEGORY_PROJECT, 'marker' => '699fd6', 'sort' => 5120));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'de', 'body' => 'Kultur'));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'fr', 'body' => 'Culture'));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'it', 'body' => 'Cultura'));
					$this->db->insert('category_i18n', array('category_id' => 1012, 'language' => 'en', 'body' => 'Culture'));

					$this->db->insert('category', array('category_id' => 1013, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'c79602', 'sort' => 5130));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'de', 'body' => 'Regionale Produkte'));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'fr', 'body' => 'Produits régionaux'));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'it', 'body' => 'Prodotti regionali'));
					$this->db->insert('category_i18n', array('category_id' => 1013, 'language' => 'en', 'body' => 'Regional products'));

					$this->db->insert('category', array('category_id' => 1014, 'parent_id' => CATEGORY_PROJECT, 'marker' => 'ff00ff', 'sort' => 5140));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'de', 'body' => 'Gesundheit / Wellness'));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'fr', 'body' => 'Santé / bien-être'));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'it', 'body' => 'Benessere / wellness'));
					$this->db->insert('category_i18n', array('category_id' => 1014, 'language' => 'en', 'body' => 'Health / wellness'));

					$this->db->insert('category', array('category_id' => 1015, 'parent_id' => CATEGORY_PROJECT, 'marker' => '9b7bb4', 'sort' => 5150));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'de', 'body' => 'Nachhaltigkeit'));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'fr', 'body' => 'Durabilité'));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'it', 'body' => 'Sostenibilità'));
					$this->db->insert('category_i18n', array('category_id' => 1015, 'language' => 'en', 'body' => 'Sustainability'));

					$this->db->insert('category', array('category_id' => 1016, 'parent_id' => CATEGORY_PROJECT, 'marker' => '376091', 'sort' => 5160));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'de', 'body' => 'Dienstleistungen'));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'fr', 'body' => 'Services'));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'it', 'body' => 'Servizi'));
					$this->db->insert('category_i18n', array('category_id' => 1016, 'language' => 'en', 'body' => 'Services'));

					$this->db->insert('category', array('category_id' => 1017, 'parent_id' => CATEGORY_PROJECT, 'marker' => '7030a0', 'sort' => 5170));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'de', 'body' => 'Transnationale Projekte'));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'fr', 'body' => 'Projets transfrontaliers'));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'it', 'body' => 'Progetti transnazionali'));
					$this->db->insert('category_i18n', array('category_id' => 1017, 'language' => 'en', 'body' => 'Transnational projects'));

					// move research category
					$this->db->query("UPDATE `category` SET `category`.`sort` = 6000 WHERE `category_id` = 5000 LIMIT 1;");
					$this->db->query("UPDATE `category` SET `category`.`sort` = 6010 WHERE `category_id` = 5001 LIMIT 1;");
					$this->db->query("UPDATE `category` SET `category`.`sort` = 6020 WHERE `category_id` = 5002 LIMIT 1;");

					break;


				/*
				|--------------------------------------------------------------------------
				| Migrate version 4 to version 5
				|--------------------------------------------------------------------------
				|
				*/
				case 5:
					$this->db->query("ALTER TABLE `offer` ADD COLUMN `is_hint` TINYINT(1) AFTER `park`;");
					break;

				/*
				|--------------------------------------------------------------------------
				| Migrate version 5 to version 6
				|--------------------------------------------------------------------------
				|
				*/
				case 6:

					// create new keywords field for offers
					$this->db->query("ALTER TABLE `offer` ADD COLUMN `keywords` VARCHAR(150) AFTER `longitude`;");

					// create category: event -> presentation
					$this->db->insert('category', array('category_id' => 122, 'parent_id' => 1, 'marker' => 'ffcc00', 'sort' => 1025));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'de', 'body' => 'Vortrag'));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'fr', 'body' => 'Présentation'));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'it', 'body' => 'Presentatzione'));
					$this->db->insert('category_i18n', array('category_id' => 122, 'language' => 'en', 'body' => 'Presentation'));

					// create category: product -> producer
					$this->db->insert('category', array('category_id' => 123, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2312));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'de', 'body' => 'Produzent'));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'fr', 'body' => 'Producteur'));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'it', 'body' => 'Produttore'));
					$this->db->insert('category_i18n', array('category_id' => 123, 'language' => 'en', 'body' => 'Producer'));

					// create category: product -> shop for regional products
					$this->db->insert('category', array('category_id' => 124, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2314));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'de', 'body' => 'Verkauf Regionalprodukte'));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'fr', 'body' => 'Vente du produits regionaux'));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'it', 'body' => 'Vendita di prodotti regionali'));
					$this->db->insert('category_i18n', array('category_id' => 124, 'language' => 'en', 'body' => 'Shop for regional products'));

					// create category: product -> gifts
					$this->db->insert('category', array('category_id' => 125, 'parent_id' => 19, 'marker' => '93dbff', 'sort' => 2316));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'de', 'body' => 'Geschenke'));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'fr', 'body' => 'Cadeaux'));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'it', 'body' => 'Regali'));
					$this->db->insert('category_i18n', array('category_id' => 125, 'language' => 'en', 'body' => 'Gifts'));

					// update category: product -> further
					$this->db->update('category_i18n', array('body' => 'Weitere Produkte'), array('category_id' => 27, 'language' => 'de'));

					// update category: gastronomy/accommodation -> restaurant
					$this->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'de'));
					$this->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'fr'));
					$this->db->update('category_i18n', array('body' => 'Ristorante'), array('category_id' => 28, 'language' => 'it'));
					$this->db->update('category_i18n', array('body' => 'Restaurant'), array('category_id' => 28, 'language' => 'en'));

					// create category: gastronomy/accommodation -> cafe
					$this->db->insert('category', array('category_id' => 126, 'parent_id' => 20, 'marker' => 'ff7b21', 'sort' => 2415));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'de', 'body' => 'Cafe'));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'fr', 'body' => 'Café'));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'it', 'body' => 'Caffè'));
					$this->db->insert('category_i18n', array('category_id' => 126, 'language' => 'en', 'body' => 'Cafe'));

					// check all cafe offers coming from restaurant
					$q_category_link = $this->db->get('category_link', array('category_id' => 28));
					if (mysqli_num_rows($q_category_link) > 0) {
						while ($row = mysqli_fetch_object($q_category_link)) {
							$this->db->insert('category_link', array('offer_id' => $row->offer_id, 'category_id' => 126));
						}
					}

					// create category: infrastructure -> swimming pool/lake
					$this->db->insert('category', array('category_id' => 127, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2631));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'de', 'body' => 'Schwimmbad/Badesee'));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'fr', 'body' => 'Piscine/Lac de baignade'));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'it', 'body' => 'Piscina/Lago balneabile'));
					$this->db->insert('category_i18n', array('category_id' => 127, 'language' => 'en', 'body' => 'Swimming pool/Swimming lake'));

					// update category sort: infrastructure -> watersports
					$this->db->update('category', array('sort' => 2633), array('category_id' => 119));

					// create category: infrastructure -> funicular
					$this->db->insert('category', array('category_id' => 128, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2632));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'de', 'body' => 'Seilbahn'));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'fr', 'body' => 'Funiculaire'));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'it', 'body' => 'Funicolare'));
					$this->db->insert('category_i18n', array('category_id' => 128, 'language' => 'en', 'body' => 'Funicular'));

					// create category: infrastructure -> climbing
					$this->db->insert('category', array('category_id' => 129, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2638));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'de', 'body' => 'Klettern'));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'fr', 'body' => 'Escalade'));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'it', 'body' => 'Arrampicata'));
					$this->db->insert('category_i18n', array('category_id' => 129, 'language' => 'en', 'body' => 'Climbing'));

					// create category: infrastructure -> skating rink
					$this->db->insert('category', array('category_id' => 130, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2643));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'de', 'body' => 'Eisbahn'));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'fr', 'body' => 'Patinoire'));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'it', 'body' => 'Pista di ghiaccio'));
					$this->db->insert('category_i18n', array('category_id' => 130, 'language' => 'en', 'body' => 'Skating rink'));

					// create category: infrastructure -> cross-country skiing
					$this->db->insert('category', array('category_id' => 131, 'parent_id' => 100, 'marker' => 'd8d8d8', 'sort' => 2647));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'de', 'body' => 'Langlauf'));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'fr', 'body' => 'Ski de fond'));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'it', 'body' => 'Sci di fondo'));
					$this->db->insert('category_i18n', array('category_id' => 131, 'language' => 'en', 'body' => 'Cross-country skiing'));

					break;


				default:
					break;


			}

			// update db version
			$this->db->query("UPDATE `api` SET `version` = ".$version_to." LIMIT 1;");
			$this->logger->info('Migration to version '.$version_to.' successfully finished.');
		}
		else {
			$this->logger->error('No valid version number set.');
		}
	}



}
