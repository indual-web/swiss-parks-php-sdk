<?php
/*
|---------------------------------------------------------------
| parks.swiss API
| Netzwerk Schweizer Pärke
|---------------------------------------------------------------
|
| Example for displaying a list of offers using the parks.swiss API
|
*/

// include API
require_once('parks_api/autoload.php');

// initialize API with default language and optional with an alternative hash
$api = new ParksAPI('de');

?>
<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8">
	<title>parks.swiss API Example</title>

	<!-- Viewport, reponsive design -->
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

	<!-- Important CSS styles and javascripts for using the parks.swiss API -->
	<link href="https://angebote.paerke.ch/css/frontend/api.css?v=10" rel="stylesheet">
	<script src="https://angebote.paerke.ch/js/i18n/<?php echo $api->lang_id; ?>.js"></script>
	<script src="https://angebote.paerke.ch/addons/jquery/jquery.js"></script>
	<script src="https://angebote.paerke.ch/addons/jquery/jquery-ui.js"></script>
	<script src="https://angebote.paerke.ch/js/frontend/ParkApp.js?v=10"></script>

</head>
<body>
	<div id="parks_offer_wrap" class="<?php echo $api->is_offer_detail() ? 'detail' : ''; ?>">
		<?php

		// map options
		$api->map_options = array(
			/*
			'show_layers_at_start' => FALSE, 			// show/hide layers at start after loading
			'parkperimeter_visibility' => TRUE;			// show/hide swiss parks perimeter after loading
			'associated_members_visibility' => TRUE;	// show/hide associated members layer
			'link_target' => '_blank', 					// set the link target for offer detail links in the map
			'full_height' => FALSE, 					// show the map over full window height
			'map_extent' => array(						// overwrite init extent on overview maps and set your own
				'xmin' => 2590807.0,
				'ymin' => 1130285.0,
				'xmax' => 2736607.0,
				'ymax' => 1235385.0,
			),
			*/
		);

		// filter settings
		$filter = array(
			/*
			'keywords' => '', 							// filter by keywords
			'contact_is_park_partner' => 0, 			// 1 == show only offers from park partners
			'target_groups' => array(6), 				// filter by target groups
			'search' => '', 							// filter by an explicit word
			'offers_barrier_free' => 0, 				// 1 = barrier free offers
			'offers_learning_opportunity' => 0, 		// 1 = learning opportunity offers
			'offers_child_friendly' => 0, 				// 1 = child friendly offers
			'offers_filter_hints' => 0, 				// 1 = show only hints (Tipps)
			'offers_is_park_event' => 1,				// 1 = show only park events	
			'offers' => array(),						// filter by offer ids
			'system_filter' => array(					// additional filter set by your system
				'target_groups' => array()				// show only these target groups in offers list and filter view field
			)
			*/
		);

		// filter categories
		$categories = array();

		// show detail page
		if ($api->is_offer_detail()) {
			$api->show_offer_detail();
		}

		// show offer listing
		else {
			// show offer filter
			$api->show_offers_filter($categories, $filter);
			?>
			<div id="content_top">
				<ul class="tab_list move_offer_total" role="tablist" aria-hidden="true">
					<li data="tab_1" role="tab" class="current" aria-controls="tab_1"><?php echo $api->lang->get('offer_list'); ?></li>
					<li data="tab_2" role="tab" class="" aria-controls="tab_2"><?php echo $api->lang->get('offer_map'); ?></li>
				</ul>
			</div>
			<div id="content">
				<div class="tab_content tab_content_1 show">
					<?php
					$api->show_offers_list($categories, $filter);
					$api->show_offers_pagination();
					?>
				</div>
				<div class="tab_content tab_content_2" aria-hidden="true">
					<?php $api->show_offers_map($categories, $filter); ?>
				</div>
			</div>
			<?php
		}
		?>
	</div>
</body>
</html>